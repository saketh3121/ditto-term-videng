import ridersContent from "@/content/riders.json";
import { visibleFeatureCategories } from "@/lib/feature-comparison";
import type { InbuiltFeatureCategory, RidersContent, StaticComparisonColumn, StaticComparisonTable } from "@/types";

/**
 * Client-safe Riders access, same direct-import pattern as
 * lib/inbuilt-features.ts — content/riders.json is bundler-inlined, no
 * fetch, no server round-trip.
 */

const RIDERS = ridersContent as RidersContent;

export type RiderPill = "wop" | "ci" | "others";

export function visibleOthersCategories(policyIds: string[]): InbuiltFeatureCategory[] {
  return visibleFeatureCategories(RIDERS.others.categories, policyIds);
}

export function staticTable(pill: "wop" | "ci"): StaticComparisonTable {
  return RIDERS[pill];
}

/**
 * One column per currently-selected policy that the table has data for —
 * same per-policy resolution as InbuiltFeaturesTable. Ordered by
 * `policyIds` (selection order), not the static table's own column order,
 * so column order stays consistent with every other table on the site.
 */
export function visibleStaticColumns(table: StaticComparisonTable, policyIds: string[]): StaticComparisonColumn[] {
  return policyIds
    .map((id) => table.columns.find((c) => c.policyId === id))
    .filter((c): c is StaticComparisonColumn => c !== undefined);
}
