import { describe, expect, it } from "vitest";
import { parseDetailFields } from "./detail-fields";

describe("parseDetailFields", () => {
  it("splits a labeled sub-item list into a value array", () => {
    const text =
      "1. Total cover paid\na. If the life assured is diagnosed with a terminal illness before the age of 80, HDFC Life will pay up to ₹2 crore.\nb. Accelerated benefit\n\n2. Definition of terminal illness\n A condition certified in writing by two doctors.\n\n3. WoP on remaining SA: no";
    const fields = parseDetailFields(text);
    expect(fields).toHaveLength(3);
    expect(fields[0]).toEqual({
      label: "Total cover paid",
      lead: undefined,
      value: [
        "If the life assured is diagnosed with a terminal illness before the age of 80, HDFC Life will pay up to ₹2 crore.",
        "Accelerated benefit",
      ],
    });
    expect(fields[1]).toEqual({ label: "Definition of terminal illness", value: "A condition certified in writing by two doctors." });
    expect(fields[2]).toEqual({ label: "WoP on remaining SA", value: "no" });
  });

  it("captures a lead line between the label and a sub-item list", () => {
    const text =
      "1. Policyholder has an option to increase their Sum Assured during important life stages.\nPolicyholder can increase their SA as mentioned below:\na. Marriage - 50% of SA\nb. Birth of 1st Child - 25% of SA";
    const [field] = parseDetailFields(text);
    expect(field).toEqual({
      label: "Policyholder has an option to increase their Sum Assured during important life stages.",
      lead: "Policyholder can increase their SA as mentioned below:",
      value: ["Marriage - 50% of SA", "Birth of 1st Child - 25% of SA"],
    });
  });

  it("falls back to a label-less value when a block has no clean split", () => {
    const fields = parseDetailFields("Available for NRIs travelling to India.");
    expect(fields).toEqual([{ label: "", value: "Available for NRIs travelling to India." }]);
  });

  it("treats '-' lines as sub-items alongside lettered markers", () => {
    const text = "e. Documents required to process the claim:\n-Death Certificate\n-Cancelled Cheque\n-Claim Intimation Form";
    const [field] = parseDetailFields(text);
    expect(field).toEqual({
      label: "",
      lead: undefined,
      value: ["Documents required to process the claim:", "Death Certificate", "Cancelled Cheque", "Claim Intimation Form"],
    });
  });

  it("strips a leading line that just restates the modal title", () => {
    const text = "Instant payout on claim intimation: \na. An accelerated benefit up to 2 lakhs is payable within 1 working day.\n\nb. Waiting period: 1 year.";
    const fields = parseDetailFields(text, "Instant Payout on Claim Intimation");
    expect(fields).toEqual([
      { label: "", lead: undefined, value: ["An accelerated benefit up to 2 lakhs is payable within 1 working day."] },
      { label: "", lead: undefined, value: ["Waiting period: 1 year."] },
    ]);
  });

  it("leaves the text untouched when the leading line doesn't match the title", () => {
    const text = "1. Total cover paid\na. Something.";
    const fields = parseDetailFields(text, "Terminal Illness");
    expect(fields[0]?.label).toBe("Total cover paid");
  });
});
