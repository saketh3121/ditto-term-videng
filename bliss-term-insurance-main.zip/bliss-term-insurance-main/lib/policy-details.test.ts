import { describe, expect, it } from "vitest";
import { getCategory, getItem } from "./policy-details";
import type { PolicyDetailsContent } from "@/types";

const SAMPLE: PolicyDetailsContent = {
  policyId: "sample-policy",
  categories: [
    {
      category: "entry-age",
      items: [
        { label: "Min Age", text: "18" },
        { label: "Max Age", text: "65" },
      ],
    },
    {
      category: "paid-add-ons",
      items: [{ label: "Critical Illness", text: "Up to 1.5 Cr" }],
    },
  ],
};

describe("getCategory", () => {
  it("returns the matching category", () => {
    expect(getCategory(SAMPLE, "entry-age")?.items).toHaveLength(2);
  });

  it("returns undefined for a category the policy doesn't have", () => {
    expect(getCategory(SAMPLE, "nri-guidelines")).toBeUndefined();
  });
});

describe("getItem", () => {
  it("returns the matching item within a category", () => {
    expect(getItem(SAMPLE, "entry-age", "Max Age")?.text).toBe("65");
  });

  it("returns undefined for an unknown label", () => {
    expect(getItem(SAMPLE, "entry-age", "Not A Label")).toBeUndefined();
  });

  it("returns undefined when the category itself is absent", () => {
    expect(getItem(SAMPLE, "variants", "Variants")).toBeUndefined();
  });
});
