/**
 * Pure time-window check for content-driven, expiring notices (e.g.
 * ChromeContent.priceRevisionBanner). Takes `now` as a parameter
 * (defaulting to the real clock) so callers and tests can pin it.
 */
export function isWithinBannerWindow(expiresAt: string, now: Date = new Date()): boolean {
  const expiry = new Date(expiresAt);
  if (Number.isNaN(expiry.getTime())) return false;
  return now.getTime() < expiry.getTime();
}
