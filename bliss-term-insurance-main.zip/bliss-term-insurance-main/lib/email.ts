import "server-only";
import { upsertFile } from "@/lib/cms/github";
import { CMS_BASE_BRANCH, CMS_BOT_AUTHOR } from "@/config/cms";
import { emailToSlug } from "@/lib/slug";

/**
 * Queues an access request instead of sending email directly — @joinditto.in's
 * Google Workspace blocks direct SMTP and externally-triggered Apps Script Web
 * Apps (same restriction as ditto-health-insurance-bliss), so a separate Apps
 * Script project polls `pending-requests/` every 5 minutes and emails the
 * admin from there. See docs/AUTH.md for the full flow and Apps Script setup.
 */
export async function sendAccessRequestEmail(name: string, email: string): Promise<void> {
  const slug = emailToSlug(email);
  const path = `pending-requests/${Date.now()}-${slug}.json`;
  const content = `${JSON.stringify(
    { name, email: email.toLowerCase(), requestedAt: new Date().toISOString() },
    null,
    2,
  )}\n`;

  try {
    await upsertFile({
      path,
      content,
      message: `request: ${email.toLowerCase()}`,
      branch: CMS_BASE_BRANCH,
      author: CMS_BOT_AUTHOR,
    });
  } catch (err) {
    console.error(`[access-request] failed to queue request for ${email}:`, err);
  }
}
