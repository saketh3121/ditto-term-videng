import policiesContent from "@/content/policies.json";
import type { Policy, PoliciesContent } from "@/types";

/**
 * Client-safe policy access. `content/policies.json` is imported directly so
 * the bundler inlines it — the Control/Policy panels and the Recommendations
 * step all read from this one source (no fetch, no server round-trip).
 */

const { policies } = policiesContent as PoliciesContent;

export const POLICIES: Policy[] = policies;

export function policyById(id: string): Policy | undefined {
  return POLICIES.find((p) => p.id === id);
}

export interface InsurerPolicyGroup {
  insurerId: string;
  insurerName: string;
  policies: Policy[];
}

/** Group policies by owning insurer, preserving file order. */
export function policiesByInsurer(): InsurerPolicyGroup[] {
  const groups: InsurerPolicyGroup[] = [];
  for (const p of POLICIES) {
    let group = groups.find((g) => g.insurerId === p.insurerId);
    if (!group) {
      group = { insurerId: p.insurerId, insurerName: p.insurerName, policies: [] };
      groups.push(group);
    }
    group.policies.push(p);
  }
  return groups;
}

/** Unique insurer ids owning the given policy ids (order-preserving). */
export function insurerIdsForPolicies(policyIds: string[]): string[] {
  const ids: string[] = [];
  for (const pid of policyIds) {
    const p = policyById(pid);
    if (p && !ids.includes(p.insurerId)) ids.push(p.insurerId);
  }
  return ids;
}

/** Which of the given selected policy ids belong to one insurer (order-preserving). */
export function selectedPoliciesForInsurer(insurerId: string, policyIds: string[]): Policy[] {
  return policyIds
    .map((id) => policyById(id))
    .filter((p): p is Policy => p !== undefined && p.insurerId === insurerId);
}
