import { describe, expect, it } from "vitest";
import { categoryToNarrative } from "./policy-narrative";
import type { PolicyDetailCategory } from "@/types";

describe("categoryToNarrative", () => {
  it("joins single line breaks into one flowing sentence and keeps blank-line breaks as separate sentences", () => {
    const category: PolicyDetailCategory = {
      category: "inbuilt-benefits",
      items: [
        {
          label: "Terminal Illness",
          text: "1. Total cover paid\na. Up to 2Cr.\n\n2. Waiting period: none",
        },
      ],
    };
    const [paragraph] = categoryToNarrative(category);
    expect(paragraph?.text).toBe("1. Total cover paid a. Up to 2Cr. 2. Waiting period: none");
  });

  it("drops items whose text is a blank placeholder", () => {
    const category: PolicyDetailCategory = {
      category: "paid-add-ons",
      items: [
        { label: "Premium Holiday", text: "-" },
        { label: "Maternity Cover", text: "Not available" },
        { label: "Critical Illness", text: "Covered up to 1.5 Cr" },
      ],
    };
    const result = categoryToNarrative(category);
    expect(result).toHaveLength(1);
    expect(result[0]).toEqual({ label: "Critical Illness", text: "Covered up to 1.5 Cr" });
  });

  it("preserves the item label alongside its flowed text", () => {
    const category: PolicyDetailCategory = {
      category: "entry-age",
      items: [{ label: "Min Age", text: "18" }],
    };
    expect(categoryToNarrative(category)).toEqual([{ label: "Min Age", text: "18" }]);
  });
});
