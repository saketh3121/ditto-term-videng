import abbreviationsContent from "@/content/abbreviations.json";
import type { AbbreviationsContent } from "@/types";

/**
 * Client-safe abbreviation glossary access, same pattern as
 * lib/inbuilt-features.ts — content/abbreviations.json is imported directly
 * so the bundler inlines it (no fetch, no server round-trip).
 */

const { abbreviations } = abbreviationsContent as AbbreviationsContent;

// Keyed by uppercase abbr so lookups after a case-insensitive match (below)
// find the entry regardless of how the source content cased it (content
// writes both "SA" and "WoP", for instance).
export const ABBREVIATION_MAP: ReadonlyMap<string, string> = new Map(
  abbreviations.map((a) => [a.abbr.toUpperCase(), a.expansion]),
);

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

// Longest-first so a shorter abbreviation can't shadow one that starts with
// the same letters (not currently possible with \b-wrapped alternation, but
// keeps the match order deterministic if the glossary grows).
const sortedAbbrs = [...ABBREVIATION_MAP.keys()].sort((a, b) => b.length - a.length);

const MATCH_RE =
  sortedAbbrs.length > 0
    ? new RegExp(`\\b(${sortedAbbrs.map(escapeRegExp).join("|")})\\b`, "gi")
    : null;

export type TextSegment = { kind: "text"; value: string } | { kind: "abbr"; abbr: string; expansion: string };

/**
 * Splits `text` into plain-text and abbreviation segments, matching whole
 * words only, case-insensitively (content cases abbreviations inconsistently
 * — "SA", "WoP" — so matching is case-insensitive but the matched text keeps
 * its original casing on screen; only the glossary lookup is case-folded).
 */
export function annotateAbbreviations(text: string): TextSegment[] {
  if (!MATCH_RE) return [{ kind: "text", value: text }];

  const segments: TextSegment[] = [];
  let lastIndex = 0;
  MATCH_RE.lastIndex = 0;

  let match: RegExpExecArray | null;
  while ((match = MATCH_RE.exec(text)) !== null) {
    if (match.index > lastIndex) {
      segments.push({ kind: "text", value: text.slice(lastIndex, match.index) });
    }
    const abbr = match[0];
    segments.push({ kind: "abbr", abbr, expansion: ABBREVIATION_MAP.get(abbr.toUpperCase())! });
    lastIndex = match.index + abbr.length;
  }
  if (lastIndex < text.length) {
    segments.push({ kind: "text", value: text.slice(lastIndex) });
  }
  return segments;
}
