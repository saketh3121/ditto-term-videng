import { describe, expect, it } from "vitest";
import { emailToSlug } from "./slug";

describe("emailToSlug", () => {
  it("replaces @ and . with -", () => {
    expect(emailToSlug("sameen.gulzar@joinditto.in")).toBe("sameen-gulzar-joinditto-in");
  });

  it("lowercases mixed-case emails", () => {
    expect(emailToSlug("Nikita@joinditto.in")).toBe("nikita-joinditto-in");
  });
});
