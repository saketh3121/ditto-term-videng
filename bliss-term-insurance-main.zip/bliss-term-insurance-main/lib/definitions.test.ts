import { describe, expect, it } from "vitest";
import { getDefinition, getDefinitionsByCategory } from "./definitions";
import type { DefinitionEntry } from "@/types";

const SAMPLE: DefinitionEntry[] = [
  { category: "inbuilt-benefits", label: "Terminal Illness", text: "Advance payout on terminal diagnosis." },
  { category: "inbuilt-benefits", label: "Lifeline Plus", text: "Top-up cover on spouse's death." },
  { category: "paid-add-ons", label: "Critical Illness", text: "Lump-sum payout on specified illness." },
];

describe("getDefinition", () => {
  it("finds a definition by label", () => {
    expect(getDefinition(SAMPLE, "Critical Illness")?.text).toBe("Lump-sum payout on specified illness.");
  });

  it("returns undefined for an unknown label", () => {
    expect(getDefinition(SAMPLE, "Not A Term")).toBeUndefined();
  });
});

describe("getDefinitionsByCategory", () => {
  it("returns all definitions in a category", () => {
    expect(getDefinitionsByCategory(SAMPLE, "inbuilt-benefits")).toHaveLength(2);
  });

  it("returns an empty array for a category with no definitions", () => {
    expect(getDefinitionsByCategory(SAMPLE, "nri-guidelines")).toHaveLength(0);
  });
});
