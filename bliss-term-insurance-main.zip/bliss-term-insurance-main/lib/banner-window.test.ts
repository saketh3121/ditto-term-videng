import { describe, it, expect } from "vitest";
import { isWithinBannerWindow } from "./banner-window";

describe("isWithinBannerWindow", () => {
  it("is true before the expiry instant", () => {
    expect(isWithinBannerWindow("2026-10-17T00:00:00+05:30", new Date("2026-10-16T23:00:00+05:30"))).toBe(true);
  });

  it("is false at the expiry instant", () => {
    expect(isWithinBannerWindow("2026-10-17T00:00:00+05:30", new Date("2026-10-17T00:00:00+05:30"))).toBe(false);
  });

  it("is false after the expiry instant", () => {
    expect(isWithinBannerWindow("2026-10-17T00:00:00+05:30", new Date("2026-10-20T00:00:00+05:30"))).toBe(false);
  });

  it("is false for an unparseable date", () => {
    expect(isWithinBannerWindow("not a date")).toBe(false);
  });
});
