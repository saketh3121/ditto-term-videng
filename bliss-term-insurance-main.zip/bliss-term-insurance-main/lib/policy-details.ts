import type {
  PolicyDetailCategory,
  PolicyDetailCategoryId,
  PolicyDetailItem,
  PolicyDetailsContent,
} from "@/types";

/**
 * Pure lookups over a policy's detail content — no I/O. Lets a step
 * component pull exactly the aspect it needs (e.g. only "paid-add-ons" for
 * a Riders step) without caring about the rest of the record.
 */

export function getCategory(
  details: PolicyDetailsContent,
  category: PolicyDetailCategoryId,
): PolicyDetailCategory | undefined {
  return details.categories.find((c) => c.category === category);
}

export function getItem(
  details: PolicyDetailsContent,
  category: PolicyDetailCategoryId,
  label: string,
): PolicyDetailItem | undefined {
  return getCategory(details, category)?.items.find((i) => i.label === label);
}
