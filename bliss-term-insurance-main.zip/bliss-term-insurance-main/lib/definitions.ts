import type { DefinitionEntry, PolicyDetailCategoryId } from "@/types";

/** Pure lookups over the glossary — no I/O. */

export function getDefinition(
  definitions: DefinitionEntry[],
  label: string,
): DefinitionEntry | undefined {
  return definitions.find((d) => d.label === label);
}

export function getDefinitionsByCategory(
  definitions: DefinitionEntry[],
  category: PolicyDetailCategoryId,
): DefinitionEntry[] {
  return definitions.filter((d) => d.category === category);
}
