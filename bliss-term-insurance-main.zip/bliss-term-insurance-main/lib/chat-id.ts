/**
 * Validates and parses the DittoHQ chat link pasted into the Control Panel's
 * mandatory Chat ID field, e.g. "https://dittohq.in/whatsapp/chats?chat=CH515923".
 * Pure — no React, no I/O — so the format rule is unit-testable and reusable
 * by both the Control Panel form and the server-side chat log writer.
 */

const CHAT_LINK_PATTERN = /^https:\/\/dittohq\.in\/whatsapp\/chats\?chat=(CH\d+)$/;

/** True when `value` (after trimming) is a well-formed DittoHQ chat link. */
export function isValidChatLink(value: string): boolean {
  return CHAT_LINK_PATTERN.test(value.trim());
}

/** Extracts the "CH..." chat ID from a valid link; null if the link doesn't match. */
export function extractChatId(value: string): string | null {
  const match = CHAT_LINK_PATTERN.exec(value.trim());
  return match ? match[1]! : null;
}
