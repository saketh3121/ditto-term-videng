import "server-only";
import { promises as fs } from "fs";
import path from "path";
import { cache } from "react";
import { advisorSchema, definitionsContentSchema, insurerSchema, policyDetailsContentSchema } from "@/schemas/content";
import type { Advisor, DefinitionEntry, Insurer, PolicyDetailsContent } from "@/types";

/**
 * Server-only content loader.
 *
 * `import "server-only"` makes the build FAIL if any client component imports
 * this file — so confidential content physically cannot leak into the browser
 * bundle (the failure mode the term SPA couldn't prevent). Every read is
 * validated through its zod schema, so malformed data throws a named error
 * here instead of rendering as `undefined` on a live call.
 */

const CONTENT_DIR = path.join(process.cwd(), "content");

async function readJsonDir<T>(
  subdir: string,
  parse: (raw: unknown, file: string) => T,
): Promise<T[]> {
  const dir = path.join(CONTENT_DIR, subdir);
  const files = (await fs.readdir(dir)).filter((f) => f.endsWith(".json"));
  return Promise.all(
    files.map(async (file) => {
      const raw = JSON.parse(await fs.readFile(path.join(dir, file), "utf-8"));
      return parse(raw, `${subdir}/${file}`);
    }),
  );
}

export const getInsurers = cache(async (): Promise<Insurer[]> => {
  const insurers = await readJsonDir("insurers", (raw, file) => {
    const result = insurerSchema.safeParse(raw);
    if (!result.success) {
      throw new Error(
        `Invalid insurer content in ${file}: ${result.error.message}`,
      );
    }
    return result.data;
  });
  return insurers.sort((a, b) => b.csr - a.csr);
});

export const getInsurersBySegment = cache(
  async (segment: Insurer["segments"][number]): Promise<Insurer[]> => {
    const all = await getInsurers();
    return all.filter((i) => i.segments.includes(segment));
  },
);

export const getInsurerById = cache(async (id: string): Promise<Insurer | null> => {
  const all = await getInsurers();
  return all.find((i) => i.id === id) ?? null;
});

export const getAllPolicyDetails = cache(async (): Promise<PolicyDetailsContent[]> => {
  return readJsonDir("policy-details", (raw, file) => {
    const result = policyDetailsContentSchema.safeParse(raw);
    if (!result.success) {
      throw new Error(
        `Invalid policy details in ${file}: ${result.error.message}`,
      );
    }
    return result.data;
  });
});

export const getPolicyDetailsById = cache(
  async (policyId: string): Promise<PolicyDetailsContent | null> => {
    const all = await getAllPolicyDetails();
    return all.find((p) => p.policyId === policyId) ?? null;
  },
);

export const getAllAdvisors = cache(async (): Promise<Advisor[]> => {
  return readJsonDir("advisors", (raw, file) => {
    const result = advisorSchema.safeParse(raw);
    if (!result.success) {
      throw new Error(`Invalid advisor content in ${file}: ${result.error.message}`);
    }
    return result.data;
  });
});

export const getAdvisorByEmail = cache(async (email: string): Promise<Advisor | null> => {
  const normalized = email.toLowerCase();
  const all = await getAllAdvisors();
  return all.find((a) => a.email.toLowerCase() === normalized) ?? null;
});

export const getDefinitions = cache(async (): Promise<DefinitionEntry[]> => {
  const file = path.join(CONTENT_DIR, "definitions.json");
  const raw = JSON.parse(await fs.readFile(file, "utf-8"));
  const result = definitionsContentSchema.safeParse(raw);
  if (!result.success) {
    throw new Error(`Invalid content/definitions.json: ${result.error.message}`);
  }
  return result.data.definitions;
});
