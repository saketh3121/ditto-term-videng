import specificIllnessesContent from "@/content/specific-illnesses.json";
import type { IllnessList, SpecificIllnessesContent } from "@/types";

/**
 * Client-safe WOP/CI illness-list access, same direct-import pattern as
 * lib/policies.ts. `lists` is normalized (insurers reuse the same block
 * across several of their own plans) — resolve a policy's blocks through
 * this module rather than reading content/specific-illnesses.json directly.
 */

const CONTENT = specificIllnessesContent as SpecificIllnessesContent;

export function illnessListsForPolicy(policyId: string, side: "wop" | "ci"): IllnessList[] {
  const entry = CONTENT.policies[policyId];
  if (!entry) return [];
  return entry[side].map((id) => CONTENT.lists[id]).filter((l): l is IllnessList => l !== undefined);
}

export function hasIllnessData(policyId: string): boolean {
  return CONTENT.policies[policyId] !== undefined;
}

/** Every policyId with at least one WOP or CI illness list, in content/policies.json order. */
export function policyIdsWithIllnessData(orderedPolicyIds: string[]): string[] {
  return orderedPolicyIds.filter((id) => hasIllnessData(id));
}
