"use client";

import { useEffect, useRef, useState } from "react";

const DEFAULT_INTERVAL_MS = 150;
const DEFAULT_SETTLE_MS = 450;

/**
 * The site's one signature motion: items reveal one at a time, left to
 * right, on first mount only — later updates (toggling a milestone,
 * switching tier, etc.) snap straight to the full set instead of replaying
 * the stagger. Shared by the milestone chart and the landing hero's
 * projection teaser so it reads as one deliberate motion language, not a
 * one-off chart effect.
 *
 * @returns how many of `itemCount` items should currently render.
 */
export function useStaggeredReveal(
  itemCount: number,
  { intervalMs = DEFAULT_INTERVAL_MS, settleMs = DEFAULT_SETTLE_MS }: { intervalMs?: number; settleMs?: number } = {},
): number {
  const doneRef = useRef(false);
  const [visibleCount, setVisibleCount] = useState(0);

  useEffect(() => {
    if (doneRef.current) {
      setVisibleCount(itemCount);
      return undefined;
    }
    setVisibleCount(0);
    const timers: ReturnType<typeof setTimeout>[] = [];
    for (let i = 1; i <= itemCount; i++) {
      timers.push(setTimeout(() => setVisibleCount(i), i * intervalMs));
    }
    timers.push(setTimeout(() => (doneRef.current = true), itemCount * intervalMs + settleMs));
    return () => timers.forEach(clearTimeout);
  }, [itemCount, intervalMs, settleMs]);

  return visibleCount;
}
