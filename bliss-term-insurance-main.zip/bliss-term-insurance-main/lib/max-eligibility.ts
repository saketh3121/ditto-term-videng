import type { Residency } from "@/types";

/**
 * Max-eligibility multipliers per insurer / plan. Pure logic, zero
 * dependencies — safe to import from a Server Component, Server Action, or
 * API route, not just client code.
 *
 * Source: insurer underwriting tables (Bajaj x 3 plans, Axis Max Life,
 * ICICI Prudential, HDFC Life). Each plan exposes a multiplierFor({ age,
 * annualIncome }) function returning the Multiples-of-Income value at that
 * age (or null if the plan has no entry for that age / income tier).
 *
 * `appliesTo` is 'resident' | 'nri' | 'both' and controls which residency
 * the plan participates in. Bajaj's NRI plan only fires for NRI leads; its
 * two domestic plans only fire for residents.
 */

type AppliesTo = Residency | "both";

interface AgeBand {
  min: number;
  max: number;
  multiplier: number;
}

const inAgeBand = (age: number, bands: readonly AgeBand[]): number | null => {
  for (const b of bands) {
    if (age >= b.min && age <= b.max) return b.multiplier;
  }
  return null;
};

export interface EligibilityPlanInput {
  age: number;
  annualIncome: number;
}

export interface EligibilityPlan {
  name: string;
  brand: string;
  appliesTo: AppliesTo;
  multiplierFor: (input: EligibilityPlanInput) => number | null;
}

// Bajaj Life i secure II (Table 1) — domestic.
const BAJAJ_I_SECURE_II: EligibilityPlan = {
  name: "Bajaj i secure II",
  brand: "Bajaj Life",
  appliesTo: "resident",
  multiplierFor: ({ age }) =>
    inAgeBand(age, [
      { min: 18, max: 35, multiplier: 25 },
      { min: 36, max: 40, multiplier: 20 },
      { min: 41, max: 45, multiplier: 15 },
      { min: 46, max: 50, multiplier: 12 },
      { min: 51, max: 55, multiplier: 10 },
      { min: 56, max: 60, multiplier: 5 },
      { min: 61, max: 65, multiplier: 3 },
    ]),
};

// Bajaj (Table 2) — NRI. Most generous of the three Bajaj plans, used only
// for NRI leads.
const BAJAJ_NRI: EligibilityPlan = {
  name: "Bajaj (NRI)",
  brand: "Bajaj Life",
  appliesTo: "nri",
  multiplierFor: ({ age }) =>
    inAgeBand(age, [
      { min: 18, max: 35, multiplier: 35 },
      { min: 36, max: 40, multiplier: 30 },
      { min: 41, max: 45, multiplier: 25 },
      { min: 46, max: 50, multiplier: 20 },
      { min: 51, max: 55, multiplier: 15 },
      { min: 56, max: 60, multiplier: 10 },
      { min: 61, max: 65, multiplier: 5 },
    ]),
};

// Bajaj (Table 3) — domestic. Same shape as i secure II but with a single
// 56-65 tail band (no split between 56-60 and 61-65).
const BAJAJ_OTHER: EligibilityPlan = {
  name: "Bajaj (plan III)",
  brand: "Bajaj Life",
  appliesTo: "resident",
  multiplierFor: ({ age }) =>
    inAgeBand(age, [
      { min: 18, max: 35, multiplier: 25 },
      { min: 36, max: 40, multiplier: 20 },
      { min: 41, max: 45, multiplier: 15 },
      { min: 46, max: 50, multiplier: 12 },
      { min: 51, max: 55, multiplier: 10 },
      { min: 56, max: 65, multiplier: 5 },
    ]),
};

// Axis Max Life (Table 4) — income-split. Above Rs 4.5L income gets the
// generous column; below Rs 4.5L only covers the first two age bands.
const AXIS_MAX_LIFE: EligibilityPlan = {
  name: "Axis Max Life",
  brand: "Axis Max Life",
  appliesTo: "both",
  multiplierFor: ({ age, annualIncome }) => {
    const incomeAbove45L = (Number(annualIncome) || 0) >= 450000;
    if (incomeAbove45L) {
      return inAgeBand(age, [
        { min: 18, max: 35, multiplier: 25 },
        { min: 36, max: 40, multiplier: 20 },
        { min: 41, max: 45, multiplier: 20 },
        { min: 46, max: 50, multiplier: 15 },
        { min: 51, max: 60, multiplier: 10 },
        { min: 61, max: 100, multiplier: 5 },
      ]);
    }
    // Below Rs 4.5L: only the first two age bands have an entry.
    return inAgeBand(age, [
      { min: 18, max: 35, multiplier: 17 },
      { min: 36, max: 40, multiplier: 12 },
    ]);
  },
};

// ICICI Prudential (Table 5).
const ICICI_PRUDENTIAL: EligibilityPlan = {
  name: "ICICI Prudential",
  brand: "ICICI Prudential",
  appliesTo: "both",
  multiplierFor: ({ age }) =>
    inAgeBand(age, [
      { min: 18, max: 30, multiplier: 35 },
      { min: 31, max: 35, multiplier: 30 },
      { min: 36, max: 40, multiplier: 25 },
      { min: 41, max: 45, multiplier: 20 },
      { min: 46, max: 50, multiplier: 15 },
      { min: 51, max: 55, multiplier: 10 },
      { min: 56, max: 100, multiplier: 5 },
    ]),
};

// HDFC Life (Table 6).
const HDFC_LIFE: EligibilityPlan = {
  name: "HDFC Life",
  brand: "HDFC Life",
  appliesTo: "both",
  multiplierFor: ({ age }) =>
    inAgeBand(age, [
      { min: 18, max: 30, multiplier: 35 },
      { min: 31, max: 35, multiplier: 30 },
      { min: 36, max: 40, multiplier: 25 },
      { min: 41, max: 45, multiplier: 20 },
      { min: 46, max: 50, multiplier: 15 },
      { min: 51, max: 55, multiplier: 10 },
      { min: 56, max: 100, multiplier: 5 },
    ]),
};

export const ELIGIBILITY_PLANS: readonly EligibilityPlan[] = [
  BAJAJ_I_SECURE_II,
  BAJAJ_NRI,
  BAJAJ_OTHER,
  AXIS_MAX_LIFE,
  ICICI_PRUDENTIAL,
  HDFC_LIFE,
];

// Logo files already shipped in public/logos/ for the same four brands this
// table covers (see components/steps/insurer-comparison-table.tsx, which
// notes two have mismatched-but-fine extensions — plain <img>, not next/image).
const BRAND_LOGOS: Record<string, string> = {
  "Bajaj Life": "/logos/bajaj.png",
  "Axis Max Life": "/logos/axis-max.png",
  "ICICI Prudential": "/logos/icici.png",
  "HDFC Life": "/logos/hdfc.png",
};

export interface PerInsurerEntry {
  brand: string;
  name: string;
  multiplier: number;
  amount: number;
  logo: string | null;
}

export interface MaxEligibilityRange {
  min: number | null;
  max: number | null;
  perInsurer: PerInsurerEntry[];
}

export interface ComputeMaxEligibilityRangeInput {
  /** Lead age (whole years). */
  age: number | string;
  /** Annual income in rupees. */
  annualIncome: number | string;
  /** 'resident' | 'nri' — anything else is treated as resident for the purpose of selecting Bajaj plans. */
  residency?: string;
}

/**
 * Compute the max-eligibility figures for a lead. Plans are collapsed by
 * insurer brand: when a brand has multiple plans (e.g. Bajaj has three),
 * only the winning plan's amount is reported. The range `min` / `max` are
 * computed off the deduped per-brand list, so they reflect "min and max
 * across insurers", not "min and max across plans".
 *
 * `min` / `max` are in rupees, null when no plan applies (e.g. lead is
 * under 18 or over 65, or income is blank/zero). `perInsurer` carries one
 * entry per insurer brand (the winning plan), sorted ascending by amount.
 */
export function computeMaxEligibilityRange({
  age,
  annualIncome,
  residency,
}: ComputeMaxEligibilityRangeInput): MaxEligibilityRange {
  const safeAge = Number(age);
  const safeIncome = Number(annualIncome);
  if (!Number.isFinite(safeAge) || !Number.isFinite(safeIncome) || safeIncome <= 0) {
    return { min: null, max: null, perInsurer: [] };
  }
  const residencyKey: Residency = residency === "nri" ? "nri" : "resident";

  // Evaluate every applicable plan, then dedupe by brand keeping the max
  // amount for each. Sort the deduped list ascending by amount.
  const byBrand = new Map<string, PerInsurerEntry>();
  for (const plan of ELIGIBILITY_PLANS) {
    if (plan.appliesTo !== "both" && plan.appliesTo !== residencyKey) continue;
    const m = plan.multiplierFor({ age: safeAge, annualIncome: safeIncome });
    if (typeof m !== "number" || !Number.isFinite(m) || m <= 0) continue;
    const amount = m * safeIncome;
    const existing = byBrand.get(plan.brand);
    if (!existing || amount > existing.amount) {
      byBrand.set(plan.brand, {
        brand: plan.brand,
        name: plan.name,
        multiplier: m,
        amount,
        logo: BRAND_LOGOS[plan.brand] ?? null,
      });
    }
  }
  const perInsurer = Array.from(byBrand.values()).sort((a, b) => a.amount - b.amount);
  if (perInsurer.length === 0) return { min: null, max: null, perInsurer: [] };

  return {
    min: perInsurer[0]!.amount,
    max: perInsurer[perInsurer.length - 1]!.amount,
    perInsurer,
  };
}

export type EligibilityCase = "over" | "within" | "under";

/**
 * Categorise a cover amount against a computed eligibility range. 'over'
 * when the cover exceeds even the most generous insurer, 'within' when it
 * falls inside the range, 'under' when it's below the most conservative
 * insurer. Returns null when the range hasn't been computed yet (age/income
 * not filled, or no plan applies at all).
 */
export function classifyCoverVsEligibilityRange(
  cover: number,
  range: MaxEligibilityRange | null | undefined,
): EligibilityCase | null {
  if (!range || range.min == null || range.max == null) return null;
  if (cover > range.max) return "over";
  if (cover < range.min) return "under";
  return "within";
}
