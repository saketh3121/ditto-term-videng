import { COVER_DISCOUNT_RATE, DEFAULT_INFLATION_RATE, PROJECTION_END_AGE } from "@/config/milestone-assumptions";

/**
 * Pure expense projection model. No React, no DOM — unit-testable in
 * isolation and safe to import from Server Components.
 *
 * Simplified projection: monthly expenses inflated at a flat rate per year,
 * from the user's current age through a caller-supplied end age. An optional
 * milestone overlay bumps the running expense multiplicatively at specific
 * ages — this is the year-by-year sibling of milestone-expense-projection.ts's
 * bar-sampled engine; the two must agree exactly at any shared milestone age
 * (SPEC.md §6).
 */

export interface MilestoneOverlay {
  age: number;
  multiplier: number;
}

export interface ProjectExpensesInput {
  /** Parent's current age (whole years). */
  currentAge: number;
  /** Current monthly lifestyle expense in INR. */
  monthlyExpense: number;
  /** Last age included in the projection. Defaults to PROJECTION_END_AGE. */
  endAge?: number;
  /** Each milestone fires once at its age, multiplying the running expense. Defaults to []. */
  milestones?: MilestoneOverlay[];
  /** Annual expense inflation. Defaults to DEFAULT_INFLATION_RATE. */
  inflationRate?: number;
}

export interface ProjectionRow {
  age: number;
  monthly: number;
  annual: number;
}

export interface ProjectExpensesResult {
  rows: ProjectionRow[];
  peak: ProjectionRow;
  endAge: number;
}

/**
 * Project monthly + annual expenses from `currentAge` through `endAge`,
 * inflated at a flat rate per year, with optional milestone multipliers
 * applied at specific ages. Milestone multipliers are applied BEFORE the row
 * at that age is recorded, so a milestone at age X visibly bumps the bar at
 * X — matching the bar chart's compounding rule (see cross-check invariant,
 * SPEC.md §6).
 */
export function projectExpenses({
  currentAge,
  monthlyExpense,
  endAge,
  milestones = [],
  inflationRate = DEFAULT_INFLATION_RATE,
}: ProjectExpensesInput): ProjectExpensesResult {
  const requested = typeof endAge === "number" && Number.isFinite(endAge) ? endAge : PROJECTION_END_AGE;
  const finalEndAge = Math.max(currentAge, Math.round(requested));
  const milestoneByAge = new Map<number, number>(
    milestones.map((m) => [Math.round(m.age), Number(m.multiplier) || 1]),
  );

  const rows: ProjectionRow[] = [];
  let expense = monthlyExpense;
  for (let a = currentAge; a <= finalEndAge; a++) {
    const mult = milestoneByAge.get(a);
    if (mult) expense *= mult;
    const monthly = expense;
    rows.push({ age: a, monthly: Math.round(monthly), annual: Math.round(monthly * 12) });
    expense *= 1 + inflationRate;
  }

  const last: ProjectionRow = rows[rows.length - 1] ?? { age: currentAge, monthly: 0, annual: 0 };

  return { rows, peak: last, endAge: finalEndAge };
}

export interface ComputeIdealCoverInput {
  currentAge: number;
  /** Today's monthly expense. */
  monthlyExpense: number;
  /** Last age included in the projection. */
  horizonEndAge: number;
  milestones?: MilestoneOverlay[];
  /** Death-age scenarios to evaluate. Defaults to [currentAge]. */
  scenarioAges?: number[];
  /** Fixed at 5% — deliberately NOT wired to inflationRate (see SPEC.md §8). */
  discountRate?: number;
  /** Defaults to DEFAULT_INFLATION_RATE. */
  inflationRate?: number;
}

/**
 * Multi-scenario ideal cover. For each hypothetical death age in
 * `scenarioAges`, computes the NPV at `discountRate` of the family's annual
 * expenses from that death age through the horizon, and returns the maximum
 * (the worst case is not always "dying today" once a milestone step-up is in
 * play, so every candidate age is brute-forced — SPEC.md §8).
 *
 * @returns Cover amount in INR (unrounded — round to your own denomination).
 */
function annualExpenseByAge(
  currentAge: number,
  monthlyExpense: number,
  finalHorizon: number,
  milestones: MilestoneOverlay[],
  inflationRate: number,
): Map<number, number> {
  const milestoneByAge = new Map<number, number>(
    milestones.map((m) => [Math.round(m.age), Number(m.multiplier) || 1]),
  );
  const annualByAge = new Map<number, number>();
  let expense = monthlyExpense;
  for (let a = currentAge; a <= finalHorizon; a++) {
    const mult = milestoneByAge.get(a);
    if (mult) expense *= mult;
    annualByAge.set(a, expense * 12);
    expense *= 1 + inflationRate;
  }
  return annualByAge;
}

/** NPV, as of claim age `death`, of every year's expense from `death` through `finalHorizon`. */
function npvFromClaimAge(annualByAge: Map<number, number>, death: number, finalHorizon: number, discountRate: number): number {
  let npv = 0;
  for (let t = death; t <= finalHorizon; t++) {
    npv += (annualByAge.get(t) ?? 0) / Math.pow(1 + discountRate, t - death);
  }
  return npv;
}

export function computeIdealCover({
  currentAge,
  monthlyExpense,
  horizonEndAge,
  milestones = [],
  scenarioAges,
  discountRate = COVER_DISCOUNT_RATE,
  inflationRate = DEFAULT_INFLATION_RATE,
}: ComputeIdealCoverInput): number {
  if (!Number.isFinite(monthlyExpense) || monthlyExpense <= 0) return 0;
  const finalHorizon = Math.max(currentAge, Math.round(horizonEndAge));
  const annualByAge = annualExpenseByAge(currentAge, monthlyExpense, finalHorizon, milestones, inflationRate);

  const validScenarios = (scenarioAges ?? [currentAge])
    .map((d) => Math.round(d))
    .filter((d) => d >= currentAge && d <= finalHorizon);
  const scenarios = validScenarios.length ? validScenarios : [currentAge];

  let best = 0;
  for (const death of scenarios) {
    const npv = npvFromClaimAge(annualByAge, death, finalHorizon, discountRate);
    if (npv > best) best = npv;
  }
  return best;
}

export interface NpvCurveRow {
  age: number;
  npv: number;
}

export interface NpvCurve {
  rows: NpvCurveRow[];
  /** Claim age with the greatest need — null when there's no expense to size against. */
  peakAge: number | null;
  peakNpv: number;
}

/**
 * Every per-claim-age NPV that computeIdealCover takes the max of, for each
 * age from `currentAge` through `horizonEndAge` — the "cover required if a
 * claim happened at this age" bell curve. Its peak equals computeIdealCover
 * evaluated over the same full range of scenario ages.
 */
export function computeNpvCurve({
  currentAge,
  monthlyExpense,
  horizonEndAge,
  milestones = [],
  discountRate = COVER_DISCOUNT_RATE,
  inflationRate = DEFAULT_INFLATION_RATE,
}: Omit<ComputeIdealCoverInput, "scenarioAges">): NpvCurve {
  if (!Number.isFinite(monthlyExpense) || monthlyExpense <= 0) return { rows: [], peakAge: null, peakNpv: 0 };
  const finalHorizon = Math.max(currentAge, Math.round(horizonEndAge));
  const annualByAge = annualExpenseByAge(currentAge, monthlyExpense, finalHorizon, milestones, inflationRate);

  const rows: NpvCurveRow[] = [];
  let peakAge: number | null = null;
  let peakNpv = 0;
  for (let death = currentAge; death <= finalHorizon; death++) {
    const npv = npvFromClaimAge(annualByAge, death, finalHorizon, discountRate);
    rows.push({ age: death, npv });
    if (npv > peakNpv) {
      peakNpv = npv;
      peakAge = death;
    }
  }
  return { rows, peakAge, peakNpv };
}
