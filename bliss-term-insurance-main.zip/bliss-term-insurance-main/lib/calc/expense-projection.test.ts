import { describe, expect, it } from "vitest";
import { computeIdealCover, computeNpvCurve, projectExpenses } from "./expense-projection";

// SPEC.md §10 Test B — currentAge=30, monthlyExpense=50000, tier1 bracket 1
// (firstChild x1.30, secondChild x1.22), inflationRate=0.05.
const FIRST_CHILD = { age: 33, multiplier: 1.3 };
const SECOND_CHILD = { age: 37, multiplier: 1.22 };

describe("projectExpenses — SPEC.md Test B", () => {
  const common = { currentAge: 30, monthlyExpense: 50_000, endAge: 38, inflationRate: 0.05 };

  it("base (no milestones) matches the expected rupee figures", () => {
    const { rows } = projectExpenses({ ...common, milestones: [] });
    const byAge = new Map(rows.map((r) => [r.age, r.monthly]));
    expect(byAge.get(30)).toBe(50_000);
    expect(byAge.get(33)).toBe(57_881);
    expect(byAge.get(35)).toBe(63_814);
    expect(byAge.get(37)).toBe(70_355);
    expect(byAge.get(38)).toBe(73_873);
  });

  it("next (+first child) matches the expected rupee figures", () => {
    const { rows } = projectExpenses({ ...common, milestones: [FIRST_CHILD] });
    const byAge = new Map(rows.map((r) => [r.age, r.monthly]));
    expect(byAge.get(30)).toBe(50_000);
    expect(byAge.get(33)).toBe(75_246);
    expect(byAge.get(35)).toBe(82_958);
    expect(byAge.get(37)).toBe(91_462);
    expect(byAge.get(38)).toBe(96_035);
  });

  it("all (+first & second child) matches the expected rupee figures", () => {
    const { rows } = projectExpenses({ ...common, milestones: [FIRST_CHILD, SECOND_CHILD] });
    const byAge = new Map(rows.map((r) => [r.age, r.monthly]));
    expect(byAge.get(30)).toBe(50_000);
    expect(byAge.get(33)).toBe(75_246);
    expect(byAge.get(35)).toBe(82_958);
    expect(byAge.get(37)).toBe(1_11_583);
    expect(byAge.get(38)).toBe(1_17_162);
  });

  it("cross-engine invariant: ages 33 and 37 match projectMilestoneBars' Test A bars exactly", async () => {
    const { projectMilestoneBars } = await import("./milestone-expense-projection");
    const { bars } = projectMilestoneBars({
      currentAge: 30,
      annualIncome: 12_00_000,
      currentMonthlyExpense: 50_000,
      tier: "tier1",
      inflationRate: 0.05,
      includedMilestones: { marriage: true, firstChild: true, secondChild: true },
    });
    const { rows } = projectExpenses({ ...common, milestones: [FIRST_CHILD, SECOND_CHILD] });
    const rowsByAge = new Map(rows.map((r) => [r.age, r.monthly]));
    for (const bar of bars) {
      if (bar.type !== "milestone") continue;
      expect(rowsByAge.get(bar.age)).toBe(bar.monthly);
    }
  });
});

describe("computeIdealCover — SPEC.md Test D (NPV flat-identity case)", () => {
  it("returns the exact NPV when inflationRate equals the discount rate", () => {
    const cover = computeIdealCover({
      currentAge: 30,
      monthlyExpense: 50_000,
      horizonEndAge: 32,
      milestones: [],
      scenarioAges: [30, 31, 32],
      inflationRate: 0.05,
    });
    expect(Math.round(cover)).toBe(18_00_000);
  });
});

describe("computeNpvCurve", () => {
  const input = { currentAge: 30, monthlyExpense: 1_00_000, horizonEndAge: 70 };

  it("has one row per claim age, current age through horizon", () => {
    const { rows } = computeNpvCurve(input);
    expect(rows).toHaveLength(41);
    expect(rows[0]!.age).toBe(30);
    expect(rows[rows.length - 1]!.age).toBe(70);
  });

  it("peaks at exactly the figure computeIdealCover sizes the cover against", () => {
    const scenarioAges = Array.from({ length: 41 }, (_, i) => 30 + i);
    const ideal = computeIdealCover({ ...input, scenarioAges });
    const { peakAge, peakNpv } = computeNpvCurve(input);
    expect(peakNpv).toBe(ideal);
    expect(peakAge).toBe(50);
  });

  it("is empty with no peak when there is no expense", () => {
    expect(computeNpvCurve({ ...input, monthlyExpense: 0 })).toEqual({ rows: [], peakAge: null, peakNpv: 0 });
  });
});
