import { describe, it, expect } from "vitest";
import { computeBasicCoverSummary, computeCover, formatRupees, sampleProjectionByInterval } from "./cover";

describe("computeCover", () => {
  it("derives term as retirementAge - age, floored at the minimum", () => {
    expect(computeCover({ age: 30, monthlyExpense: 50_000 }).termYears).toBe(30);
    // age 58 -> 2 years, below the 5-year floor
    expect(computeCover({ age: 58, monthlyExpense: 50_000 }).termYears).toBe(5);
  });

  it("produces one projection point per policy year, plus the tenure's target age", () => {
    const { termYears, projection } = computeCover({
      age: 40,
      monthlyExpense: 40_000,
    });
    expect(projection).toHaveLength(termYears + 1);
    expect(projection[0]!.year).toBe(1);
  });

  it("always ends the projection on the tenure's target age", () => {
    const withTarget = computeCover({ age: 36, monthlyExpense: 40_000, targetAge: 60 });
    expect(withTarget.projection[withTarget.projection.length - 1]!.age).toBe(60);

    const withDefault = computeCover({ age: 30, monthlyExpense: 40_000 }); // no targetAge -> retirementAge 60
    expect(withDefault.projection[withDefault.projection.length - 1]!.age).toBe(60);
  });

  it("inflates expenses year over year (monotonically increasing)", () => {
    const { projection } = computeCover({ age: 35, monthlyExpense: 30_000 });
    for (let i = 1; i < projection.length; i++) {
      expect(projection[i]!.annualExpense).toBeGreaterThan(
        projection[i - 1]!.annualExpense,
      );
    }
  });

  it("rounds the recommended cover to the nearest ₹10L", () => {
    const { coverAmount } = computeCover({ age: 30, monthlyExpense: 50_000 });
    expect(coverAmount % 1_000_000).toBe(0);
  });

  it("floors the recommended cover at ₹50L even for a trivially small NPV", () => {
    const { coverAmount } = computeCover({ age: 58, monthlyExpense: 100 }); // floored 5-yr term, tiny expense
    expect(coverAmount).toBe(5_000_000);
  });

  it("honors a customer-chosen target age instead of the fixed retirement-age default", () => {
    const default60 = computeCover({ age: 24, monthlyExpense: 80_000 });
    const target65 = computeCover({ age: 24, monthlyExpense: 80_000, targetAge: 65 });
    expect(default60.termYears).toBe(36); // 60 - 24
    expect(target65.termYears).toBe(41); // 65 - 24
    // A longer horizon means a larger worst-case NPV, so the cover figure must increase too.
    expect(target65.coverAmount).toBeGreaterThan(default60.coverAmount);
  });

  it("ignores an out-of-range target age (at or before current age) and falls back to the default", () => {
    const withInvalidTarget = computeCover({ age: 30, monthlyExpense: 50_000, targetAge: 25 });
    const withoutTarget = computeCover({ age: 30, monthlyExpense: 50_000 });
    expect(withInvalidTarget.termYears).toBe(withoutTarget.termYears);
    expect(withInvalidTarget.coverAmount).toBe(withoutTarget.coverAmount);
  });
});

describe("computeBasicCoverSummary", () => {
  it("adds uninsured loans and subtracts existing cover, each rounded up to ₹5L", () => {
    const s = computeBasicCoverSummary({ age: 30, monthlyExpense: 1_00_000, targetAge: 70, uninsuredLoans: 21_00_000, existingCover: 48_00_000 });
    expect(s.coverAmount).toBe(6_70_00_000);
    expect(s.loansRounded).toBe(25_00_000);
    expect(s.existingRounded).toBe(50_00_000);
    expect(s.purchaseNow).toBe(6_70_00_000 + 25_00_000 - 50_00_000);
  });

  it("never goes below zero when existing cover exceeds the need", () => {
    const s = computeBasicCoverSummary({ age: 30, monthlyExpense: 10_000, uninsuredLoans: 0, existingCover: 50_00_00_000 });
    expect(s.purchaseNow).toBe(0);
  });

  it("reports the cover-until age it sized against", () => {
    expect(computeBasicCoverSummary({ age: 30, monthlyExpense: 50_000, targetAge: 70, uninsuredLoans: 0, existingCover: 0 }).coverUntilAge).toBe(70);
    expect(computeBasicCoverSummary({ age: 30, monthlyExpense: 50_000, uninsuredLoans: 0, existingCover: 0 }).coverUntilAge).toBe(60);
  });
});

describe("sampleProjectionByInterval", () => {
  it("keeps every 10th year plus the final year, even off-interval", () => {
    const { projection } = computeCover({ age: 36, monthlyExpense: 40_000, targetAge: 60 }); // ages 36-60 inclusive
    const sampled = sampleProjectionByInterval(projection, 10);
    expect(sampled.map((p) => p.age)).toEqual([36, 46, 56, 60]);
  });

  it("doesn't duplicate the final year when it already lands on an interval", () => {
    const { projection } = computeCover({ age: 30, monthlyExpense: 40_000, targetAge: 50 }); // ages 30-50 inclusive
    const sampled = sampleProjectionByInterval(projection, 10);
    expect(sampled.map((p) => p.age)).toEqual([30, 40, 50]);
  });

  it("keeps only the start and end year for a tenure shorter than the interval", () => {
    const { projection } = computeCover({ age: 58, monthlyExpense: 40_000 }); // floored to 5-year minimum
    const sampled = sampleProjectionByInterval(projection, 10);
    expect(sampled.map((p) => p.age)).toEqual([projection[0]!.age, projection[projection.length - 1]!.age]);
  });

  it("returns an empty array for an empty projection", () => {
    expect(sampleProjectionByInterval([], 10)).toEqual([]);
  });
});

describe("formatRupees", () => {
  it("formats crores, lakhs, and plain values, all rounded to 1 decimal", () => {
    expect(formatRupees(15_000_000)).toBe("₹1.5 Cr");
    expect(formatRupees(7_500_000)).toBe("₹75.0 L");
    expect(formatRupees(5_000)).toBe("₹5,000");
  });

  it("rounds an exact .x5 Cr boundary consistently (not at the mercy of toFixed's binary float quirks)", () => {
    // 1.65 Cr naively (value / 1e7).toFixed(1) renders "1.6" — the double
    // closest to 1.65 sits fractionally under it. Rounding on the integer
    // number of 10-lakh units first (16500000 / 1000000 = 16.5, exactly
    // representable) makes the tie resolve deterministically upward instead.
    expect(formatRupees(16_500_000)).toBe("₹1.7 Cr");
    // ...and stays internally consistent with a sum built from these parts:
    // base (1.65 Cr) + loans (0.70 Cr) = 2.35 Cr, which should display as
    // the same "1.7 Cr" + "70.0 L" -> "2.4 Cr" a reader would expect to add up.
    expect(formatRupees(16_500_000 + 7_000_000)).toBe("₹2.4 Cr");
  });
});
