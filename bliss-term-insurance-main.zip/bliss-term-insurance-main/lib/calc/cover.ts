import { ASSUMPTIONS } from "@/config/assumptions";
import { BASIC_COVER_FLOOR, BASIC_COVER_ROUNDING, COVER_ROUNDING, DEFAULT_INFLATION_RATE } from "@/config/milestone-assumptions";
import { computeIdealCover } from "@/lib/calc/expense-projection";

/**
 * Pure cover-amount logic. No React, no I/O — just numbers in, numbers out.
 * Because it's pure it is trivially unit-testable (see cover.test.ts), so the
 * financial math can never silently regress inside a 1,400-line page.
 *
 * Basic mode shares its NPV engine with expense-projection.ts's
 * computeIdealCover (Advanced mode's zero-milestone base case) — a term sum
 * assured is a fixed nominal amount, so "enough cover" has to hold no matter
 * which future year the claim actually lands in, not just if death happens
 * today. Sizing off "die today" alone understates the true worst case:
 * inflation keeps eroding a fixed nominal payout while the remaining term
 * shrinks, and those two effects don't peak at the same age.
 *
 * 1. Project every year's expense from today (year 0, unmultiplied) through
 *    the "cover until" age, inclusive — each following year ×(1 + inflation)
 *    — for the projection chart.
 * 2. Ask computeIdealCover for the worst-case NPV across every possible
 *    death age from today through the horizon (no milestones in Basic mode).
 * 3. Round to the nearest BASIC_COVER_ROUNDING, floored at BASIC_COVER_FLOOR.
 */

export interface CoverInputs {
  /** Current age of the applicant, in years. */
  age: number;
  /** Approximate current monthly expenses, in rupees. */
  monthlyExpense: number;
  /** Age until which cover should run (the Control Panel's "Preferred age of cover"). Defaults to ASSUMPTIONS.retirementAge when omitted. */
  targetAge?: number;
}

export interface CoverResult {
  /** The Control Panel's "Preferred age of cover" when valid, else ASSUMPTIONS.retirementAge. */
  coverUntilAge: number;
  /** Last age in the projection/NPV horizon — max(age, coverUntilAge). */
  horizonEndAge: number;
  /** Policy term in years (coverUntilAge − age, floored at ASSUMPTIONS.minPolicyTerm). */
  termYears: number;
  /** Suggested cover, in rupees, rounded to the nearest BASIC_COVER_ROUNDING (floored at BASIC_COVER_FLOOR). */
  coverAmount: number;
  /** Year-by-year inflated annual expense, for the projection chart. `age` runs from the applicant's current age through the "cover until" age (Control Panel's "Preferred age of cover", or the default retirement age), inclusive. */
  projection: { year: number; age: number; annualExpense: number }[];
}

const LAKH = 100_000;

export function computeCover({ age, monthlyExpense, targetAge }: CoverInputs): CoverResult {
  const coverUntilAge =
    typeof targetAge === "number" && Number.isFinite(targetAge) && targetAge > age
      ? targetAge
      : ASSUMPTIONS.retirementAge;
  const termYears = Math.max(ASSUMPTIONS.minPolicyTerm, coverUntilAge - age);
  const horizonEndAge = Math.max(age, coverUntilAge);

  // Step 1 — project every year's expense, year 0 = today's (unmultiplied),
  // each following year ×(1 + inflation), through horizonEndAge inclusive.
  // Chart-only; the NPV itself is computed below via computeIdealCover.
  const projection: CoverResult["projection"] = [];
  let expense = monthlyExpense * 12;
  for (let a = age; a <= horizonEndAge; a++) {
    projection.push({ year: a - age + 1, age: a, annualExpense: Math.round(expense) });
    expense *= 1 + DEFAULT_INFLATION_RATE;
  }

  // Step 2 — worst-case NPV across every possible death age (no milestones).
  const scenarioAges: number[] = [];
  for (let a = age; a <= horizonEndAge; a++) scenarioAges.push(a);
  const npv = computeIdealCover({
    currentAge: age,
    monthlyExpense,
    horizonEndAge,
    milestones: [],
    scenarioAges,
  });

  // Step 3 — round to the nearest ₹10L, floored at ₹50L.
  const coverAmount = Math.max(Math.round(npv / BASIC_COVER_ROUNDING) * BASIC_COVER_ROUNDING, BASIC_COVER_FLOOR);

  return { coverUntilAge, horizonEndAge, termYears, coverAmount, projection };
}

/** Rounds up to the next COVER_ROUNDING (₹5L) — used for uninsured loans and existing cover. */
export function roundUpToCoverUnit(amount: number): number {
  if (!Number.isFinite(amount) || amount <= 0) return 0;
  return Math.ceil(amount / COVER_ROUNDING) * COVER_ROUNDING;
}

export interface BasicCoverSummaryInputs extends CoverInputs {
  uninsuredLoans: number;
  existingCover: number;
}

export interface BasicCoverSummary extends CoverResult {
  loansRounded: number;
  existingRounded: number;
  /** Suggested cover + uninsured loans − existing cover, never below 0 — the "purchase now" headline. */
  purchaseNow: number;
}

/** Everything the Basic Cover Amount screen shows — also what the customer summary PDF prints. */
export function computeBasicCoverSummary({
  uninsuredLoans,
  existingCover,
  ...coverInputs
}: BasicCoverSummaryInputs): BasicCoverSummary {
  const cover = computeCover(coverInputs);
  const loansRounded = roundUpToCoverUnit(uninsuredLoans);
  const existingRounded = roundUpToCoverUnit(existingCover);
  return {
    ...cover,
    loansRounded,
    existingRounded,
    purchaseNow: Math.max(0, cover.coverAmount + loansRounded - existingRounded),
  };
}

/**
 * Thins a year-by-year projection down to one bar every `intervalYears`
 * (starting from the first entry), always keeping the final year of the
 * tenure even when it doesn't land on an interval boundary — so a chart
 * built from this still reads as "start → every N years → end" instead of
 * stopping short of maturity.
 */
export function sampleProjectionByInterval(
  projection: CoverResult["projection"],
  intervalYears = 10,
): CoverResult["projection"] {
  if (projection.length === 0) return [];
  const sampled = projection.filter((_, i) => i % intervalYears === 0);
  const last = projection[projection.length - 1]!;
  if (sampled[sampled.length - 1] !== last) sampled.push(last);
  return sampled;
}

/**
 * Format rupees as a compact Indian-style label, e.g. ₹1.5 Cr / ₹7.5 L.
 *
 * Rounds via integer division first (nearest 10L for the Cr branch, nearest
 * 10K for the L branch) rather than `(value / unit).toFixed(1)` directly —
 * naive toFixed on a value that lands exactly on a .x5 boundary (e.g.
 * 1.65 Cr) is at the mercy of that number's binary floating-point
 * representation, which can round either up or down inconsistently between
 * two values that are otherwise mathematically related (e.g. a suggested
 * cover of ₹1.65 Cr plus ₹0.70 Cr in loans totalling exactly ₹2.35 Cr could
 * display as "1.6 Cr" + "70.0 L" not visibly summing to "2.4 Cr"). Rounding
 * on an integer first makes the decision deterministic (ties round up).
 */
export function formatRupees(value: number): string {
  if (value >= 1_00_00_000) return `₹${(Math.round(value / 1_000_000) / 10).toFixed(1)} Cr`;
  if (value >= LAKH) return `₹${(Math.round(value / 10_000) / 10).toFixed(1)} L`;
  return `₹${value.toLocaleString("en-IN")}`;
}
