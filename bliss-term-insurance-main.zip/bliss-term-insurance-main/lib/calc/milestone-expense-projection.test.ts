import { describe, expect, it } from "vitest";
import { computeIdealTenureEndAge, projectMilestoneBars } from "./milestone-expense-projection";

// Common inputs from SPEC.md §10. currentAge=30, bracket 1 (₹5-15L),
// monthlyExpense=50000, tier1, inflationRate=0.05. Marriage (29) is already
// past for a 30-year-old and produces nothing regardless of checkbox state.
const BASE = {
  currentAge: 30,
  annualIncome: 12_00_000,
  currentMonthlyExpense: 50_000,
  tier: "tier1" as const,
  inflationRate: 0.05,
  includedMilestones: { marriage: true, firstChild: true, secondChild: true },
};

describe("projectMilestoneBars — SPEC.md Test A", () => {
  it("produces Today/First child/Second child bars at the exact expected rupee figures", () => {
    const { bars } = projectMilestoneBars(BASE);
    expect(bars.map((b) => [b.age, b.monthly])).toEqual([
      [30, 50_000],
      [33, 75_246],
      [37, 1_11_583],
    ]);
  });
});

describe("projectMilestoneBars — SPEC.md Test C (personal goals overlay)", () => {
  it("adds a standalone goals bar and layers goals onto the second-child bar without changing lifestyle", () => {
    const { bars } = projectMilestoneBars({
      ...BASE,
      personalGoals: { included: true, age: 35, monthlyAmount: 20_000 },
    });

    const goalsBar = bars.find((b) => b.age === 35);
    expect(goalsBar?.monthly).toBe(1_08_484);

    const secondChildBar = bars.find((b) => b.age === 37);
    expect(secondChildBar?.monthly).toBe(1_39_725);
    // Lifestyle component at age 37 is unchanged from Test A (111,583) —
    // the goals overlay never alters the milestone-multiplier chain.
    expect(secondChildBar?.lifestyleMonthly).toBe(1_11_583);
  });
});

describe("projectMilestoneBars — milestone filtering", () => {
  it("excludes past milestones (marriage at 29 for a 30-year-old) regardless of checked state", () => {
    const { bars, activeMilestones } = projectMilestoneBars(BASE);
    expect(bars.some((b) => b.key === "marriage")).toBe(false);
    expect(activeMilestones.map((m) => m.key)).toEqual(["firstChild", "secondChild"]);
  });

  it("excludes an unchecked future milestone", () => {
    const { bars } = projectMilestoneBars({
      ...BASE,
      includedMilestones: { marriage: true, firstChild: true, secondChild: false },
    });
    expect(bars.map((b) => b.age)).toEqual([30, 33]);
  });
});

describe("computeIdealTenureEndAge — SPEC.md §7", () => {
  it("anchors off the youngest checked kid when only first child is checked", () => {
    // youngest=33 -> rawMin=58, rawMax=63 -> midpoint=60.5 -> snapped=60
    const range = computeIdealTenureEndAge({ firstChild: true, secondChild: false });
    expect(range).toEqual({ min: 60, max: 65 });
  });

  it("anchors off the youngest (later) kid when both are checked", () => {
    // youngest=37 -> rawMin=62, rawMax=67 -> midpoint=64.5 -> snapped=65
    const range = computeIdealTenureEndAge({ firstChild: true, secondChild: true });
    expect(range).toEqual({ min: 65, max: 70 });
  });

  it("falls back to the preferred cover age when no kid milestone is checked", () => {
    const range = computeIdealTenureEndAge({ firstChild: false, secondChild: false }, {}, 55);
    expect(range).toEqual({ min: 55, max: 60 });
  });

  it("falls back to PROJECTION_END_AGE (60) when no kid milestone and no preferred age given", () => {
    const range = computeIdealTenureEndAge({ firstChild: false, secondChild: false });
    expect(range).toEqual({ min: 60, max: 65 });
  });

  it("respects custom milestone ages when computing the youngest kid", () => {
    // custom firstChild=40 -> rawMin=65, rawMax=70 -> midpoint=67.5 -> round(13.5)=14 -> snapped=70
    const range = computeIdealTenureEndAge({ firstChild: true, secondChild: false }, { firstChild: 40 });
    expect(range).toEqual({ min: 70, max: 75 });
  });
});
