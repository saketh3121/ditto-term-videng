/**
 * Pure age derivation. No React, no I/O — an ISO date-of-birth in, whole years
 * out. Isolated in lib/calc with unit tests so the number that drives cover and
 * eligibility downstream can never silently regress.
 */

/**
 * Whole years from an ISO date-of-birth ("YYYY-MM-DD") to `today`.
 * Returns null for empty, unparseable, or out-of-range (future / >130) input.
 */
export function ageFromDob(dob: string, today: Date = new Date()): number | null {
  if (!dob) return null;
  const born = new Date(`${dob}T00:00:00`);
  if (Number.isNaN(born.getTime())) return null;

  let age = today.getFullYear() - born.getFullYear();
  const monthDelta = today.getMonth() - born.getMonth();
  if (monthDelta < 0 || (monthDelta === 0 && today.getDate() < born.getDate())) {
    age--;
  }

  if (age < 0 || age > 130) return null;
  return age;
}
