import {
  DEFAULT_INFLATION_RATE,
  DEFAULT_MILESTONE_AGES,
  KID_INDEPENDENCE_MAX,
  KID_INDEPENDENCE_MIN,
  MILESTONE_MULTIPLIERS,
  MILESTONES,
  PERSONAL_GOALS_BASE_MONTHLY,
  PROJECTION_END_AGE,
  type IncludedMilestones,
  type MilestoneAges,
  type MilestoneKey,
  type Tier,
} from "@/config/milestone-assumptions";

/**
 * Income-bracket / milestone-driven expense projection used by the milestone
 * bar chart. Pure — no React, no DOM — safe to import from Server Components
 * and unit-testable in isolation.
 *
 * Walks integer ages from currentAge through PROJECTION_END_AGE. At each
 * milestone age strictly greater than currentAge, the running monthly
 * expense is multiplied by a tier x income-bracket multiplier. Between
 * milestones the expense compounds at `inflationRate`.
 */

export function incomeBracketIndex(annualIncome: number): 0 | 1 | 2 | 3 | 4 {
  if (annualIncome < 5_00_000) return 0;
  if (annualIncome < 15_00_000) return 1;
  if (annualIncome < 30_00_000) return 2;
  if (annualIncome < 50_00_000) return 3;
  return 4;
}

export const INCOME_BRACKET_LABELS = Object.freeze([
  "<₹5L",
  "₹5-15L",
  "₹15-30L",
  "₹30-50L",
  "₹50L+",
] as const);

/** Returns the effective age for a milestone — custom override if set, else default. */
export function effectiveMilestoneAge(
  key: MilestoneKey,
  customMilestoneAges: Partial<MilestoneAges> = {},
): number {
  const custom = customMilestoneAges[key];
  if (Number.isFinite(Number(custom))) return Number(custom);
  return DEFAULT_MILESTONE_AGES[key];
}

/**
 * Default checkbox state for the milestone bar chart: only the chronologically
 * next future milestone is included; everything else is off. Re-evaluate each
 * time the user's current age changes.
 */
export function defaultIncludedFromAge(
  currentAge: number,
  customMilestoneAges: Partial<MilestoneAges> = {},
): IncludedMilestones {
  const result: IncludedMilestones = { marriage: false, firstChild: false, secondChild: false };
  const ordered = MILESTONES.map((m) => ({ key: m.key, age: effectiveMilestoneAge(m.key, customMilestoneAges) })).sort(
    (a, b) => a.age - b.age,
  );
  const next = ordered.find((m) => m.age > currentAge);
  if (next) result[next.key] = true;
  return result;
}

export interface PersonalGoalsInput {
  included: boolean;
  age: number | null;
  /** Runtime also sees '' while the field is mid-edit; treated as "unset". */
  monthlyAmount?: number | "";
}

export interface ProjectMilestoneBarsInput {
  currentAge: number;
  /** Gross rupees per year. Used only to pick the income bracket. */
  annualIncome: number;
  /** Rupees per month. */
  currentMonthlyExpense: number;
  tier: Tier;
  /** Annual expense inflation, applied between bars. Defaults to DEFAULT_INFLATION_RATE. */
  inflationRate?: number;
  /** Map of milestone key -> included flag. Missing keys are treated as included. */
  includedMilestones?: Partial<IncludedMilestones>;
  personalGoals?: PersonalGoalsInput;
  customMilestoneAges?: Partial<MilestoneAges>;
}

export type ProjectionBarType = "today" | "milestone" | "goals";

export interface ProjectionBar {
  key: string;
  label: string;
  age: number;
  monthly: number;
  lifestyleMonthly: number;
  goalsMonthly: number;
  multiplier?: number;
  type: ProjectionBarType;
}

export interface ActiveMilestone {
  key: MilestoneKey;
  label: string;
  age: number;
  multiplier: number;
  type: "milestone";
}

interface GoalsAnchor {
  key: "personalGoals";
  label: string;
  age: number;
  type: "goals";
}

type Anchor = ActiveMilestone | GoalsAnchor;

export interface ProjectMilestoneBarsResult {
  bars: ProjectionBar[];
  activeMilestones: ActiveMilestone[];
  bracketIndex: 0 | 1 | 2 | 3 | 4;
  goalsActive: boolean;
  goalsAge: number | null;
}

/**
 * Sample expense at "Today" plus each checked future milestone, applying
 * compound inflation between sample points and the milestone multiplier at
 * each fire. Used by the milestone bar chart.
 *
 * `lifestyle` is kept at full float precision across the whole loop — only
 * the value pushed into `bars` is rounded. Each subsequent anchor compounds
 * off the *unrounded* figure; don't "clean up" this by reassigning lifestyle
 * to a rounded value, it will drift from expense-projection.ts's output at
 * shared milestone ages (see SPEC.md §6 cross-check invariant).
 */
export function projectMilestoneBars({
  currentAge,
  annualIncome,
  currentMonthlyExpense,
  tier,
  inflationRate = DEFAULT_INFLATION_RATE,
  includedMilestones = {},
  personalGoals = { included: false, age: null },
  customMilestoneAges = {},
}: ProjectMilestoneBarsInput): ProjectMilestoneBarsResult {
  const bracket = incomeBracketIndex(annualIncome);
  const multTable = MILESTONE_MULTIPLIERS[tier] ?? MILESTONE_MULTIPLIERS.tier1;
  const isIncluded = (key: MilestoneKey) => includedMilestones[key] !== false;

  const futureChecked: ActiveMilestone[] = MILESTONES.map((m) => ({
    ...m,
    age: effectiveMilestoneAge(m.key, customMilestoneAges),
  }))
    .filter((m) => m.age > currentAge && m.age <= PROJECTION_END_AGE && isIncluded(m.key))
    .map((m) => ({ ...m, multiplier: multTable[m.key][bracket], type: "milestone" as const }))
    .sort((a, b) => a.age - b.age);

  const goalsActive =
    personalGoals.included === true &&
    Number.isFinite(Number(personalGoals.age)) &&
    Number(personalGoals.age) >= currentAge &&
    Number(personalGoals.age) <= PROJECTION_END_AGE;
  const goalsAge = goalsActive ? Number(personalGoals.age) : null;
  const goalsBaseAmount =
    Number.isFinite(Number(personalGoals.monthlyAmount)) && Number(personalGoals.monthlyAmount) > 0
      ? Number(personalGoals.monthlyAmount)
      : PERSONAL_GOALS_BASE_MONTHLY;
  const goalsExpenseAt = (age: number): number => {
    if (!goalsActive || goalsAge === null || age < goalsAge) return 0;
    return goalsBaseAmount * Math.pow(1 + inflationRate, age - currentAge);
  };

  const anchors: Anchor[] = [...futureChecked];
  if (goalsActive && goalsAge !== null && goalsAge > currentAge && !anchors.some((a) => a.age === goalsAge)) {
    anchors.push({ key: "personalGoals", label: "Personal goals", age: goalsAge, type: "goals" });
  }
  anchors.sort((a, b) => a.age - b.age);

  const todayLifestyle = currentMonthlyExpense;
  const todayGoals = goalsExpenseAt(currentAge);
  const bars: ProjectionBar[] = [
    {
      key: "today",
      label: `Today (${currentAge})`,
      age: currentAge,
      monthly: Math.max(0, Math.round(todayLifestyle + todayGoals)),
      lifestyleMonthly: Math.max(0, Math.round(todayLifestyle)),
      goalsMonthly: Math.max(0, Math.round(todayGoals)),
      type: "today",
    },
  ];

  let lifestyle = currentMonthlyExpense;
  let prevAge = currentAge;
  for (const a of anchors) {
    const yearsBetween = a.age - prevAge;
    const inflated = lifestyle * Math.pow(1 + inflationRate, yearsBetween);
    lifestyle = a.type === "milestone" ? inflated * a.multiplier : inflated;
    const goals = goalsExpenseAt(a.age);
    const total = lifestyle + goals;
    bars.push({
      key: a.key,
      label: a.type === "goals" ? `Personal goals (${a.age})` : `${a.label} (${a.age})`,
      age: a.age,
      monthly: Math.max(0, Math.round(total)),
      lifestyleMonthly: Math.max(0, Math.round(lifestyle)),
      goalsMonthly: Math.max(0, Math.round(goals)),
      type: a.type,
      ...(a.type === "milestone" ? { multiplier: a.multiplier } : {}),
    });
    prevAge = a.age;
  }

  return { bars, activeMilestones: futureChecked, bracketIndex: bracket, goalsActive, goalsAge };
}

export interface IdealTenureRange {
  min: number;
  max: number;
}

/**
 * Ideal tenure end-age range (e.g. "65–70"). If a kid milestone is checked,
 * anchors off the youngest kid staying dependent for KID_INDEPENDENCE_MIN..MAX
 * years; otherwise falls back to the customer's own preferred cover age (or
 * PROJECTION_END_AGE if none given). The midpoint is snapped to a 5-year
 * bucket so the range always reads as a clean "X–X+5".
 */
export function computeIdealTenureEndAge(
  includedMilestones: Partial<IncludedMilestones>,
  customMilestoneAges: Partial<MilestoneAges> = {},
  desiredEndAge?: number,
): IdealTenureRange {
  const kidAges = (["firstChild", "secondChild"] as const)
    .filter((key) => includedMilestones[key] !== false)
    .map((key) => effectiveMilestoneAge(key, customMilestoneAges));

  let rawMin: number;
  let rawMax: number;
  if (kidAges.length > 0) {
    const youngest = Math.max(...kidAges);
    rawMin = youngest + KID_INDEPENDENCE_MIN;
    rawMax = youngest + KID_INDEPENDENCE_MAX;
  } else {
    const single = Number.isFinite(desiredEndAge) && (desiredEndAge as number) > 0 ? (desiredEndAge as number) : PROJECTION_END_AGE;
    rawMin = single;
    rawMax = single;
  }

  const midpoint = (rawMin + rawMax) / 2;
  const snapped = Math.round(midpoint / 5) * 5;
  return { min: snapped, max: snapped + 5 };
}
