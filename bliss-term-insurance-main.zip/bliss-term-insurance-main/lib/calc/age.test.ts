import { describe, expect, it } from "vitest";
import { ageFromDob } from "./age";

const TODAY = new Date("2026-07-12T00:00:00");

describe("ageFromDob", () => {
  it("computes whole years for a birthday already passed this year", () => {
    expect(ageFromDob("1990-01-01", TODAY)).toBe(36);
  });

  it("does not count a birthday that has not occurred yet this year", () => {
    expect(ageFromDob("1990-12-31", TODAY)).toBe(35);
  });

  it("counts the birthday on the day itself", () => {
    expect(ageFromDob("2000-07-12", TODAY)).toBe(26);
  });

  it("returns null for empty input", () => {
    expect(ageFromDob("", TODAY)).toBeNull();
  });

  it("returns null for an unparseable date", () => {
    expect(ageFromDob("not-a-date", TODAY)).toBeNull();
  });

  it("returns null for a future date of birth", () => {
    expect(ageFromDob("2030-01-01", TODAY)).toBeNull();
  });
});
