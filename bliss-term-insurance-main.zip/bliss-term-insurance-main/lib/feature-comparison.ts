import type { InbuiltFeature, InbuiltFeatureCategory } from "@/types";

/**
 * Shared visibility rule behind every policy-comparison table in the app
 * (Inbuilt Features, and each of the Riders pills): a feature row is dropped
 * entirely when none of the currently-selected policies offer it, otherwise
 * it's kept so the shown policies that do lack it render as NA.
 */

function isFeatureVisible(feature: InbuiltFeature, policyIds: string[]): boolean {
  return policyIds.some((id) => feature.byPolicy[id]?.available === true);
}

export function visibleFeatureCategories(
  categories: InbuiltFeatureCategory[],
  policyIds: string[],
): InbuiltFeatureCategory[] {
  return categories
    .map((category) => ({
      ...category,
      features: category.features.filter((f) => isFeatureVisible(f, policyIds)),
    }))
    .filter((category) => category.features.length > 0);
}
