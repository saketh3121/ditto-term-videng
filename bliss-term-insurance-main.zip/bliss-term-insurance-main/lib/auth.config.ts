import type { NextAuthConfig } from "next-auth";

/**
 * Edge-safe auth config — imported by middleware. Holds only what the edge
 * runtime needs: the sign-in-page path and the authorization callback that
 * gates every protected route. Providers live in lib/auth.ts (Node runtime).
 */
export const authConfig = {
  pages: { signIn: "/login", error: "/login" },
  providers: [],
  callbacks: {
    authorized({ auth }) {
      // A valid session is required for all matched routes (see middleware.ts).
      return Boolean(auth?.user);
    },
  },
} satisfies NextAuthConfig;
