import { describe, expect, it } from "vitest";
import { annotateAbbreviations } from "./abbreviations";

describe("annotateAbbreviations", () => {
  it("splits plain text around a whole-word abbreviation", () => {
    const segments = annotateAbbreviations("100% of Death Benefit SA (Max 1 Cr)");
    expect(segments).toEqual([
      { kind: "text", value: "100% of Death Benefit " },
      { kind: "abbr", abbr: "SA", expansion: "Sum Assured" },
      { kind: "text", value: " (Max 1 Cr)" },
    ]);
  });

  it("does not match an abbreviation as a substring of a longer word", () => {
    const segments = annotateAbbreviations("Sold in the USA and covers TPD");
    expect(segments).toEqual([
      { kind: "text", value: "Sold in the USA and covers " },
      { kind: "abbr", abbr: "TPD", expansion: "Total Permanent Disability" },
    ]);
  });

  it("matches multiple distinct abbreviations in one string", () => {
    const segments = annotateAbbreviations("WOP and ROP riders, PPT of 10 years");
    expect(segments.filter((s) => s.kind === "abbr").map((s) => (s as { abbr: string }).abbr)).toEqual([
      "WOP",
      "ROP",
      "PPT",
    ]);
  });

  it("matches case-insensitively but keeps the source's original casing on screen", () => {
    const segments = annotateAbbreviations("3. WoP on remaining SA: Yes");
    expect(segments).toEqual([
      { kind: "text", value: "3. " },
      { kind: "abbr", abbr: "WoP", expansion: "Waiver of Premium" },
      { kind: "text", value: " on remaining " },
      { kind: "abbr", abbr: "SA", expansion: "Sum Assured" },
      { kind: "text", value: ": Yes" },
    ]);
  });

  it("returns the whole string untouched when nothing matches", () => {
    expect(annotateAbbreviations("plain sentence")).toEqual([{ kind: "text", value: "plain sentence" }]);
  });
});
