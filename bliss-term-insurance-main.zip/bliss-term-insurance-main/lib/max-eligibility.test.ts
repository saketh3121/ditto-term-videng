import { describe, expect, it } from "vitest";
import { classifyCoverVsEligibilityRange, computeMaxEligibilityRange } from "./max-eligibility";

describe("computeMaxEligibilityRange", () => {
  it("Test A — baseline, resident age 32, income 15L: Bajaj/Axis tie at min, ICICI/HDFC tie at max", () => {
    const range = computeMaxEligibilityRange({ age: 32, annualIncome: 15_00_000, residency: "resident" });
    expect(range.min).toBe(3_75_00_000);
    expect(range.max).toBe(4_50_00_000);
    expect(range.perInsurer).toHaveLength(4);
    expect(range.perInsurer.map((p) => p.brand).sort()).toEqual(
      ["Axis Max Life", "Bajaj Life", "HDFC Life", "ICICI Prudential"].sort(),
    );

    const bajaj = range.perInsurer.find((p) => p.brand === "Bajaj Life");
    expect(bajaj?.name).toBe("Bajaj i secure II");
    expect(bajaj?.amount).toBe(3_75_00_000);

    expect(classifyCoverVsEligibilityRange(5_00_00_000, range)).toBe("over");
    expect(classifyCoverVsEligibilityRange(4_00_00_000, range)).toBe("within");
    expect(classifyCoverVsEligibilityRange(3_00_00_000, range)).toBe("under");
  });

  it("Test B — resident age 63, income 10L: Bajaj plan III overtakes i secure II, all four tie at 50L", () => {
    const range = computeMaxEligibilityRange({ age: 63, annualIncome: 10_00_000, residency: "resident" });
    expect(range.min).toBe(50_00_000);
    expect(range.max).toBe(50_00_000);
    expect(range.perInsurer).toHaveLength(4);

    const bajaj = range.perInsurer.find((p) => p.brand === "Bajaj Life");
    expect(bajaj?.name).toBe("Bajaj (plan III)");
    expect(bajaj?.amount).toBe(50_00_000);
  });

  it("Test C — NRI age 40, income 8L: only the NRI Bajaj plan fires, becomes the most generous", () => {
    const range = computeMaxEligibilityRange({ age: 40, annualIncome: 8_00_000, residency: "nri" });
    expect(range.min).toBe(1_60_00_000);
    expect(range.max).toBe(2_40_00_000);
    expect(range.perInsurer).toHaveLength(4);

    const bajaj = range.perInsurer.find((p) => p.brand === "Bajaj Life");
    expect(bajaj?.name).toBe("Bajaj (NRI)");
    expect(bajaj?.amount).toBe(2_40_00_000);
    expect(bajaj?.amount).toBe(range.max);
  });

  it("Test D — resident age 45, income 3L (below Axis's 4.5L threshold): Axis Max Life is absent, not zeroed", () => {
    const range = computeMaxEligibilityRange({ age: 45, annualIncome: 3_00_000, residency: "resident" });
    expect(range.min).toBe(45_00_000);
    expect(range.max).toBe(60_00_000);
    expect(range.perInsurer).toHaveLength(3);
    expect(range.perInsurer.some((p) => p.brand === "Axis Max Life")).toBe(false);
  });

  it("returns nulls when income is blank or zero", () => {
    const range = computeMaxEligibilityRange({ age: 30, annualIncome: 0, residency: "resident" });
    expect(range).toEqual({ min: null, max: null, perInsurer: [] });
  });
});

describe("classifyCoverVsEligibilityRange", () => {
  it("returns null when the range hasn't been computed", () => {
    expect(classifyCoverVsEligibilityRange(1_00_00_000, null)).toBeNull();
    expect(classifyCoverVsEligibilityRange(1_00_00_000, { min: null, max: null, perInsurer: [] })).toBeNull();
  });
});
