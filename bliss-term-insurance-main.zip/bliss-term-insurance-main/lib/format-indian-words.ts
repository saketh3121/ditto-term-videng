/**
 * Number -> Indian-English words (thousand / lakh / crore grouping, not
 * million / billion). Pure, no I/O — used as a live "did I type that right"
 * readout under monetary inputs (Annual Income, Monthly Expenses,
 * Uninsured Loans), never for currency math itself.
 */

const ONES = [
  "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
  "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen",
];
const TENS = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];

/** 0-99 */
function twoDigitsToWords(n: number): string {
  if (n === 0) return "";
  if (n < 20) return ONES[n]!;
  const tens = Math.floor(n / 10);
  const ones = n % 10;
  return TENS[tens] + (ones ? ` ${ONES[ones]}` : "");
}

/** 0-999 */
function threeDigitsToWords(n: number): string {
  if (n === 0) return "";
  const hundreds = Math.floor(n / 100);
  const rest = n % 100;
  const parts: string[] = [];
  if (hundreds) parts.push(`${ONES[hundreds]} Hundred`);
  if (rest) parts.push(twoDigitsToWords(rest));
  return parts.join(" ");
}

/** Whole rupees only — the UI feeding this always deals in whole-rupee inputs. */
export function numberToIndianWords(value: number): string {
  if (!Number.isFinite(value)) return "";
  const n = Math.floor(Math.abs(value));
  if (n === 0) return "Zero";

  let remainder = n;
  const crore = Math.floor(remainder / 1_00_00_000);
  remainder %= 1_00_00_000;
  const lakh = Math.floor(remainder / 1_00_000);
  remainder %= 1_00_000;
  const thousand = Math.floor(remainder / 1_000);
  remainder %= 1_000;
  const hundredsGroup = remainder;

  const parts: string[] = [];
  if (crore) parts.push(`${threeDigitsToWords(crore)} Crore`);
  if (lakh) parts.push(`${twoDigitsToWords(lakh)} Lakh`);
  if (thousand) parts.push(`${twoDigitsToWords(thousand)} Thousand`);
  if (hundredsGroup) parts.push(threeDigitsToWords(hundredsGroup));

  return (value < 0 ? "Minus " : "") + parts.join(" ");
}
