import type { PolicyDetailCategory, PolicyDetailItem } from "@/types";

/**
 * Reflows a policy-detail item's raw text into one flowing paragraph:
 * blank-line breaks in the source become paragraph-internal sentence
 * breaks, and single line breaks (mid-list continuations like "1. / a. /
 * i.") are joined with a space rather than kept as separate lines. The
 * numbered/lettered markers themselves are left as-is — collapsing them
 * into hand-written prose while faithfully preserving every nested
 * condition is a job for the source data, not a mechanical formatter.
 */
function flowText(text: string): string {
  return text
    .split(/\n\s*\n/)
    .map((block) => block.replace(/\s*\n\s*/g, " ").trim())
    .filter(Boolean)
    .join(" ");
}

export interface NarrativeParagraph {
  label: string;
  text: string;
}

/** True for placeholder "no data" values that shouldn't render as a paragraph. */
function isBlank(text: string): boolean {
  const t = text.trim();
  return t.length === 0 || t === "-" || t.toLowerCase() === "not available";
}

/**
 * One category's items turned into flowing paragraphs, each led by its
 * label. Items with no real content (e.g. "-") are dropped rather than
 * rendered as an empty paragraph.
 */
export function categoryToNarrative(category: PolicyDetailCategory): NarrativeParagraph[] {
  return category.items
    .map((item: PolicyDetailItem) => ({ label: item.label, text: flowText(item.text) }))
    .filter((p) => !isBlank(p.text));
}
