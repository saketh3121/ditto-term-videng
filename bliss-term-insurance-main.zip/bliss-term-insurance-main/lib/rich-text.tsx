import type { ReactNode } from "react";

/**
 * Splits copy around `<bold>...</bold>` spans for inline emphasis — the
 * one rich-text convention this app's content JSON uses. Shared by any
 * component that needs to bold specific action words within a longer
 * sentence (Profile's factor bodies, the eligibility disclaimer tile).
 */
export function renderBoldText(text: string): ReactNode {
  const parts = text.split(/(<bold>.*?<\/bold>)/g);
  return parts.map((part, i) => {
    const m = /^<bold>(.*?)<\/bold>$/.exec(part);
    if (m) {
      return (
        <span key={i} className="font-semibold text-text-primary">
          {m[1]}
        </span>
      );
    }
    return <span key={i}>{part}</span>;
  });
}
