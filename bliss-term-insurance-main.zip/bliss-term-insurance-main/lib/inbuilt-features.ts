import inbuiltFeaturesContent from "@/content/inbuilt-features.json";
import { visibleFeatureCategories } from "@/lib/feature-comparison";
import type { InbuiltFeatureCategory, InbuiltFeaturesContent } from "@/types";

/**
 * Client-safe Inbuilt Features access, same pattern as lib/policies.ts —
 * content/inbuilt-features.json is imported directly so the bundler inlines
 * it (no fetch, no server round-trip).
 */

const { categories } = inbuiltFeaturesContent as InbuiltFeaturesContent;

export const INBUILT_FEATURE_CATEGORIES: InbuiltFeatureCategory[] = categories;

export function visibleInbuiltFeatureCategories(policyIds: string[]): InbuiltFeatureCategory[] {
  return visibleFeatureCategories(categories, policyIds);
}
