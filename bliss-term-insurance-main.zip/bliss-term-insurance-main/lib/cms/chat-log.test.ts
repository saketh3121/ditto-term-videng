import { beforeEach, describe, expect, it, vi } from "vitest";
import type { SessionRecord } from "@/lib/session/record";

vi.mock("server-only", () => ({}));
vi.mock("@/config/chat-log", () => ({
  CHATLOG_REPO_OWNER: "owner",
  CHATLOG_REPO_NAME: "repo",
  CHATLOG_BASE_BRANCH: "main",
}));

const getContent = vi.fn();
const createOrUpdateFileContents = vi.fn();
vi.mock("@octokit/rest", () => ({
  Octokit: class {
    repos = { getContent, createOrUpdateFileContents };
  },
}));

process.env.CHATLOG_GITHUB_TOKEN = "test-token";
const { upsertSessionRecord } = await import("./chat-log");

const record = (seq: number) =>
  ({
    sessionId: "11111111-1111-4111-8111-111111111111",
    chatId: "CH515923",
    startedAt: "2026-10-13T06:00:00.000Z",
    coveragePct: 44,
    qualified: true,
    advisorEmail: "a@joinditto.in",
    seq,
  }) as SessionRecord;

const stored = (seq: number) => ({
  data: { type: "file", sha: "sha-1", content: Buffer.from(JSON.stringify({ seq })).toString("base64") },
});
const httpError = (status: number) => Object.assign(new Error(`HTTP ${status}`), { status });

beforeEach(() => {
  getContent.mockReset();
  createOrUpdateFileContents.mockReset().mockResolvedValue({});
});

describe("upsertSessionRecord", () => {
  it("creates the session file on first write, under its IST date", async () => {
    getContent.mockRejectedValue(httpError(404));
    expect(await upsertSessionRecord(record(1))).toBe("written");
    const call = createOrUpdateFileContents.mock.calls[0]![0];
    expect(call.path).toBe("sessions/2026-10-13/CH515923_11111111-1111-4111-8111-111111111111.json");
    expect(call).not.toHaveProperty("sha");
    expect(call.message).toContain("CH515923 · 44% · qualified");
  });

  it("updates in place with the current sha when the record is newer", async () => {
    getContent.mockResolvedValue(stored(2));
    expect(await upsertSessionRecord(record(3))).toBe("written");
    expect(createOrUpdateFileContents.mock.calls[0]![0].sha).toBe("sha-1");
  });

  it("ignores a late, older snapshot instead of moving the session backwards", async () => {
    getContent.mockResolvedValue(stored(5));
    expect(await upsertSessionRecord(record(4))).toBe("stale");
    expect(createOrUpdateFileContents).not.toHaveBeenCalled();
  });

  it("retries when another write to the same file lands first", async () => {
    getContent.mockRejectedValueOnce(httpError(404)).mockResolvedValue(stored(1));
    createOrUpdateFileContents.mockRejectedValueOnce(httpError(422)).mockResolvedValue({});
    expect(await upsertSessionRecord(record(2))).toBe("written");
    expect(createOrUpdateFileContents).toHaveBeenCalledTimes(2);
  });

  it("gives up after repeated conflicts", async () => {
    getContent.mockResolvedValue(stored(1));
    createOrUpdateFileContents.mockRejectedValue(httpError(409));
    await expect(upsertSessionRecord(record(2))).rejects.toThrow("HTTP 409");
    expect(createOrUpdateFileContents).toHaveBeenCalledTimes(3);
  });
});
