import "server-only";
import { CMS_BRANCH_NAME } from "@/config/cms";
import { getFileOnRef } from "@/lib/cms/github";
import { getPoliciesLive } from "@/lib/cms/policies-live";
import { getInsurerById } from "@/lib/content";
import { insurerSchema, policiesContentSchema } from "@/schemas/content";
import type { Insurer, PoliciesContent } from "@/types";

/**
 * Branch-tip-first reads for admin edit forms. If the CMS branch already has
 * a pending edit for a record, the form should pre-fill from that — not from
 * stale `main` — so a second edit round doesn't silently revert the first.
 * The write path (lib/cms/actions.ts) always re-fetches sha fresh at commit
 * time regardless, so this only affects what the form displays on load.
 */

export async function getStagedOrLiveInsurer(id: string): Promise<Insurer | null> {
  const staged = await getFileOnRef(`content/insurers/${id}.json`, CMS_BRANCH_NAME);
  if (staged) {
    const result = insurerSchema.safeParse(JSON.parse(staged.content));
    if (result.success) return result.data;
  }
  return getInsurerById(id);
}

export async function getStagedOrLivePolicies(): Promise<PoliciesContent> {
  const staged = await getFileOnRef("content/policies.json", CMS_BRANCH_NAME);
  if (staged) {
    const result = policiesContentSchema.safeParse(JSON.parse(staged.content));
    if (result.success) return result.data;
  }
  return getPoliciesLive();
}
