import "server-only";
import { upsertFile } from "@/lib/cms/github";
import { CMS_BASE_BRANCH, CMS_BOT_AUTHOR } from "@/config/cms";
import { emailToSlug } from "@/lib/slug";
import type { Advisor } from "@/types";

/**
 * Writes one advisor straight to `content/advisors/<slug>.json` on `main` —
 * no PR branch, unlike the rest of the CMS. Used by the super-admin
 * auto-seed (lib/auth.ts) and the access-request approve endpoint
 * (app/api/approve-access/route.ts), neither of which has a human editor
 * session to attribute the commit to.
 */
export async function writeAdvisorFile(advisor: Advisor): Promise<void> {
  const content = `${JSON.stringify({ ...advisor, email: advisor.email.toLowerCase() }, null, 2)}\n`;
  await upsertFile({
    path: `content/advisors/${emailToSlug(advisor.email)}.json`,
    content,
    message: `chore: add advisor ${advisor.email.toLowerCase()}`,
    branch: CMS_BASE_BRANCH,
    author: CMS_BOT_AUTHOR,
  });
}
