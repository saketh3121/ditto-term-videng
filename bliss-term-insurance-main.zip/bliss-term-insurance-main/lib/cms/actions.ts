"use server";

import { revalidatePath } from "next/cache";
import { CMS_BRANCH_NAME, CMS_PR_TITLE } from "@/config/cms";
import { auth } from "@/lib/auth";
import { diffInsurer, diffPolicy, hasChanges } from "@/lib/cms/diff";
import {
  closePrAndDeleteBranch,
  createPr,
  deleteBranchIfExists,
  ensureBranch,
  findOpenPr,
  getCombinedCheckStatus,
  getPrMergeability,
  mergePr,
  updatePrBody,
  upsertFile,
  type CheckStatus,
  type CommitAuthor,
} from "@/lib/cms/github";
import { buildFullDiff, buildPrBody } from "@/lib/cms/pending-changes";
import { isAdminEmail } from "@/lib/cms/roles";
import { getStagedOrLiveInsurer, getStagedOrLivePolicies } from "@/lib/cms/staged-content";
import { insurerSchema, policiesContentSchema, policySchema } from "@/schemas/content";

/**
 * Server actions for the admin CMS. Shared here (not colocated per route)
 * because both the "new" and "edit" pages for a record type call the same
 * submit logic, and the review page's approve/reject share the same
 * GitHub/diff orchestration.
 */

export type ActionResult =
  | { ok: true; noop?: boolean }
  | {
      ok: false;
      error: string;
      code?: "unauthorized" | "validation" | "duplicate_id" | "not_found" | "checks_not_passed" | "conflict";
    };

async function requireSession(): Promise<{ email: string; name: string } | null> {
  const session = await auth();
  const email = session?.user?.email;
  if (!email) return null;
  return { email, name: session?.user?.name ?? email };
}

async function requireAdmin(): Promise<{ email: string; name: string } | null> {
  const session = await requireSession();
  if (!session || !(await isAdminEmail(session.email))) return null;
  return session;
}

/** Opens the PR if this is the first staged edit, then refreshes its body with the full diff. */
async function refreshPr(): Promise<void> {
  const pr = (await findOpenPr()) ?? (await createPr({ title: CMS_PR_TITLE, body: "Pending content edits." }));
  const changes = await buildFullDiff();
  await updatePrBody(pr.number, buildPrBody(changes));
}

export async function submitInsurerEdit(input: {
  id: string;
  mode: "create" | "edit";
  data: unknown;
}): Promise<ActionResult> {
  const session = await requireSession();
  if (!session) return { ok: false, error: "Not signed in.", code: "unauthorized" };

  const parsed = insurerSchema.safeParse(input.data);
  if (!parsed.success) {
    return { ok: false, error: parsed.error.message, code: "validation" };
  }

  const current = await getStagedOrLiveInsurer(input.id);
  if (input.mode === "create" && current !== null) {
    return { ok: false, error: "An insurer with this id already exists.", code: "duplicate_id" };
  }
  if (input.mode === "edit" && current === null) {
    return { ok: false, error: "Insurer not found.", code: "not_found" };
  }

  const diff = diffInsurer(current, parsed.data);
  if (!hasChanges(diff)) return { ok: true, noop: true };

  const author: CommitAuthor = { name: session.name, email: session.email };
  await ensureBranch();
  await upsertFile({
    path: `content/insurers/${input.id}.json`,
    content: `${JSON.stringify(parsed.data, null, 2)}\n`,
    message: `content: update insurer ${input.id}`,
    branch: CMS_BRANCH_NAME,
    author,
  });
  await refreshPr();
  revalidatePath("/admin", "layout");
  return { ok: true };
}

export async function submitPolicyEdit(input: {
  id: string;
  mode: "create" | "edit";
  data: unknown;
}): Promise<ActionResult> {
  const session = await requireSession();
  if (!session) return { ok: false, error: "Not signed in.", code: "unauthorized" };

  const parsedRecord = policySchema.safeParse(input.data);
  if (!parsedRecord.success) {
    return { ok: false, error: parsedRecord.error.message, code: "validation" };
  }

  const { policies } = await getStagedOrLivePolicies();
  const before = policies.find((p) => p.id === input.id) ?? null;

  if (input.mode === "create" && before !== null) {
    return { ok: false, error: "A policy with this id already exists.", code: "duplicate_id" };
  }
  if (input.mode === "edit" && before === null) {
    return { ok: false, error: "Policy not found.", code: "not_found" };
  }

  const nextPolicies =
    input.mode === "create"
      ? [...policies, parsedRecord.data]
      : policies.map((p) => (p.id === input.id ? parsedRecord.data : p));

  const parsedContent = policiesContentSchema.safeParse({ policies: nextPolicies });
  if (!parsedContent.success) {
    return { ok: false, error: parsedContent.error.message, code: "validation" };
  }

  const diff = diffPolicy(before, parsedRecord.data);
  if (!hasChanges(diff)) return { ok: true, noop: true };

  const author: CommitAuthor = { name: session.name, email: session.email };
  await ensureBranch();
  await upsertFile({
    path: "content/policies.json",
    content: `${JSON.stringify(parsedContent.data, null, 2)}\n`,
    message: `content: update policy ${input.id}`,
    branch: CMS_BRANCH_NAME,
    author,
  });
  await refreshPr();
  revalidatePath("/admin", "layout");
  return { ok: true };
}

/** Polled by the review screen's client-side check-status/approve UI. */
export async function getReviewStatus(): Promise<{
  hasPr: boolean;
  prUrl: string | null;
  checks: CheckStatus | null;
  mergeable: boolean | null;
}> {
  const session = await requireAdmin();
  if (!session) return { hasPr: false, prUrl: null, checks: null, mergeable: null };

  const pr = await findOpenPr();
  if (!pr) return { hasPr: false, prUrl: null, checks: null, mergeable: null };

  const [checks, mergeability] = await Promise.all([
    getCombinedCheckStatus(CMS_BRANCH_NAME),
    getPrMergeability(pr.number),
  ]);
  return { hasPr: true, prUrl: pr.htmlUrl, checks, mergeable: mergeability.mergeable };
}

export async function approveAndMerge(): Promise<ActionResult> {
  const session = await requireAdmin();
  if (!session) return { ok: false, error: "Admins only.", code: "unauthorized" };

  const pr = await findOpenPr();
  if (!pr) return { ok: false, error: "No pending changes to merge.", code: "not_found" };

  // Never trust client-side gating alone — re-verify server-side.
  const checks = await getCombinedCheckStatus(CMS_BRANCH_NAME);
  if (checks.state !== "success") {
    return { ok: false, error: "Checks have not passed yet.", code: "checks_not_passed" };
  }

  const mergeability = await getPrMergeability(pr.number);
  if (mergeability.mergeable === false || mergeability.mergeableState === "dirty") {
    return {
      ok: false,
      error: "This change conflicts with main — resolve it on GitHub, or reject to discard.",
      code: "conflict",
    };
  }

  await mergePr(pr.number);
  await deleteBranchIfExists();
  revalidatePath("/admin", "layout");
  return { ok: true };
}

export async function rejectAndDiscard(): Promise<ActionResult> {
  const session = await requireAdmin();
  if (!session) return { ok: false, error: "Admins only.", code: "unauthorized" };

  const pr = await findOpenPr();
  if (!pr) return { ok: false, error: "No pending changes to reject.", code: "not_found" };

  await closePrAndDeleteBranch(pr.number);
  revalidatePath("/admin", "layout");
  return { ok: true };
}
