import "server-only";
import { promises as fs } from "fs";
import path from "path";
import { cache } from "react";
import { policiesContentSchema } from "@/schemas/content";
import type { PoliciesContent, Policy } from "@/types";

/**
 * Server-only, disk-read policies loader for the admin CMS.
 *
 * `lib/policies.ts` imports content/policies.json directly so the bundler
 * inlines it — perfect for the client-facing Policy Panel, but stale for an
 * admin form: it reflects whatever was baked in at build time, not the
 * current file on disk. This is the fs + zod-validated sibling, following
 * `lib/content.ts`'s exact pattern. Deliberately does not modify
 * `lib/policies.ts` or its consumers.
 */

const FILE = path.join(process.cwd(), "content", "policies.json");

export const getPoliciesLive = cache(async (): Promise<PoliciesContent> => {
  const raw = JSON.parse(await fs.readFile(FILE, "utf-8"));
  const result = policiesContentSchema.safeParse(raw);
  if (!result.success) {
    throw new Error(`Invalid content/policies.json: ${result.error.message}`);
  }
  return result.data;
});

export interface InsurerPolicyGroup {
  insurerId: string;
  insurerName: string;
  policies: Policy[];
}

/** Group policies by owning insurer, preserving array order. Admin-list use only. */
export function groupPoliciesByInsurer(policies: Policy[]): InsurerPolicyGroup[] {
  const groups: InsurerPolicyGroup[] = [];
  for (const p of policies) {
    let group = groups.find((g) => g.insurerId === p.insurerId);
    if (!group) {
      group = { insurerId: p.insurerId, insurerName: p.insurerName, policies: [] };
      groups.push(group);
    }
    group.policies.push(p);
  }
  return groups;
}
