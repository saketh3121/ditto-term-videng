import "server-only";
import { Octokit } from "@octokit/rest";
import { CHATLOG_BASE_BRANCH, CHATLOG_REPO_NAME, CHATLOG_REPO_OWNER } from "@/config/chat-log";
import { SUPER_ADMIN_EMAIL } from "@/config/auth";
import { sessionRecordPath, type SessionRecord } from "@/lib/session/record";

/**
 * Writes session records to the dedicated chat-log repo (see
 * config/chat-log.ts). One file per session, so advisors on different calls
 * never write the same file; a session's own writes are ordered by `seq`.
 */

let client: Octokit | null = null;

function getOctokit(): Octokit {
  if (client) return client;
  // Prefers a dedicated, narrowly-scoped token for the log repo; falls back
  // to CMS_GITHUB_TOKEN so a single-token setup still works.
  const token = process.env.CHATLOG_GITHUB_TOKEN ?? process.env.CMS_GITHUB_TOKEN;
  if (!token) throw new Error("Neither CHATLOG_GITHUB_TOKEN nor CMS_GITHUB_TOKEN is set");
  client = new Octokit({ auth: token });
  return client;
}

export function isChatLogConfigured(): boolean {
  return Boolean(CHATLOG_REPO_OWNER && CHATLOG_REPO_NAME);
}

const LOG_AUTHOR = { name: "Bliss Term Advisory — Chat Log", email: SUPER_ADMIN_EMAIL };
const MAX_ATTEMPTS = 3;

const httpStatus = (err: unknown): number | undefined =>
  typeof err === "object" && err !== null && "status" in err && typeof err.status === "number" ? err.status : undefined;

/**
 * Creates or replaces this session's record. Returns "stale" without
 * writing when the stored record already has an equal or newer `seq` (a
 * slower, older request arriving late), so a session never moves backwards.
 */
export async function upsertSessionRecord(record: SessionRecord): Promise<"written" | "stale"> {
  if (!isChatLogConfigured()) {
    throw new Error("Chat log repo is not configured — set CHATLOG_GITHUB_OWNER and CHATLOG_GITHUB_REPO.");
  }
  const octokit = getOctokit();
  const repo = { owner: CHATLOG_REPO_OWNER, repo: CHATLOG_REPO_NAME };
  const path = sessionRecordPath(record);

  for (let attempt = 1; ; attempt++) {
    let sha: string | undefined;
    try {
      const { data } = await octokit.repos.getContent({ ...repo, path, ref: CHATLOG_BASE_BRANCH });
      if (!Array.isArray(data) && data.type === "file" && data.content !== undefined) {
        const existing = JSON.parse(Buffer.from(data.content, "base64").toString("utf-8")) as Partial<SessionRecord>;
        if (typeof existing.seq === "number" && existing.seq >= record.seq) return "stale";
        sha = data.sha;
      }
    } catch (err) {
      if (httpStatus(err) !== 404) throw err;
    }

    try {
      await octokit.repos.createOrUpdateFileContents({
        ...repo,
        path,
        message: `session: ${record.chatId} · ${record.coveragePct}% · ${record.qualified ? "qualified" : "not qualified"} — ${record.advisorEmail}`,
        content: Buffer.from(JSON.stringify(record, null, 2), "utf-8").toString("base64"),
        branch: CHATLOG_BASE_BRANCH,
        ...(sha ? { sha } : {}),
        author: LOG_AUTHOR,
        committer: LOG_AUTHOR,
      });
      return "written";
    } catch (err) {
      // 409: file changed since we read it. 422: it was created since we read it.
      const status = httpStatus(err);
      if ((status !== 409 && status !== 422) || attempt >= MAX_ATTEMPTS) throw err;
    }
  }
}
