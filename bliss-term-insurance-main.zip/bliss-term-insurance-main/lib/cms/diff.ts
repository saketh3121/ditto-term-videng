import { CMS_INSURER_FIELDS, CMS_POLICY_FIELDS } from "@/config/cms";
import type { Insurer, Policy } from "@/types";

/**
 * Pure record diffing. No I/O — two record snapshots in, a structured diff
 * out. Values are compared by content (JSON-stringified), not reference, so
 * an array that's re-created but unchanged in content doesn't register as a
 * change.
 */

export type RecordStatus = "added" | "removed" | "modified" | "unchanged";

export interface FieldChange<T> {
  field: keyof T & string;
  before: unknown;
  after: unknown;
}

export interface RecordDiff<T> {
  status: RecordStatus;
  changes: FieldChange<T>[];
}

function valuesEqual(a: unknown, b: unknown): boolean {
  return JSON.stringify(a) === JSON.stringify(b);
}

export function diffFields<T extends Record<string, unknown>>(
  before: T | null,
  after: T | null,
  fields: readonly (keyof T & string)[],
): RecordDiff<T> {
  if (before === null && after === null) {
    throw new Error("diffFields: both before and after are null");
  }

  if (before === null) {
    return {
      status: "added",
      changes: fields.map((field) => ({ field, before: undefined, after: after![field] })),
    };
  }

  if (after === null) {
    return {
      status: "removed",
      changes: fields.map((field) => ({ field, before: before[field], after: undefined })),
    };
  }

  const changes = fields
    .filter((field) => !valuesEqual(before[field], after[field]))
    .map((field) => ({ field, before: before[field], after: after[field] }));

  return { status: changes.length > 0 ? "modified" : "unchanged", changes };
}

export function hasChanges<T>(diff: RecordDiff<T>): boolean {
  return diff.status !== "unchanged";
}

export function diffInsurer(before: Insurer | null, after: Insurer | null): RecordDiff<Insurer> {
  return diffFields(
    before as unknown as Record<string, unknown> | null,
    after as unknown as Record<string, unknown> | null,
    CMS_INSURER_FIELDS,
  ) as unknown as RecordDiff<Insurer>;
}

export function diffPolicy(before: Policy | null, after: Policy | null): RecordDiff<Policy> {
  return diffFields(
    before as unknown as Record<string, unknown> | null,
    after as unknown as Record<string, unknown> | null,
    CMS_POLICY_FIELDS,
  ) as unknown as RecordDiff<Policy>;
}
