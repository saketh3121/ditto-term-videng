import { describe, expect, it } from "vitest";
import { diffFields, hasChanges } from "./diff";

interface Sample extends Record<string, unknown> {
  id: string;
  name: string;
  segments: string[];
}

const FIELDS = ["id", "name", "segments"] as const;

const base: Sample = { id: "a", name: "Alpha", segments: ["resident"] };

describe("diffFields", () => {
  it("reports unchanged when nothing differs", () => {
    const diff = diffFields(base, { ...base, segments: ["resident"] }, FIELDS);
    expect(diff.status).toBe("unchanged");
    expect(diff.changes).toHaveLength(0);
  });

  it("detects a single scalar field change", () => {
    const diff = diffFields(base, { ...base, name: "Alpha Prime" }, FIELDS);
    expect(diff.status).toBe("modified");
    expect(diff.changes).toEqual([{ field: "name", before: "Alpha", after: "Alpha Prime" }]);
  });

  it("detects multiple field changes, in field order", () => {
    const after: Sample = { id: "a", name: "Beta", segments: ["nri"] };
    const diff = diffFields(base, after, FIELDS);
    expect(diff.status).toBe("modified");
    expect(diff.changes.map((c) => c.field)).toEqual(["name", "segments"]);
  });

  it("detects an array content change", () => {
    const diff = diffFields(base, { ...base, segments: ["resident", "nri"] }, FIELDS);
    expect(diff.status).toBe("modified");
    expect(diff.changes).toEqual([
      { field: "segments", before: ["resident"], after: ["resident", "nri"] },
    ]);
  });

  it("does not flag an array with the same content but a different reference", () => {
    const diff = diffFields(base, { ...base, segments: [...base.segments] }, FIELDS);
    expect(diff.status).toBe("unchanged");
  });

  it("reports added when before is null", () => {
    const diff = diffFields<Sample>(null, base, FIELDS);
    expect(diff.status).toBe("added");
    expect(diff.changes).toEqual([
      { field: "id", before: undefined, after: "a" },
      { field: "name", before: undefined, after: "Alpha" },
      { field: "segments", before: undefined, after: ["resident"] },
    ]);
  });

  it("reports removed when after is null", () => {
    const diff = diffFields<Sample>(base, null, FIELDS);
    expect(diff.status).toBe("removed");
    expect(diff.changes).toEqual([
      { field: "id", before: "a", after: undefined },
      { field: "name", before: "Alpha", after: undefined },
      { field: "segments", before: ["resident"], after: undefined },
    ]);
  });

  it("throws when both before and after are null", () => {
    expect(() => diffFields<Sample>(null, null, FIELDS)).toThrow();
  });
});

describe("hasChanges", () => {
  it("is false only for unchanged", () => {
    expect(hasChanges(diffFields(base, { ...base }, FIELDS))).toBe(false);
    expect(hasChanges(diffFields(base, { ...base, name: "Beta" }, FIELDS))).toBe(true);
    expect(hasChanges(diffFields<Sample>(null, base, FIELDS))).toBe(true);
    expect(hasChanges(diffFields<Sample>(base, null, FIELDS))).toBe(true);
  });
});
