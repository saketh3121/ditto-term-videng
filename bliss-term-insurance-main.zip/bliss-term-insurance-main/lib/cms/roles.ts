import "server-only";
import { getAdvisorByEmail } from "@/lib/content";

/**
 * Any signed-in, allowlisted advisor can reach /admin and submit edits (the
 * implicit "editor" role — no separate flag needed since every advisor in
 * content/advisors/ already passed the allowlist check in lib/auth.ts).
 * `role: "admin"` on that same advisor record additionally gates the review
 * screen and the approve/reject actions — single source of truth, no
 * separate ADMIN_EMAILS list to keep in sync.
 */
export async function isAdminEmail(email: string | null | undefined): Promise<boolean> {
  if (!email) return false;
  const advisor = await getAdvisorByEmail(email);
  return advisor?.role === "admin";
}
