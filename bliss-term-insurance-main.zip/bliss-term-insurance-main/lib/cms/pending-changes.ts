import "server-only";
import { CMS_BASE_BRANCH, CMS_BRANCH_NAME } from "@/config/cms";
import { diffInsurer, diffPolicy, hasChanges, type RecordDiff } from "@/lib/cms/diff";
import { getFileOnRef, listDirOnRef } from "@/lib/cms/github";
import { insurerSchema, policiesContentSchema } from "@/schemas/content";
import type { Insurer, Policy } from "@/types";

/**
 * Recomputes the entire pending diff fresh, every call, by comparing
 * content/insurers/* and content/policies.json on `main` vs the CMS branch.
 * No changelog is persisted anywhere — this is the single source of truth
 * for "what's pending," consumed by the dashboard banner, list badges, the
 * review screen, and the PR body. If it disagrees with itself, it's a bug in
 * this function, not a sync issue between a log and the branch.
 */

export interface PendingChange {
  recordType: "insurer" | "policy";
  recordId: string;
  recordLabel: string;
  diff: RecordDiff<Insurer> | RecordDiff<Policy>;
}

async function readInsurerOnRef(id: string, ref: string): Promise<Insurer | null> {
  const file = await getFileOnRef(`content/insurers/${id}.json`, ref);
  if (!file) return null;
  const result = insurerSchema.safeParse(JSON.parse(file.content));
  return result.success ? result.data : null;
}

async function diffInsurers(): Promise<PendingChange[]> {
  const [mainFiles, branchFiles] = await Promise.all([
    listDirOnRef("content/insurers", CMS_BASE_BRANCH),
    listDirOnRef("content/insurers", CMS_BRANCH_NAME),
  ]);
  const ids = new Set(
    [...mainFiles, ...branchFiles].map((f) => f.replace(/\.json$/, "")),
  );

  const changes: PendingChange[] = [];
  for (const id of ids) {
    const [before, after] = await Promise.all([
      readInsurerOnRef(id, CMS_BASE_BRANCH),
      readInsurerOnRef(id, CMS_BRANCH_NAME),
    ]);
    if (before === null && after === null) continue;
    const diff = diffInsurer(before, after);
    if (!hasChanges(diff)) continue;
    changes.push({
      recordType: "insurer",
      recordId: id,
      recordLabel: after?.name ?? before?.name ?? id,
      diff,
    });
  }
  return changes;
}

async function readPoliciesOnRef(ref: string): Promise<Policy[]> {
  const file = await getFileOnRef("content/policies.json", ref);
  if (!file) return [];
  const result = policiesContentSchema.safeParse(JSON.parse(file.content));
  return result.success ? result.data.policies : [];
}

async function diffPolicies(): Promise<PendingChange[]> {
  const [before, after] = await Promise.all([
    readPoliciesOnRef(CMS_BASE_BRANCH),
    readPoliciesOnRef(CMS_BRANCH_NAME),
  ]);
  const ids = new Set([...before.map((p) => p.id), ...after.map((p) => p.id)]);

  const changes: PendingChange[] = [];
  for (const id of ids) {
    const b = before.find((p) => p.id === id) ?? null;
    const a = after.find((p) => p.id === id) ?? null;
    const diff = diffPolicy(b, a);
    if (!hasChanges(diff)) continue;
    changes.push({ recordType: "policy", recordId: id, recordLabel: a?.name ?? b?.name ?? id, diff });
  }
  return changes;
}

export async function buildFullDiff(): Promise<PendingChange[]> {
  const [insurers, policies] = await Promise.all([diffInsurers(), diffPolicies()]);
  return [...insurers, ...policies];
}

export function buildPrBody(changes: PendingChange[]): string {
  if (changes.length === 0) return "No pending changes.";
  const lines = ["## Pending content changes", ""];
  for (const change of changes) {
    lines.push(`### ${change.recordType}: ${change.recordLabel} (\`${change.recordId}\`) — ${change.diff.status}`);
    for (const c of change.diff.changes) {
      lines.push(`- **${c.field}**: \`${JSON.stringify(c.before)}\` → \`${JSON.stringify(c.after)}\``);
    }
    lines.push("");
  }
  return lines.join("\n");
}
