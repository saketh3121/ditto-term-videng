import "server-only";
import { Octokit } from "@octokit/rest";
import {
  CMS_BASE_BRANCH,
  CMS_BRANCH_NAME,
  CMS_MERGE_METHOD,
  CMS_REPO_NAME,
  CMS_REPO_OWNER,
} from "@/config/cms";

/**
 * Thin Octokit wrapper — the only module that talks to the GitHub API. The
 * admin CMS's "pending changes queue" is a single fixed branch + PR (see
 * config/cms.ts); every function here operates on that branch unless a ref
 * is passed explicitly. `CMS_GITHUB_TOKEN` is read lazily, inside function
 * bodies only, so importing this module can never fail `next build`.
 */

export interface CommitAuthor {
  name: string;
  email: string;
}

export interface PrInfo {
  number: number;
  htmlUrl: string;
  body: string | null;
}

export interface CheckStatus {
  state: "pending" | "success" | "failure";
  runs: { name: string; status: string; conclusion: string | null }[];
}

let client: Octokit | null = null;

function getOctokit(): Octokit {
  if (client) return client;
  const token = process.env.CMS_GITHUB_TOKEN;
  if (!token) throw new Error("CMS_GITHUB_TOKEN is not set");
  client = new Octokit({ auth: token });
  return client;
}

const repo = { owner: CMS_REPO_OWNER, repo: CMS_REPO_NAME };

function isNotFound(err: unknown): boolean {
  return typeof err === "object" && err !== null && "status" in err && err.status === 404;
}

export async function getMainHeadSha(): Promise<string> {
  const octokit = getOctokit();
  const { data } = await octokit.git.getRef({ ...repo, ref: `heads/${CMS_BASE_BRANCH}` });
  return data.object.sha;
}

/** Idempotent — creates the CMS branch from current main HEAD if it doesn't exist. */
export async function ensureBranch(): Promise<{ created: boolean }> {
  const octokit = getOctokit();
  try {
    await octokit.git.getRef({ ...repo, ref: `heads/${CMS_BRANCH_NAME}` });
    return { created: false };
  } catch (err) {
    if (!isNotFound(err)) throw err;
    const sha = await getMainHeadSha();
    await octokit.git.createRef({ ...repo, ref: `refs/heads/${CMS_BRANCH_NAME}`, sha });
    return { created: true };
  }
}

export async function getFileOnRef(
  path: string,
  ref: string,
): Promise<{ content: string; sha: string } | null> {
  const octokit = getOctokit();
  try {
    const { data } = await octokit.repos.getContent({ ...repo, path, ref });
    if (Array.isArray(data) || data.type !== "file" || data.content === undefined) {
      throw new Error(`getFileOnRef: ${path}@${ref} is not a file`);
    }
    return { content: Buffer.from(data.content, "base64").toString("utf-8"), sha: data.sha };
  } catch (err) {
    if (isNotFound(err)) return null;
    throw err;
  }
}

/** Names of .json files in a directory on the given ref. */
export async function listDirOnRef(dir: string, ref: string): Promise<string[]> {
  const octokit = getOctokit();
  try {
    const { data } = await octokit.repos.getContent({ ...repo, path: dir, ref });
    if (!Array.isArray(data)) return [];
    return data.filter((e) => e.type === "file" && e.name.endsWith(".json")).map((e) => e.name);
  } catch (err) {
    if (isNotFound(err)) return [];
    throw err;
  }
}

export async function upsertFile(params: {
  path: string;
  content: string;
  message: string;
  branch: string;
  author: CommitAuthor;
}): Promise<{ commitSha: string }> {
  const octokit = getOctokit();
  // Always re-fetch sha immediately before writing — never trust a value
  // carried from an earlier page load, since the branch may have moved.
  const existing = await getFileOnRef(params.path, params.branch);
  const { data } = await octokit.repos.createOrUpdateFileContents({
    ...repo,
    path: params.path,
    message: params.message,
    content: Buffer.from(params.content, "utf-8").toString("base64"),
    branch: params.branch,
    sha: existing?.sha,
    author: params.author,
    committer: params.author,
  });
  return { commitSha: data.commit.sha ?? "" };
}

export async function findOpenPr(): Promise<PrInfo | null> {
  const octokit = getOctokit();
  const { data } = await octokit.pulls.list({
    ...repo,
    head: `${CMS_REPO_OWNER}:${CMS_BRANCH_NAME}`,
    state: "open",
    base: CMS_BASE_BRANCH,
  });
  const pr = data[0];
  return pr ? { number: pr.number, htmlUrl: pr.html_url, body: pr.body ?? null } : null;
}

export async function createPr(params: { title: string; body: string }): Promise<PrInfo> {
  const octokit = getOctokit();
  const { data } = await octokit.pulls.create({
    ...repo,
    head: CMS_BRANCH_NAME,
    base: CMS_BASE_BRANCH,
    title: params.title,
    body: params.body,
  });
  return { number: data.number, htmlUrl: data.html_url, body: data.body ?? null };
}

export async function updatePrBody(prNumber: number, body: string): Promise<void> {
  const octokit = getOctokit();
  await octokit.pulls.update({ ...repo, pull_number: prNumber, body });
}

export async function getPrMergeability(
  prNumber: number,
): Promise<{ mergeable: boolean | null; mergeableState: string }> {
  const octokit = getOctokit();
  const { data } = await octokit.pulls.get({ ...repo, pull_number: prNumber });
  return { mergeable: data.mergeable, mergeableState: data.mergeable_state };
}

export async function getCombinedCheckStatus(ref: string): Promise<CheckStatus> {
  const octokit = getOctokit();
  const { data } = await octokit.checks.listForRef({ ...repo, ref });
  const runs = data.check_runs.map((r) => ({
    name: r.name,
    status: r.status,
    conclusion: r.conclusion,
  }));
  let state: CheckStatus["state"] = "success";
  if (runs.some((r) => r.status !== "completed")) state = "pending";
  else if (runs.some((r) => r.conclusion === "failure")) state = "failure";
  else if (runs.length === 0) state = "pending";
  return { state, runs };
}

export async function mergePr(prNumber: number): Promise<{ merged: boolean; sha: string }> {
  const octokit = getOctokit();
  const { data } = await octokit.pulls.merge({
    ...repo,
    pull_number: prNumber,
    merge_method: CMS_MERGE_METHOD,
  });
  return { merged: data.merged, sha: data.sha };
}

export async function deleteBranchIfExists(): Promise<void> {
  const octokit = getOctokit();
  try {
    await octokit.git.deleteRef({ ...repo, ref: `heads/${CMS_BRANCH_NAME}` });
  } catch (err) {
    if (!isNotFound(err)) throw err;
  }
}

export async function closePrAndDeleteBranch(prNumber: number): Promise<void> {
  const octokit = getOctokit();
  await octokit.pulls.update({ ...repo, pull_number: prNumber, state: "closed" });
  await deleteBranchIfExists();
}
