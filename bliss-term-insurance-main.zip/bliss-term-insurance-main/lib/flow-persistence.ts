import type { CustomerInfo, Residency } from "@/types";

/**
 * localStorage-backed persistence for the advisor's in-progress inputs
 * (Control Panel + Policy Panel selections) — a hard browser refresh no
 * longer wipes a call in progress. Deliberately NOT using cookies/session
 * storage: this is advisor-local scratch data, never sent to a server.
 */

const STORAGE_KEY = "ditto:flow-state:v1";

export interface PersistedFlowState {
  customer: CustomerInfo;
  policiesByResidency: Record<Residency, string[]>;
  secondaryEnabledByResidency: Record<Residency, boolean>;
}

export function loadPersistedFlowState(): PersistedFlowState | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || !parsed.customer || !parsed.policiesByResidency) return null;
    return parsed as PersistedFlowState;
  } catch {
    return null;
  }
}

export function savePersistedFlowState(state: PersistedFlowState): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Storage full or disabled (private browsing) — the session still works, just unpersisted.
  }
}

export function clearPersistedFlowState(): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.removeItem(STORAGE_KEY);
  } catch {
    // Nothing to do if storage is unavailable.
  }
}
