import { describe, expect, it } from "vitest";
import { numberToIndianWords } from "./format-indian-words";

describe("numberToIndianWords", () => {
  it("handles zero", () => {
    expect(numberToIndianWords(0)).toBe("Zero");
  });

  it("handles the user's own worked examples", () => {
    expect(numberToIndianWords(20)).toBe("Twenty");
    expect(numberToIndianWords(200)).toBe("Two Hundred");
    expect(numberToIndianWords(2000)).toBe("Two Thousand");
  });

  it("handles teens distinctly from tens", () => {
    expect(numberToIndianWords(11)).toBe("Eleven");
    expect(numberToIndianWords(19)).toBe("Nineteen");
  });

  it("handles a compound hundreds + tens value", () => {
    expect(numberToIndianWords(345)).toBe("Three Hundred Forty Five");
  });

  it("handles lakh grouping (Indian, not international)", () => {
    expect(numberToIndianWords(2_50_000)).toBe("Two Lakh Fifty Thousand");
    expect(numberToIndianWords(1_00_000)).toBe("One Lakh");
  });

  it("handles crore grouping", () => {
    expect(numberToIndianWords(4_40_00_000)).toBe("Four Crore Forty Lakh");
    expect(numberToIndianWords(1_00_00_000)).toBe("One Crore");
  });

  it("handles a full mixed-group value", () => {
    expect(numberToIndianWords(1_23_45_678)).toBe("One Crore Twenty Three Lakh Forty Five Thousand Six Hundred Seventy Eight");
  });

  it("floors fractional input", () => {
    expect(numberToIndianWords(20.9)).toBe("Twenty");
  });

  it("handles negative input", () => {
    expect(numberToIndianWords(-500)).toBe("Minus Five Hundred");
  });
});
