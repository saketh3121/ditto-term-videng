import NextAuth from "next-auth";
import Google from "next-auth/providers/google";
import { authConfig } from "@/lib/auth.config";
import { ALLOWED_EMAIL_DOMAIN, SUPER_ADMIN_EMAIL } from "@/config/auth";
import { getAdvisorByEmail } from "@/lib/content";
import { writeAdvisorFile } from "@/lib/cms/advisors";
import { sendAccessRequestEmail } from "@/lib/email";
import type { AdvisorRole } from "@/types";

/**
 * Full NextAuth config (Node runtime). Google OAuth restricted to
 * @<ALLOWED_EMAIL_DOMAIN>, then to advisors present in content/advisors/
 * (see lib/content.ts) — an in-domain account that isn't allowlisted lands
 * on the pending-access screen instead of a bare denial (see lib/email.ts).
 * `SUPER_ADMIN_EMAIL` always gets in and self-seeds its own admin entry on
 * first sign-in. Same model as ditto-health-insurance-bliss — see docs/AUTH.md.
 */
export const { handlers, auth, signIn, signOut } = NextAuth({
  ...authConfig,
  providers: [Google],
  // JWT session, sliding 7-day window: a week of inactivity forces a fresh
  // Google sign-in; regular use within the window keeps renewing it.
  session: { maxAge: 60 * 60 * 24 * 7 },
  callbacks: {
    ...authConfig.callbacks,

    async signIn({ profile }) {
      const email = (profile?.email ?? "").toLowerCase();
      const verified = Boolean(profile?.email_verified);

      if (!verified || !email.endsWith(`@${ALLOWED_EMAIL_DOMAIN}`)) {
        return false; // NextAuth shows the generic AccessDenied error on /login
      }

      if (email === SUPER_ADMIN_EMAIL) {
        const existing = await getAdvisorByEmail(email);
        if (!existing) {
          await writeAdvisorFile({ email, name: profile?.name ?? email, role: "admin" }).catch(
            (err: unknown) => console.error("[auth] super-admin auto-seed failed:", err),
          );
        }
        return true;
      }

      const advisor = await getAdvisorByEmail(email);
      if (advisor) return true;

      // In-domain but not allowlisted — queue the access request instead of a
      // bare denial. The string return value is where NextAuth redirects.
      await sendAccessRequestEmail(profile?.name ?? email, email);
      return "/login?pending=true";
    },

    async jwt({ token }) {
      // Re-read on every refresh so a newly-approved (or role-changed)
      // advisor takes effect without forcing a re-login.
      const email = token.email;
      if (email) {
        const advisor = await getAdvisorByEmail(email);
        if (advisor) {
          token.role = advisor.role;
        } else if (email.toLowerCase() === SUPER_ADMIN_EMAIL) {
          token.role = "admin"; // fallback if content/advisors/ is unreachable
        }
      }
      return token;
    },

    session({ session, token }) {
      if (session.user) {
        session.user.role = (token.role as AdvisorRole | undefined) ?? "member";
      }
      return session;
    },
  },
});
