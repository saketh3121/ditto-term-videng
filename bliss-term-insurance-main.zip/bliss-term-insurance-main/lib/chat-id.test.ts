import { describe, it, expect } from "vitest";
import { isValidChatLink, extractChatId } from "./chat-id";

describe("isValidChatLink", () => {
  it("accepts a well-formed DittoHQ chat link", () => {
    expect(isValidChatLink("https://dittohq.in/whatsapp/chats?chat=CH515923")).toBe(true);
  });

  it("tolerates leading/trailing whitespace from a paste", () => {
    expect(isValidChatLink("  https://dittohq.in/whatsapp/chats?chat=CH1  ")).toBe(true);
  });

  it("rejects blank input", () => {
    expect(isValidChatLink("")).toBe(false);
    expect(isValidChatLink("   ")).toBe(false);
  });

  it("rejects a link missing the CH-prefixed chat id", () => {
    expect(isValidChatLink("https://dittohq.in/whatsapp/chats?chat=515923")).toBe(false);
  });

  it("rejects an unrelated URL", () => {
    expect(isValidChatLink("https://example.com/CH515923")).toBe(false);
  });

  it("rejects trailing junk after the chat id", () => {
    expect(isValidChatLink("https://dittohq.in/whatsapp/chats?chat=CH515923&foo=bar")).toBe(false);
  });
});

describe("extractChatId", () => {
  it("extracts the CH id from a valid link", () => {
    expect(extractChatId("https://dittohq.in/whatsapp/chats?chat=CH515923")).toBe("CH515923");
  });

  it("returns null for an invalid link", () => {
    expect(extractChatId("not a link")).toBeNull();
  });
});
