import type { ModalBullet } from "@/components/ui/modal";

/**
 * Turns a feature's free-text "I button content" into the modal's bullet
 * shape: {label, lead?, value: string | string[]}. Pure text parsing — no
 * React, no I/O. The source data isn't structured enough to guarantee a
 * clean split every time, so a block that doesn't parse cleanly falls back
 * to a plain, label-less value rather than fabricating structure.
 */

/** Matches a lettered/roman sub-item marker OR a plain "- " dash bullet at
 * the start of a line: "a. ", "iii. ", "- ", "-Item" — the source content
 * mixes both conventions, and the modal should list both the same way. */
const SUB_ITEM = /^(?:[a-z]{1,3}\.\s+|-\s*)/i;
/** Matches a leading top-level numbering marker: "1. ", "12) ". */
const NUMBERING = /^\d{1,3}[.)]\s*/;

function normalizeForCompare(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]/g, "");
}

/** Strips a leading line that just restates the modal's own title (e.g. a
 * detailText block opening with "Instant Payout on claim intimation:" when
 * the modal is already titled "Instant Payout on Claim Intimation") — the
 * source spreadsheet often repeats the row/feature title as its own first
 * line, which otherwise surfaces as a redundant bullet label under a
 * dialog title that already says the same thing. */
function stripDuplicateTitleLine(text: string, title: string | undefined): string {
  if (!title) return text;
  const lines = text.split("\n");
  const firstIdx = lines.findIndex((l) => l.trim().length > 0);
  if (firstIdx === -1) return text;
  const firstLine = lines[firstIdx]!.trim().replace(NUMBERING, "").replace(/:\s*$/, "");
  if (normalizeForCompare(firstLine) !== normalizeForCompare(title)) return text;
  return [...lines.slice(0, firstIdx), "", ...lines.slice(firstIdx + 1)].join("\n");
}

function parseBlock(block: string): ModalBullet {
  const lines = block
    .split("\n")
    .map((l) => l.replace(NUMBERING, "").trim())
    .filter(Boolean);

  const preList: string[] = [];
  const items: string[] = [];
  let current: string | null = null;

  for (const line of lines) {
    const m = SUB_ITEM.exec(line);
    if (m) {
      if (current !== null) items.push(current);
      current = line.slice(m[0].length).trim();
    } else if (current !== null) {
      current += ` ${line}`;
    } else {
      preList.push(line);
    }
  }
  if (current !== null) items.push(current);

  if (items.length > 0) {
    return {
      label: preList[0] ?? "",
      lead: preList.length > 1 ? preList.slice(1).join(" ") : undefined,
      value: items,
    };
  }

  if (lines.length === 0) return { label: "", value: "" };
  if (lines.length === 1) {
    const colonMatch = /^([^:\n]{2,60}):\s*(.+)$/.exec(lines[0]!);
    if (colonMatch && colonMatch[2]) return { label: colonMatch[1]!.trim(), value: colonMatch[2].trim() };
    return { label: "", value: lines[0]! };
  }
  const [first, ...rest] = lines;
  const restJoined = rest.join(" ");
  return restJoined ? { label: first!, value: restJoined } : { label: "", value: first! };
}

export function parseDetailFields(text: string, title?: string): ModalBullet[] {
  return stripDuplicateTitleLine(text, title)
    .split(/\n\s*\n/)
    .map((b) => b.trim())
    .filter(Boolean)
    .map(parseBlock);
}
