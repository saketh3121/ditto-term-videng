/** Turns an email into a filesystem/URL-safe slug, e.g. `a.b@c.in` -> `a-b-c-in`. */
export function emailToSlug(email: string): string {
  return email.toLowerCase().replace(/[@.]/g, "-");
}
