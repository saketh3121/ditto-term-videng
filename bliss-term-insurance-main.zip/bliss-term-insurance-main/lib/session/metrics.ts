import {
  SESSION_MIN_SLIDES_AFTER_DETAILS,
  SESSION_QUALIFYING_COVERAGE_PCT,
} from "@/config/session-tracking";
import { ageFromDob } from "@/lib/calc/age";
import { isValidChatLink } from "@/lib/chat-id";
import { sectionById, TRACKED_SECTIONS } from "@/lib/session/sections";

/**
 * The session rules, as pure functions shared by the browser tracker (to
 * know when details are complete) and the server (which computes the flags
 * that get stored). Thresholds live in config/session-tracking.ts.
 */

export interface RequiredDetailsInput {
  chatLink: string;
  name: string;
  dob: string;
  annualIncome: string;
  monthlyExpenses: string;
}

/** The Control Panel inputs every downstream step depends on: a valid Chat ID, name, DOB, income and expenses. */
export function hasRequiredDetails(d: RequiredDetailsInput): boolean {
  return (
    isValidChatLink(d.chatLink) &&
    d.name.trim().length > 0 &&
    ageFromDob(d.dob) !== null &&
    Number(d.annualIncome) > 0 &&
    Number(d.monthlyExpenses) > 0
  );
}

export interface SessionMetrics {
  requiredDetailsComplete: boolean;
  /** Distinct presentation steps viewed (past the dwell threshold) after the required details were in. */
  slidesViewedAfterDetails: number;
  presentationEngaged: boolean;
  /** Tracked section ids viewed, in first-viewed order. */
  sectionsViewed: string[];
  sectionsTotal: number;
  /** Whole-number share of tracked sections viewed. */
  coveragePct: number;
  qualified: boolean;
}

export function computeSessionMetrics(input: {
  requiredDetailsComplete: boolean;
  sections: { id: string; firstViewedAt: string; viewedAfterDetails: boolean }[];
}): SessionMetrics {
  const unique = new Map<string, { firstViewedAt: string; viewedAfterDetails: boolean }>();
  for (const s of input.sections) {
    if (!sectionById(s.id)) continue;
    const prev = unique.get(s.id);
    unique.set(s.id, {
      firstViewedAt: prev && prev.firstViewedAt < s.firstViewedAt ? prev.firstViewedAt : s.firstViewedAt,
      viewedAfterDetails: (prev?.viewedAfterDetails ?? false) || s.viewedAfterDetails,
    });
  }
  const sectionsViewed = [...unique.entries()]
    .sort((a, b) => (a[1].firstViewedAt < b[1].firstViewedAt ? -1 : 1))
    .map(([id]) => id);

  const slidesViewedAfterDetails = [...unique.entries()].filter(
    ([id, v]) => v.viewedAfterDetails && sectionById(id)?.kind === "step",
  ).length;
  const presentationEngaged = slidesViewedAfterDetails >= SESSION_MIN_SLIDES_AFTER_DETAILS;

  const sectionsTotal = TRACKED_SECTIONS.length;
  const ratioPct = (sectionsViewed.length / sectionsTotal) * 100;

  return {
    requiredDetailsComplete: input.requiredDetailsComplete,
    slidesViewedAfterDetails,
    presentationEngaged,
    sectionsViewed,
    sectionsTotal,
    coveragePct: Math.round(ratioPct),
    // Compared on the exact ratio, not the rounded display figure.
    qualified: input.requiredDetailsComplete && presentationEngaged && ratioPct >= SESSION_QUALIFYING_COVERAGE_PCT,
  };
}
