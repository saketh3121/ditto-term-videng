import { STEPS } from "@/config/flows";
import { RESOURCES } from "@/config/resources";

/**
 * The sections that count toward a session's site coverage: every
 * presentation step (config/flows.ts) plus every Resources page
 * (config/resources.ts). Derived from those configs, so adding a step or a
 * resource automatically changes the coverage denominator.
 */

export type SectionKind = "step" | "resource";

export interface TrackedSection {
  /** "step:<StepId>" or "resource:<ResourceId>". */
  id: string;
  kind: SectionKind;
  label: string;
}

export const TRACKED_SECTIONS: readonly TrackedSection[] = [
  ...STEPS.map((s) => ({ id: `step:${s.id}`, kind: "step" as const, label: s.label })),
  ...RESOURCES.map((r) => ({ id: `resource:${r.id}`, kind: "resource" as const, label: r.label })),
];

const SECTION_IDS = new Set(TRACKED_SECTIONS.map((s) => s.id));

export function isTrackedSectionId(id: string): boolean {
  return SECTION_IDS.has(id);
}

export function sectionById(id: string): TrackedSection | undefined {
  return TRACKED_SECTIONS.find((s) => s.id === id);
}

/** Maps a pathname to its tracked section, or null for untracked pages (welcome, admin, login). */
export function sectionForPath(pathname: string | null): string | null {
  if (!pathname) return null;
  const path = pathname.replace(/\/+$/, "");
  // Resources first: their hrefs live under /flow/resources/, which would
  // otherwise look like a step path. Nested pages (e.g. a per-policy
  // Specific Illnesses page) count toward their parent resource.
  for (const r of RESOURCES) {
    if (path === r.href || path.startsWith(`${r.href}/`)) return `resource:${r.id}`;
  }
  const match = /^\/flow\/([^/]+)$/.exec(path);
  if (match) {
    const id = `step:${match[1]}`;
    if (SECTION_IDS.has(id)) return id;
  }
  return null;
}
