import { z } from "zod";
import { isValidChatLink } from "@/lib/chat-id";
import { isTrackedSectionId, TRACKED_SECTIONS } from "@/lib/session/sections";

/**
 * What the browser sends to /api/session-log. Validated server-side — this
 * is a system boundary — and deliberately carries only raw observations
 * (persona inputs, which sections were viewed and when). Every derived flag
 * (engaged, coverage, qualified) is recomputed on the server from these.
 */

export const personaInputSchema = z.object({
  name: z.string().max(200),
  gender: z.enum(["male", "female"]),
  dob: z.string().max(20),
  annualIncome: z.string().max(20),
  monthlyExpenses: z.string().max(20),
  employment: z.enum(["salaried", "self-employed"]),
  citizenship: z.enum(["indian", "nri"]),
  hasPEDs: z.boolean(),
  /** Only sent when SESSION_LOG_PED_DETAILS is on. */
  pedDetails: z.string().max(2000).optional(),
  tobaccoUser: z.boolean(),
  education: z.enum(["post-graduate", "graduate", "diploma", "hsc", "ssc", "below-10th"]),
  preferredCoverAge: z.string().max(5),
  existingCoverAmount: z.string().max(20),
  uninsuredLoans: z.string().max(20),
});

export const sectionViewSchema = z.object({
  id: z.string().refine(isTrackedSectionId, "unknown section"),
  firstViewedAt: z.iso.datetime(),
  viewedAfterDetails: z.boolean(),
});

export const sessionLogPayloadSchema = z.object({
  sessionId: z.uuid(),
  /** Increments with every send from this session; the server ignores anything older than what it has. */
  seq: z.number().int().positive(),
  chatLink: z.string().refine(isValidChatLink, "invalid chat link"),
  startedAt: z.iso.datetime(),
  detailsCompletedAt: z.iso.datetime().nullable(),
  persona: personaInputSchema,
  sections: z.array(sectionViewSchema).max(TRACKED_SECTIONS.length),
});

export type PersonaInput = z.infer<typeof personaInputSchema>;
export type SectionView = z.infer<typeof sectionViewSchema>;
export type SessionLogPayload = z.infer<typeof sessionLogPayloadSchema>;
