import { ageFromDob } from "@/lib/calc/age";
import { extractChatId } from "@/lib/chat-id";
import { computeSessionMetrics, hasRequiredDetails, type SessionMetrics } from "@/lib/session/metrics";
import type { PersonaInput, SessionLogPayload } from "@/lib/session/payload";

/**
 * The record stored per session in the chat-log repo. Built server-side
 * from a validated payload plus the signed-in advisor's identity (taken
 * from the auth session, never from the browser). Pure, so it's testable.
 */

export interface PersonaRecord {
  name: string;
  gender: PersonaInput["gender"];
  dob: string | null;
  age: number | null;
  annualIncome: number | null;
  monthlyExpenses: number | null;
  employment: PersonaInput["employment"];
  residency: PersonaInput["citizenship"];
  hasPEDs: boolean;
  pedDetails?: string;
  tobaccoUser: boolean;
  education: PersonaInput["education"];
  preferredCoverAge: number | null;
  existingCoverAmount: number | null;
  uninsuredLoans: number | null;
}

export interface SessionRecord extends SessionMetrics {
  schemaVersion: 1;
  sessionId: string;
  chatId: string;
  chatLink: string;
  advisorEmail: string;
  advisorName: string;
  /** When the Chat ID was first saved for this session. */
  startedAt: string;
  /** When the required details were first all present; null if never. */
  detailsCompletedAt: string | null;
  updatedAt: string;
  persona: PersonaRecord;
  /** Send counter — later writes win, out-of-order ones are ignored. */
  seq: number;
}

const num = (raw: string): number | null => {
  const n = Number(raw);
  return raw.trim() !== "" && Number.isFinite(n) ? n : null;
};

function toPersonaRecord(p: PersonaInput, now: Date): PersonaRecord {
  return {
    name: p.name.trim(),
    gender: p.gender,
    dob: p.dob || null,
    age: ageFromDob(p.dob, now),
    annualIncome: num(p.annualIncome),
    monthlyExpenses: num(p.monthlyExpenses),
    employment: p.employment,
    residency: p.citizenship,
    hasPEDs: p.hasPEDs,
    ...(p.pedDetails !== undefined ? { pedDetails: p.pedDetails } : {}),
    tobaccoUser: p.tobaccoUser,
    education: p.education,
    preferredCoverAge: num(p.preferredCoverAge),
    existingCoverAmount: num(p.existingCoverAmount),
    uninsuredLoans: num(p.uninsuredLoans),
  };
}

export function buildSessionRecord(
  payload: SessionLogPayload,
  advisor: { email: string; name: string },
  now: Date,
): SessionRecord {
  const requiredDetailsComplete = hasRequiredDetails({ chatLink: payload.chatLink, ...payload.persona });
  // "After details" views only make sense once details were complete at some point.
  const sections = payload.detailsCompletedAt
    ? payload.sections
    : payload.sections.map((s) => ({ ...s, viewedAfterDetails: false }));
  return {
    schemaVersion: 1,
    sessionId: payload.sessionId,
    chatId: extractChatId(payload.chatLink) ?? "",
    chatLink: payload.chatLink.trim(),
    advisorEmail: advisor.email,
    advisorName: advisor.name,
    startedAt: payload.startedAt,
    detailsCompletedAt: payload.detailsCompletedAt,
    updatedAt: now.toISOString(),
    persona: toPersonaRecord(payload.persona, now),
    ...computeSessionMetrics({ requiredDetailsComplete, sections }),
    seq: payload.seq,
  };
}

/** sessions/<IST start date>/<chatId>_<sessionId>.json — one small file per session. */
export function sessionRecordPath(record: Pick<SessionRecord, "startedAt" | "chatId" | "sessionId">): string {
  const ist = new Date(new Date(record.startedAt).getTime() + 5.5 * 60 * 60 * 1000);
  const day = ist.toISOString().slice(0, 10);
  return `sessions/${day}/${record.chatId}_${record.sessionId}.json`;
}
