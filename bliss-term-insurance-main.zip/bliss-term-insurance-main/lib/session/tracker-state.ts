import { SESSION_LOG_PED_DETAILS, SESSION_MIN_DWELL_MS } from "@/config/session-tracking";
import { isValidChatLink } from "@/lib/chat-id";
import { hasRequiredDetails } from "@/lib/session/metrics";
import type { PersonaInput, SessionLogPayload } from "@/lib/session/payload";
import type { CustomerInfo } from "@/types";

/**
 * The browser tracker's state machine, as pure transitions (the React side
 * in components/session-tracker.tsx only wires these to timers, routing and
 * localStorage).
 *
 * Session lifecycle — one session per customer call:
 * - Pages viewed before a Chat ID is saved are kept and count toward the
 *   session that starts when it is (same flow, same customer).
 * - Saving a valid Chat ID starts the session with a fresh id. Re-saving the
 *   same Chat ID (or reloading the page) continues it — no duplicates.
 * - Saving a different Chat ID, or Start Over, ends it; the ended state is
 *   returned so its final snapshot can still be sent.
 */

export interface SectionDwell {
  dwellMs: number;
  /** Visible time accumulated only while the required details were complete. */
  dwellAfterDetailsMs: number;
  /** Set once dwellMs crosses SESSION_MIN_DWELL_MS. */
  firstViewedAt: string | null;
  viewedAfterDetails: boolean;
}

export interface TrackerState {
  sessionId: string | null;
  /** The saved chat link this session belongs to; "" before a session starts. */
  chatLink: string;
  startedAt: string | null;
  detailsCompletedAt: string | null;
  /** Latest saved persona — kept here so the final snapshot survives Start Over clearing the form. */
  persona: PersonaInput | null;
  sections: Record<string, SectionDwell>;
  /** Number of sends so far. */
  seq: number;
  /** Serialized payload of the last successful send — skips sends when nothing reportable changed. */
  lastSentKey: string | null;
}

export function emptyTracker(): TrackerState {
  return {
    sessionId: null,
    chatLink: "",
    startedAt: null,
    detailsCompletedAt: null,
    persona: null,
    sections: {},
    seq: 0,
    lastSentKey: null,
  };
}

export function personaFromCustomer(c: CustomerInfo): PersonaInput {
  return {
    name: c.name,
    gender: c.gender,
    dob: c.dob,
    annualIncome: c.annualIncome,
    monthlyExpenses: c.monthlyExpenses,
    employment: c.employment,
    citizenship: c.citizenship,
    hasPEDs: c.hasPEDs,
    ...(SESSION_LOG_PED_DETAILS && c.hasPEDs ? { pedDetails: c.pedDetails } : {}),
    tobaccoUser: c.tobaccoUser,
    education: c.education,
    preferredCoverAge: c.preferredCoverAge,
    existingCoverAmount: c.existingCoverAmount,
    uninsuredLoans: c.uninsuredLoans,
  };
}

function detailsComplete(state: TrackerState): boolean {
  return state.persona !== null && hasRequiredDetails({ chatLink: state.chatLink, ...state.persona });
}

function withPersona(state: TrackerState, customer: CustomerInfo, now: Date): TrackerState {
  const next = { ...state, persona: personaFromCustomer(customer) };
  if (next.detailsCompletedAt === null && detailsComplete(next)) next.detailsCompletedAt = now.toISOString();
  return next;
}

/** Reconciles the tracker with the saved Control Panel state. */
export function syncWithCustomer(
  state: TrackerState,
  customer: CustomerInfo,
  now: Date,
  newSessionId: () => string,
): { next: TrackerState; ended: TrackerState | null } {
  const link = customer.chatId.trim();

  if (!isValidChatLink(link)) {
    // No saved Chat ID: either nothing started yet, or Start Over just cleared it.
    return state.sessionId ? { next: emptyTracker(), ended: state } : { next: state, ended: null };
  }

  if (state.sessionId && state.chatLink === link) {
    return { next: withPersona(state, customer, now), ended: null };
  }

  const started: TrackerState = {
    ...(state.sessionId ? emptyTracker() : state), // a different customer's call starts clean
    sessionId: newSessionId(),
    chatLink: link,
    startedAt: now.toISOString(),
    detailsCompletedAt: null,
    seq: 0,
    lastSentKey: null,
  };
  return { next: withPersona(started, customer, now), ended: state.sessionId ? state : null };
}

/** Adds visible on-screen time to a section. */
export function addDwell(state: TrackerState, sectionId: string, ms: number, now: Date): TrackerState {
  const prev = state.sections[sectionId] ?? {
    dwellMs: 0,
    dwellAfterDetailsMs: 0,
    firstViewedAt: null,
    viewedAfterDetails: false,
  };
  const afterDetails = detailsComplete(state);
  const dwellMs = prev.dwellMs + ms;
  const dwellAfterDetailsMs = prev.dwellAfterDetailsMs + (afterDetails ? ms : 0);
  const section: SectionDwell = {
    dwellMs,
    dwellAfterDetailsMs,
    firstViewedAt: prev.firstViewedAt ?? (dwellMs >= SESSION_MIN_DWELL_MS ? now.toISOString() : null),
    viewedAfterDetails: prev.viewedAfterDetails || dwellAfterDetailsMs >= SESSION_MIN_DWELL_MS,
  };
  return { ...state, sections: { ...state.sections, [sectionId]: section } };
}

/** The reportable snapshot (without seq), or null while there's no session to report. */
export function toPayload(state: TrackerState): Omit<SessionLogPayload, "seq"> | null {
  if (!state.sessionId || !state.startedAt || !state.persona) return null;
  return {
    sessionId: state.sessionId,
    chatLink: state.chatLink,
    startedAt: state.startedAt,
    detailsCompletedAt: state.detailsCompletedAt,
    persona: state.persona,
    sections: Object.entries(state.sections)
      .filter((entry): entry is [string, SectionDwell & { firstViewedAt: string }] => entry[1].firstViewedAt !== null)
      .map(([id, s]) => ({ id, firstViewedAt: s.firstViewedAt, viewedAfterDetails: s.viewedAfterDetails })),
  };
}
