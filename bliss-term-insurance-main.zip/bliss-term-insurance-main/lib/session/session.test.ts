import { describe, it, expect } from "vitest";
import { DEFAULT_CUSTOMER } from "@/config/defaults";
import { SESSION_MIN_DWELL_MS } from "@/config/session-tracking";
import { computeSessionMetrics, hasRequiredDetails } from "./metrics";
import { sessionLogPayloadSchema } from "./payload";
import { buildSessionRecord, sessionRecordPath } from "./record";
import { sectionForPath, TRACKED_SECTIONS } from "./sections";
import { addDwell, emptyTracker, syncWithCustomer, toPayload, type TrackerState } from "./tracker-state";
import type { CustomerInfo } from "@/types";

const LINK_A = "https://dittohq.in/whatsapp/chats?chat=CH515923";
const LINK_B = "https://dittohq.in/whatsapp/chats?chat=CH600001";
const NOW = new Date("2026-10-13T06:00:00.000Z");
const at = (s: number) => new Date(NOW.getTime() + s * 1000);

const complete: CustomerInfo = {
  ...DEFAULT_CUSTOMER,
  chatId: LINK_A,
  name: "Saketh Rao",
  dob: "1996-01-01",
  annualIncome: "4500000",
  monthlyExpenses: "100000",
};

let n = 0;
const nextId = () => `00000000-0000-4000-8000-${String(++n).padStart(12, "0")}`;

/** Views `ids` in order for `seconds` each. */
function view(state: TrackerState, ids: string[], seconds: number, start = 0): TrackerState {
  let s = state;
  ids.forEach((id, i) => {
    for (let t = 0; t < seconds; t++) s = addDwell(s, id, 1000, at(start + i * seconds + t));
  });
  return s;
}

describe("sectionForPath", () => {
  it("tracks the 7 presentation steps and 2 Resources pages", () => {
    expect(TRACKED_SECTIONS).toHaveLength(9);
    expect(sectionForPath("/flow/cover-amount")).toBe("step:cover-amount");
    expect(sectionForPath("/flow/why-ditto/")).toBe("step:why-ditto");
    expect(sectionForPath("/flow/resources/inbuilt-features")).toBe("resource:inbuilt-features");
    expect(sectionForPath("/flow/resources/specific-illnesses/hdfc-c2p-supreme")).toBe("resource:specific-illnesses");
  });

  it("ignores pages outside the presentation", () => {
    for (const p of ["/", "/admin", "/login", "/flow/not-a-step", null]) expect(sectionForPath(p)).toBeNull();
  });
});

describe("hasRequiredDetails", () => {
  const base = { chatLink: LINK_A, name: "A", dob: "1996-01-01", annualIncome: "1", monthlyExpenses: "1" };
  it("needs a valid chat link, name, DOB, income and expenses", () => {
    expect(hasRequiredDetails(base)).toBe(true);
    expect(hasRequiredDetails({ ...base, chatLink: "CH1" })).toBe(false);
    expect(hasRequiredDetails({ ...base, name: " " })).toBe(false);
    expect(hasRequiredDetails({ ...base, dob: "" })).toBe(false);
    expect(hasRequiredDetails({ ...base, annualIncome: "" })).toBe(false);
    expect(hasRequiredDetails({ ...base, monthlyExpenses: "0" })).toBe(false);
  });
});

describe("tracker session lifecycle", () => {
  it("keeps pre-session views and starts a session when a Chat ID is saved", () => {
    let s = view(emptyTracker(), ["step:eligibility"], 6);
    expect(toPayload(s)).toBeNull();
    const { next, ended } = syncWithCustomer(s, complete, NOW, nextId);
    s = next;
    expect(ended).toBeNull();
    expect(s.sessionId).not.toBeNull();
    expect(toPayload(s)?.sections.map((x) => x.id)).toEqual(["step:eligibility"]);
    expect(s.detailsCompletedAt).toBe(NOW.toISOString());
  });

  it("re-saving the same Chat ID continues the same session (no duplicate)", () => {
    const first = syncWithCustomer(emptyTracker(), complete, NOW, nextId).next;
    const again = syncWithCustomer(first, { ...complete, name: "Saketh R" }, at(60), nextId);
    expect(again.ended).toBeNull();
    expect(again.next.sessionId).toBe(first.sessionId);
    expect(again.next.persona?.name).toBe("Saketh R");
    expect(again.next.detailsCompletedAt).toBe(NOW.toISOString());
  });

  it("a different Chat ID ends the session and starts a clean one", () => {
    const a = view(syncWithCustomer(emptyTracker(), complete, NOW, nextId).next, ["step:cover-amount"], 6);
    const { next, ended } = syncWithCustomer(a, { ...complete, chatId: LINK_B }, at(100), nextId);
    expect(ended?.sessionId).toBe(a.sessionId);
    expect(next.sessionId).not.toBe(a.sessionId);
    expect(next.sections).toEqual({});
  });

  it("Start Over ends the session and keeps its last persona for the final send", () => {
    const a = syncWithCustomer(emptyTracker(), complete, NOW, nextId).next;
    const { next, ended } = syncWithCustomer(a, DEFAULT_CUSTOMER, at(10), nextId);
    expect(next).toEqual(emptyTracker());
    expect(ended && toPayload(ended)?.persona.name).toBe("Saketh Rao");
  });
});

describe("dwell (false-positive guard)", () => {
  const started = () => syncWithCustomer(emptyTracker(), complete, NOW, nextId).next;

  it("doesn't count a section until it has been on screen for the minimum dwell", () => {
    const seconds = SESSION_MIN_DWELL_MS / 1000;
    expect(toPayload(view(started(), ["step:riders"], seconds - 1))?.sections).toEqual([]);
    expect(toPayload(view(started(), ["step:riders"], seconds))?.sections).toHaveLength(1);
  });

  it("clicking rapidly through every step counts nothing", () => {
    const allSteps = TRACKED_SECTIONS.map((s) => s.id);
    expect(toPayload(view(started(), allSteps, 1))?.sections).toEqual([]);
  });

  it("only credits 'after details' time once the required details are complete", () => {
    const incomplete = syncWithCustomer(emptyTracker(), { ...complete, monthlyExpenses: "" }, NOW, nextId).next;
    const s = view(incomplete, ["step:cover-amount"], 6);
    expect(toPayload(s)?.sections[0]?.viewedAfterDetails).toBe(false);
    expect(s.detailsCompletedAt).toBeNull();
  });
});

describe("computeSessionMetrics", () => {
  const v = (id: string, after = true) => ({ id, firstViewedAt: NOW.toISOString(), viewedAfterDetails: after });

  it("needs more than a third of the site: 3 of 9 sections is 33% (not qualified), 4 of 9 is 44% (qualified)", () => {
    const three = computeSessionMetrics({
      requiredDetailsComplete: true,
      sections: [v("step:eligibility"), v("step:cover-amount"), v("step:recommendations")],
    });
    expect(three.coveragePct).toBe(33);
    expect(three.presentationEngaged).toBe(true);
    expect(three.qualified).toBe(false);

    const four = computeSessionMetrics({ requiredDetailsComplete: true, sections: [...[
      "step:eligibility", "step:cover-amount", "step:recommendations", "resource:inbuilt-features",
    ].map((id) => v(id))] });
    expect(four.coveragePct).toBe(44);
    expect(four.qualified).toBe(true);
  });

  it("engagement counts presentation steps only, viewed after details", () => {
    const m = computeSessionMetrics({
      requiredDetailsComplete: true,
      sections: [v("step:eligibility"), v("resource:inbuilt-features"), v("resource:specific-illnesses"), v("step:riders", false)],
    });
    expect(m.slidesViewedAfterDetails).toBe(1);
    expect(m.presentationEngaged).toBe(false);
    expect(m.qualified).toBe(false);
  });

  it("never qualifies without the required details", () => {
    const ids = TRACKED_SECTIONS.map((s) => s.id);
    expect(computeSessionMetrics({ requiredDetailsComplete: false, sections: ids.map((id) => v(id)) }).qualified).toBe(false);
  });

  it("dedupes repeated section ids", () => {
    const m = computeSessionMetrics({ requiredDetailsComplete: true, sections: [v("step:riders"), v("step:riders")] });
    expect(m.sectionsViewed).toEqual(["step:riders"]);
  });
});

describe("payload validation + stored record", () => {
  const payload = () => {
    let s = syncWithCustomer(emptyTracker(), complete, NOW, nextId).next;
    s = view(s, ["step:eligibility", "step:cover-amount", "step:recommendations", "step:riders"], 6);
    return { ...toPayload(s)!, seq: 3 };
  };

  it("accepts what the tracker sends", () => {
    expect(sessionLogPayloadSchema.safeParse(payload()).success).toBe(true);
  });

  it("rejects unknown sections, bad chat links and bad ids", () => {
    const p = payload();
    expect(sessionLogPayloadSchema.safeParse({ ...p, sections: [{ ...p.sections[0], id: "step:hacked" }] }).success).toBe(false);
    expect(sessionLogPayloadSchema.safeParse({ ...p, chatLink: "CH1" }).success).toBe(false);
    expect(sessionLogPayloadSchema.safeParse({ ...p, sessionId: "abc" }).success).toBe(false);
  });

  it("builds the stored record with server-side identity and recomputed flags", () => {
    const r = buildSessionRecord(sessionLogPayloadSchema.parse(payload()), { email: "a@joinditto.in", name: "A" }, NOW);
    expect(r).toMatchObject({
      chatId: "CH515923",
      advisorEmail: "a@joinditto.in",
      requiredDetailsComplete: true,
      presentationEngaged: true,
      coveragePct: 44,
      qualified: true,
      seq: 3,
    });
    expect(r.persona).toMatchObject({ name: "Saketh Rao", age: 30, monthlyExpenses: 100000, annualIncome: 4500000 });
    expect(r.persona).not.toHaveProperty("pedDetails");
  });

  it("ignores 'after details' claims when details were never completed", () => {
    const p = sessionLogPayloadSchema.parse({ ...payload(), detailsCompletedAt: null });
    expect(buildSessionRecord(p, { email: "a", name: "A" }, NOW).presentationEngaged).toBe(false);
  });

  it("files sessions by their IST start date", () => {
    expect(sessionRecordPath({ startedAt: "2026-10-13T20:00:00.000Z", chatId: "CH1", sessionId: "s" })).toBe(
      "sessions/2026-10-14/CH1_s.json",
    );
  });
});
