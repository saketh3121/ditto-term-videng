import { describe, it, expect } from "vitest";
import { buildSummaryModel, missingSummaryFields } from "./summary-model";
import { fillTemplate } from "./format";
import { formatRupees } from "@/lib/calc/cover";
import { DEFAULT_CUSTOMER } from "@/config/defaults";
import pdfSummaryContent from "@/content/pdf-summary.json";
import chromeContent from "@/content/chrome.json";
import hdfc from "@/content/insurers/hdfc-life.json";
import icici from "@/content/insurers/icici-prudential.json";
import type { ChromeContent, CustomerInfo, Insurer, PdfSummaryContent } from "@/types";

const content = (pdfSummaryContent as PdfSummaryContent).pdf;
const labels = (chromeContent as ChromeContent).controlPanel;
const insurers = [hdfc, icici] as Insurer[];

const customer: CustomerInfo = {
  ...DEFAULT_CUSTOMER,
  name: "Saketh Rao",
  dob: "1996-01-01",
  annualIncome: "4500000",
  monthlyExpenses: "100000",
  preferredCoverAge: "70",
  uninsuredLoans: "2100000",
  existingCoverAmount: "4800000",
  education: "post-graduate",
  citizenship: "nri",
  tobaccoUser: true,
};

const build = (overrides: Partial<CustomerInfo> = {}) =>
  buildSummaryModel({
    customer: { ...customer, ...overrides },
    age: 30,
    insurers,
    advisorName: "  Divya Jain ",
    discussedOn: "12 October 2026",
    content,
    labels,
  });

describe("buildSummaryModel", () => {
  it("prints the same Basic figures the Cover Amount screen shows", () => {
    const m = build();
    expect(m.baseCover).toBe(6_70_00_000);
    expect(m.loansRounded).toBe(25_00_000);
    expect(m.existingRounded).toBe(50_00_000);
    expect(m.suggestedCover).toBe(6_45_00_000);
    expect(m.hasBreakdown).toBe(true);
    expect(m.termYears).toBe(40);
    expect(m.coverEndAge).toBe(70);
  });

  it("peaks its NPV curve at the base cover's unrounded need", () => {
    const m = build();
    expect(m.peakAge).toBe(50);
    expect(Math.round(m.peakNpv / 1_000_000) * 1_000_000).toBe(m.baseCover);
  });

  it("samples the outlook every 5 years and always ends on the final age", () => {
    const ages = build({ preferredCoverAge: "62" }).outlookRows.map((r) => r.age);
    expect(ages).toEqual([30, 35, 40, 45, 50, 55, 60, 62]);
  });

  it("plots every year when the horizon is short", () => {
    const m = buildSummaryModel({
      customer: { ...customer, preferredCoverAge: "63" },
      age: 58,
      insurers,
      advisorName: "A",
      discussedOn: "",
      content,
      labels,
    });
    expect(m.outlookRows.map((r) => r.age)).toEqual([58, 59, 60, 61, 62, 63]);
  });

  it("labels the curve with its own peak, and flags when the ₹50L floor lifted the base above it", () => {
    const normal = build();
    expect(normal.peakNeedRounded).toBe(normal.baseCover);
    expect(normal.floorApplied).toBe(false);

    const floored = buildSummaryModel({
      customer: { ...customer, monthlyExpenses: "45000", preferredCoverAge: "63" },
      age: 58,
      insurers,
      advisorName: "A",
      discussedOn: "",
      content,
      labels,
    });
    expect(floored.baseCover).toBe(50_00_000);
    expect(floored.peakNeedRounded).toBeLessThan(floored.baseCover);
    expect(floored.floorApplied).toBe(true);
  });

  it("formats loans and existing cover the way the site does", () => {
    const { lead } = build();
    expect(lead.rows.find((r) => r.icon === "uninsuredLoans")?.value).toBe(formatRupees(21_00_000));
    expect(lead.rows.find((r) => r.icon === "existingCover")?.value).toBe("₹48.0 L");
  });

  it("uses the Control Panel's own value labels", () => {
    const { lead } = build();
    expect(lead.residency).toBe(labels.citizenshipNri);
    expect(lead.tobacco).toBe(labels.tobaccoYes);
    expect(lead.rows.find((r) => r.icon === "education")?.value).toBe(labels.educationPostGraduate);
    expect(lead.rows.find((r) => r.icon === "employment")?.value).toBe(labels.employmentSalaried);
  });

  it("shows 'None' for loans/existing cover that weren't entered, and no breakdown", () => {
    const m = build({ uninsuredLoans: "", existingCoverAmount: "" });
    expect(m.hasBreakdown).toBe(false);
    expect(m.lead.rows.find((r) => r.icon === "uninsuredLoans")?.value).toBe(content.personal.none);
  });

  it("maps every insurer in content/insurers to a PDF-safe PNG logo", () => {
    for (const row of build().insurers) expect(row.logo).toMatch(/\.png$/);
  });

  it("trims the advisor name and derives a first name", () => {
    const m = build();
    expect(m.advisorName).toBe("Divya Jain");
    expect(m.advisorFirstName).toBe("Divya");
  });

  it("hides Limited Pay when no standard option fits inside the cover", () => {
    const m = buildSummaryModel({
      customer: { ...customer, preferredCoverAge: "63" },
      age: 58,
      insurers,
      advisorName: "A",
      discussedOn: "",
      content,
      labels,
    });
    expect(m.payments.limited).toBeNull();
  });

  it("offers retirement and limited-pay options to a 30-year-old covered to 70", () => {
    const { payments } = build();
    expect(payments.retirement).toEqual({ age: 60, pct: 30 / 40 });
    expect(payments.limited?.n).toBe(10);
    expect(payments.decades).toBe("30s and 40s");
  });
});

describe("missingSummaryFields", () => {
  it("lists everything a blank session is missing", () => {
    expect(
      missingSummaryFields({ customer: DEFAULT_CUSTOMER, age: null, insurerCount: 0, advisorName: " " }),
    ).toEqual(["name", "dob", "monthlyExpenses", "insurers", "advisorName"]);
  });

  it("is empty when the session has what the PDF needs", () => {
    expect(missingSummaryFields({ customer, age: 30, insurerCount: 2, advisorName: "Divya" })).toEqual([]);
  });
});

describe("format helpers", () => {
  it("fills every occurrence of a token", () => {
    expect(fillTemplate("{a} and {a}, {b}", { a: 1, b: "x" })).toBe("1 and 1, x");
  });
});
