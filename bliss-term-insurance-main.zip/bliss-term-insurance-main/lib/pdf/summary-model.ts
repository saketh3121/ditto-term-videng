import { ASSUMPTIONS } from "@/config/assumptions";
import { BASIC_COVER_ROUNDING, DEFAULT_INFLATION_RATE } from "@/config/milestone-assumptions";
import { computeBasicCoverSummary, formatRupees } from "@/lib/calc/cover";
import { computeNpvCurve, type NpvCurveRow } from "@/lib/calc/expense-projection";
import { incomePerYear, rupeesPerMonth } from "@/lib/pdf/format";
import type { ControlPanelContent, CustomerInfo, EducationLevel, Insurer, PdfDocumentContent } from "@/types";

/**
 * Builds everything the customer summary PDF prints, from the live call's
 * Control Panel data, the advisor's selected insurers, and the Basic cover
 * engine (computeBasicCoverSummary — the same function the Cover Amount
 * screen renders, so the PDF can never disagree with what the customer saw).
 * Pure; no React, no react-pdf.
 *
 * Adapted from the source app's milestone-aware model: no life-stage
 * milestones, tiers or personal goals (Advanced mode isn't in the customer
 * flow), so the outlook is a single inflation-only series and the NPV curve
 * is Basic's own worst-case-claim-age curve.
 */

export type DetailRowIcon =
  | "employment"
  | "education"
  | "annualIncome"
  | "monthlyExpenses"
  | "uninsuredLoans"
  | "existingCover";

export interface DetailRow {
  icon: DetailRowIcon;
  label: string;
  value: string;
}

export interface PdfInsurerRow {
  id: string;
  name: string;
  /** PNG path, or null when content/pdf-summary.json has no logo for this insurer. */
  logo: string | null;
  csr: number;
  asr: number;
  complaintsPer10k: number;
  annualBusinessCrore: number;
}

export interface PaymentsModel {
  totalYears: number;
  retirement: { age: number; pct: number } | null;
  limited: { n: number; stopAge: number; freeYears: number; pct: number; options: number[] } | null;
  older: boolean;
  decades: string;
}

export interface SummaryModel {
  lead: { name: string; age: number; residency: string; tobacco: string; rows: DetailRow[] };
  advisorName: string;
  advisorFirstName: string;
  discussedOn: string;
  inflationRate: number;
  /** Age the policy runs to — current age + policy term. */
  coverEndAge: number;
  termYears: number;
  /** Last age on the expense outlook / NPV horizon. */
  projectionEndAge: number;
  outlookRows: { age: number; annual: number }[];
  baseCover: number;
  loansRounded: number;
  existingRounded: number;
  /** Base + loans − existing: the headline "suggested cover". */
  suggestedCover: number;
  hasBreakdown: boolean;
  npvRows: NpvCurveRow[];
  peakAge: number | null;
  peakNpv: number;
  /** The curve's peak, rounded the way Basic rounds (nearest ₹10L) — what the chart labels. */
  peakNeedRounded: number;
  /** True when BASIC_COVER_FLOOR lifted the base cover above the peak need. */
  floorApplied: boolean;
  insurers: PdfInsurerRow[];
  payments: PaymentsModel;
  whatsappNumber: string;
}

export interface SummaryModelInput {
  customer: CustomerInfo;
  /** Derived from customer.dob by the caller (see lib/calc/age.ts). */
  age: number;
  /** Insurers behind the advisor's selected policies, in display order. */
  insurers: Insurer[];
  advisorName: string;
  /** Display string, e.g. "12 October 2026". */
  discussedOn: string;
  content: PdfDocumentContent;
  /** Control Panel labels — reused so value labels (Salaried, Graduate, NRI…) have one source. */
  labels: ControlPanelContent;
}

export type MissingSummaryField = "name" | "dob" | "monthlyExpenses" | "insurers" | "advisorName";

/** What still has to be filled in before a PDF is worth printing for a customer. */
export function missingSummaryFields(input: {
  customer: CustomerInfo;
  age: number | null;
  insurerCount: number;
  advisorName: string;
}): MissingSummaryField[] {
  const missing: MissingSummaryField[] = [];
  if (!input.customer.name.trim()) missing.push("name");
  if (input.age === null) missing.push("dob");
  if (!(Number(input.customer.monthlyExpenses) > 0)) missing.push("monthlyExpenses");
  if (input.insurerCount === 0) missing.push("insurers");
  if (!input.advisorName.trim()) missing.push("advisorName");
  return missing;
}

function educationLabel(level: EducationLevel, labels: ControlPanelContent): string {
  const map: Record<EducationLevel, string> = {
    "post-graduate": labels.educationPostGraduate,
    graduate: labels.educationGraduate,
    diploma: labels.educationDiploma,
    hsc: labels.educationHsc,
    ssc: labels.educationSsc,
    "below-10th": labels.educationBelow10th,
  };
  return map[level];
}

export function buildSummaryModel({
  customer,
  age,
  insurers,
  advisorName,
  discussedOn,
  content,
  labels,
}: SummaryModelInput): SummaryModel {
  const monthlyExpense = Number(customer.monthlyExpenses) || 0;
  const annualIncome = Number(customer.annualIncome) || 0;
  const uninsuredLoans = Number(customer.uninsuredLoans) || 0;
  const existingCover = Number(customer.existingCoverAmount) || 0;
  const targetAge = Number(customer.preferredCoverAge) || undefined;

  const cover = computeBasicCoverSummary({ age, monthlyExpense, targetAge, uninsuredLoans, existingCover });
  const npv = computeNpvCurve({ currentAge: age, monthlyExpense, horizonEndAge: cover.horizonEndAge });

  // Outlook bars: current age, every 5 years (every year for short
  // horizons, which would otherwise show just two bars), and the final year.
  const last = cover.projection[cover.projection.length - 1];
  const interval = cover.projection.length <= 11 ? 1 : 5;
  const outlookRows = cover.projection
    .filter((p, i) => i % interval === 0 || p === last)
    .map((p) => ({ age: p.age, annual: p.annualExpense }));

  // The curve's peak is the raw need; the base cover is that rounded to the
  // nearest ₹10L, then floored at BASIC_COVER_FLOOR. When the floor lifts
  // it, the PDF says so rather than labelling the curve with a number that
  // isn't on it.
  const peakNeedRounded = Math.round(npv.peakNpv / BASIC_COVER_ROUNDING) * BASIC_COVER_ROUNDING;

  const p = content.personal;
  const rows: DetailRow[] = [
    {
      icon: "employment",
      label: p.rows.employment,
      value: customer.employment === "salaried" ? labels.employmentSalaried : labels.employmentSelfEmployed,
    },
    { icon: "education", label: p.rows.education, value: educationLabel(customer.education, labels) },
    { icon: "annualIncome", label: p.rows.annualIncome, value: incomePerYear(annualIncome) },
    { icon: "monthlyExpenses", label: p.rows.monthlyExpenses, value: rupeesPerMonth(monthlyExpense) },
    { icon: "uninsuredLoans", label: p.rows.uninsuredLoans, value: uninsuredLoans > 0 ? formatRupees(uninsuredLoans) : p.none },
    { icon: "existingCover", label: p.rows.existingCover, value: existingCover > 0 ? formatRupees(existingCover) : p.none },
  ];

  const name = advisorName.trim();
  const coverEndAge = age + cover.termYears;

  return {
    lead: {
      name: customer.name.trim(),
      age,
      residency: customer.citizenship === "nri" ? labels.citizenshipNri : labels.citizenshipIndian,
      tobacco: customer.tobaccoUser ? labels.tobaccoYes : labels.tobaccoNo,
      rows,
    },
    advisorName: name,
    advisorFirstName: name.split(/\s+/)[0] ?? name,
    discussedOn,
    inflationRate: DEFAULT_INFLATION_RATE,
    coverEndAge,
    termYears: cover.termYears,
    projectionEndAge: cover.horizonEndAge,
    outlookRows,
    baseCover: cover.coverAmount,
    loansRounded: cover.loansRounded,
    existingRounded: cover.existingRounded,
    suggestedCover: cover.purchaseNow,
    hasBreakdown: cover.loansRounded > 0 || cover.existingRounded > 0,
    npvRows: npv.rows,
    peakAge: npv.peakAge,
    peakNpv: npv.peakNpv,
    peakNeedRounded,
    floorApplied: cover.coverAmount > peakNeedRounded,
    insurers: insurers.map((i) => ({
      id: i.id,
      name: i.name,
      logo: content.insurerLogos[i.id] ?? null,
      csr: i.csr,
      asr: i.asr,
      complaintsPer10k: i.complaintsPer10k,
      annualBusinessCrore: i.annualBusinessCrore,
    })),
    payments: buildPaymentsModel(age, coverEndAge, content.payments.cards.limited),
    whatsappNumber: content.whatsappNumber,
  };
}

function buildPaymentsModel(
  startAge: number,
  endAge: number,
  cfg: PdfDocumentContent["payments"]["cards"]["limited"],
): PaymentsModel {
  const totalYears = Math.max(1, endAge - startAge);
  const retirementAge = ASSUMPTIONS.retirementAge;
  const retirement =
    startAge <= retirementAge - 5 && retirementAge < endAge
      ? { age: retirementAge, pct: (retirementAge - startAge) / totalYears }
      : null;

  // Example tenure: content's `exampleYears` whenever it leaves at least half
  // the cover premium-free; otherwise the largest option that does. Never an
  // option that runs past the cover. No option fits at all (within 5 years of
  // cover end) → Limited Pay isn't a real choice, so it's hidden.
  const options = cfg.options.filter((n) => n < totalYears);
  const halfOrLess = options.filter((n) => n / totalYears <= 0.5);
  const n = halfOrLess.includes(cfg.exampleYears)
    ? cfg.exampleYears
    : (halfOrLess[halfOrLess.length - 1] ?? options[0] ?? Math.max(1, totalYears - 1));
  const stopAge = startAge + n;
  const limited = options.length
    ? { n, stopAge, freeYears: Math.max(0, endAge - stopAge), pct: n / totalYears, options }
    : null;

  // "In your 30s and 40s" stops describing the customer from 45 on.
  const older = startAge >= 45;
  const stops = (options.length ? options : [n]).map((y) => startAge + y);
  const lo = Math.floor(Math.min(...stops) / 10) * 10;
  const hi = Math.floor(Math.max(...stops) / 10) * 10;
  const decades = lo === hi ? `${lo}s` : `${lo}s and ${hi}s`;
  return { totalYears, retirement, limited, older, decades };
}
