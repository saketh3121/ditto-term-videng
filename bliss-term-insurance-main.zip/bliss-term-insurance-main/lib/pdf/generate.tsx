"use client";

import type { SummaryModel } from "@/lib/pdf/summary-model";

/**
 * Browser-only PDF generation + download. @react-pdf/renderer and the
 * document tree are dynamically imported so the (heavy) PDF stack loads only
 * when an advisor actually clicks Download — never in the main bundle.
 */
export async function generateSummaryPdfBlob(model: SummaryModel): Promise<Blob> {
  const [{ pdf }, { SummaryDocument }] = await Promise.all([
    import("@react-pdf/renderer"),
    import("@/components/pdf/summary-document"),
  ]);
  return pdf(<SummaryDocument model={model} />).toBlob();
}

export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
