/**
 * Formatters for the customer summary PDF. Cover figures deliberately use
 * the site's own formatRupees (lib/calc/cover.ts) so the PDF shows exactly
 * what the Cover Amount screen shows; these are only the PDF-specific
 * notations (axis ticks, per-year/per-month rows, template fill). Kept free
 * of @react-pdf/renderer so the model builder stays unit-testable.
 */

const trimZeros = (s: string): string => s.replace(/\.?0+$/, "");

/** Compact chart-axis ticks: ₹8L / ₹32L / ₹1.2Cr. */
export function axisINR(n: number): string {
  const v = Number(n) || 0;
  if (v <= 0) return "0";
  if (v >= 1e7) return `₹${trimZeros((v / 1e7).toFixed(1))}Cr`;
  if (v >= 1e5) return `₹${trimZeros((v / 1e5).toFixed(1))}L`;
  return `₹${Math.round(v / 1e3)}k`;
}

/** "₹12 Lakh / year" for the personal-details rows; "-" when not entered. */
export function incomePerYear(n: number): string {
  const v = Number(n) || 0;
  if (v <= 0) return "-";
  if (v >= 1e7) return `₹${trimZeros((v / 1e7).toFixed(2))} Cr / year`;
  return `₹${trimZeros((v / 1e5).toFixed(1))} Lakh / year`;
}

/** "₹35,000 / month"; "-" when not entered. */
export function rupeesPerMonth(n: number): string {
  const v = Number(n) || 0;
  if (v <= 0) return "-";
  return `₹${Math.round(v).toLocaleString("en-IN")} / month`;
}

/** Fills `{key}` tokens, e.g. fillTemplate("Pay till {age}", { age: 60 }). */
export function fillTemplate(template: string, vars: Record<string, string | number>): string {
  return Object.entries(vars).reduce((acc, [k, v]) => acc.split(`{${k}}`).join(String(v)), template);
}
