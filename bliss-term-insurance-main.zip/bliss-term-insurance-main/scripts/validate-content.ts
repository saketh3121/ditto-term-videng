/**
 * Validates every content JSON file against its zod schema. Run in CI and
 * locally via `npm run validate:content`. Exits non-zero on the first bad
 * file, naming the file and the exact field — so content problems are caught
 * in the pipeline, never on a live call.
 */
import { promises as fs } from "fs";
import path from "path";
import {
  insurerSchema,
  policiesContentSchema,
  recommendationsContentSchema,
  flowsContentSchema,
  welcomeContentSchema,
  chromeContentSchema,
  adminContentSchema,
  policyDetailsContentSchema,
  definitionsContentSchema,
  abbreviationsContentSchema,
  coverAmountContentSchema,
  profileContentSchema,
  policyDetailsPageCopySchema,
  whyNowContentSchema,
  whyDittoContentSchema,
  inbuiltFeaturesContentSchema,
  inbuiltFeaturesPageContentSchema,
  resourcesContentSchema,
  specificIllnessesContentSchema,
  specificIllnessesPageContentSchema,
  ridersContentSchema,
  ridersPageCopySchema,
  premiumOptionsContentSchema,
  advisorSchema,
  nriGuidelinesContentSchema,
  pdfSummaryContentSchema,
} from "../schemas/content";
import type { ZodType } from "zod";

const ROOT = process.cwd();

type Target =
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  | { kind: "dir"; dir: string; schema: ZodType<any> }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  | { kind: "file"; file: string; schema: ZodType<any> };

const targets: Target[] = [
  { kind: "dir", dir: "content/insurers", schema: insurerSchema },
  { kind: "file", file: "content/policies.json", schema: policiesContentSchema },
  { kind: "file", file: "content/pages/recommendations.json", schema: recommendationsContentSchema },
  { kind: "file", file: "content/pages/welcome.json", schema: welcomeContentSchema },
  { kind: "file", file: "content/flows.json", schema: flowsContentSchema },
  { kind: "file", file: "content/chrome.json", schema: chromeContentSchema },
  { kind: "file", file: "content/admin.json", schema: adminContentSchema },
  { kind: "dir", dir: "content/policy-details", schema: policyDetailsContentSchema },
  { kind: "file", file: "content/definitions.json", schema: definitionsContentSchema },
  { kind: "file", file: "content/abbreviations.json", schema: abbreviationsContentSchema },
  { kind: "file", file: "content/pages/cover-amount.json", schema: coverAmountContentSchema },
  { kind: "file", file: "content/pages/profile.json", schema: profileContentSchema },
  { kind: "file", file: "content/pages/policy-details.json", schema: policyDetailsPageCopySchema },
  { kind: "file", file: "content/pages/why-now.json", schema: whyNowContentSchema },
  { kind: "file", file: "content/pages/why-ditto.json", schema: whyDittoContentSchema },
  { kind: "file", file: "content/inbuilt-features.json", schema: inbuiltFeaturesContentSchema },
  { kind: "file", file: "content/pages/inbuilt-features.json", schema: inbuiltFeaturesPageContentSchema },
  { kind: "file", file: "content/resources.json", schema: resourcesContentSchema },
  { kind: "file", file: "content/specific-illnesses.json", schema: specificIllnessesContentSchema },
  { kind: "file", file: "content/pages/specific-illnesses.json", schema: specificIllnessesPageContentSchema },
  { kind: "file", file: "content/riders.json", schema: ridersContentSchema },
  { kind: "file", file: "content/pages/riders.json", schema: ridersPageCopySchema },
  { kind: "file", file: "content/pages/premium-options.json", schema: premiumOptionsContentSchema },
  { kind: "dir", dir: "content/advisors", schema: advisorSchema },
  { kind: "file", file: "content/nri-guidelines.json", schema: nriGuidelinesContentSchema },
  { kind: "file", file: "content/pdf-summary.json", schema: pdfSummaryContentSchema },
];

async function validateFile(file: string, schema: Target["schema"]) {
  const raw = JSON.parse(await fs.readFile(path.join(ROOT, file), "utf-8"));
  const result = schema.safeParse(raw);
  if (!result.success) {
    console.error(`✗ ${file}\n${result.error.message}`);
    process.exitCode = 1;
  } else {
    console.log(`✓ ${file}`);
  }
}

async function main() {
  for (const t of targets) {
    if (t.kind === "file") {
      await validateFile(t.file, t.schema);
    } else {
      const dir = path.join(ROOT, t.dir);
      const files = (await fs.readdir(dir)).filter((f) => f.endsWith(".json"));
      for (const f of files) await validateFile(path.join(t.dir, f), t.schema);
    }
  }
  if (process.exitCode) {
    console.error("\nContent validation failed.");
  } else {
    console.log("\nAll content valid.");
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
