/**
 * Imports Ditto's Product Playbook CSV (a feature-comparison matrix: rows are
 * categorized features, columns are policies) into one
 * content/policy-details/<policyId>.json per policy, validated against
 * policyDetailsContentSchema. Re-run this whenever a refined/updated CSV is
 * provided — it fully regenerates the policy-details files from scratch.
 *
 * Usage: npx tsx scripts/import-policy-details.ts <path-to-csv>
 */
import { parse } from "csv-parse/sync";
import { promises as fs } from "fs";
import path from "path";
import { policyDetailsContentSchema } from "../schemas/content";
import policiesContent from "../content/policies.json";
import type { PoliciesContent, PolicyDetailCategoryId, PolicyDetailItem } from "../types";

const ROOT = process.cwd();
const OUT_DIR = path.join(ROOT, "content", "policy-details");

/** CSV column-0 category text -> our fixed category id. Order = canonical output order. */
const CATEGORY_MAP: Record<string, PolicyDetailCategoryId> = {
  "Entry Age": "entry-age",
  "Maturity Age": "maturity-age",
  "Educational Qualfication": "educational-qualification",
  "Annual Income": "annual-income",
  "Sum Assured": "sum-assured",
  "Pincode Restriction": "pincode-restriction",
  "Smoker Timeline": "smoker-timeline",
  "Premium Payment Term and Frequency": "premium-payment",
  Variants: "variants",
  "Inbuilt Benefits": "inbuilt-benefits",
  "Paid Add ons": "paid-add-ons",
  "Other Optional features": "other-optional-features",
  "Discounts offered": "discounts-offered",
  "NRI Guidelines": "nri-guidelines",
  "Domestic Housewife Profile": "domestic-housewife-profile",
  "NRI Housewife Profiles": "nri-housewife-profiles",
};
const CATEGORY_ORDER = Object.values(CATEGORY_MAP);

function normalizeWhitespace(s: string): string {
  return s.replace(/\s+/g, " ").trim();
}

function cleanCellText(s: string): string {
  return s
    .replace(/\r\n/g, "\n")
    .trim()
    .replace(/\n{3,}/g, "\n\n");
}

async function main() {
  const csvPath = process.argv[2];
  if (!csvPath) {
    console.error("Usage: npx tsx scripts/import-policy-details.ts <path-to-csv>");
    process.exit(1);
  }

  const raw = await fs.readFile(csvPath, "utf-8");
  const rows: string[][] = parse(raw, { relax_column_count: true });

  const header = rows[0];
  if (!header) throw new Error("CSV has no header row");

  const { policies } = policiesContent as PoliciesContent;
  const columnToPolicyId = new Map<number, string>();
  for (let col = 2; col < header.length; col++) {
    const headerName = normalizeWhitespace(header[col] ?? "");
    if (!headerName) continue;
    const policy = policies.find((p) => normalizeWhitespace(p.name) === headerName || headerName.endsWith(normalizeWhitespace(p.name)));
    if (!policy) {
      throw new Error(`Column ${col} header "${headerName}" does not match any policy in content/policies.json`);
    }
    columnToPolicyId.set(col, policy.id);
  }
  for (const policy of policies) {
    if (![...columnToPolicyId.values()].includes(policy.id)) {
      throw new Error(`Policy "${policy.id}" (${policy.name}) has no matching column in the CSV header`);
    }
  }

  // policyId -> categoryId -> items
  const byPolicy = new Map<string, Map<PolicyDetailCategoryId, PolicyDetailItem[]>>();
  for (const policy of policies) byPolicy.set(policy.id, new Map());

  let currentCategoryDisplay = "";
  for (let r = 1; r < rows.length; r++) {
    const row = rows[r];
    if (!row) continue;

    const col0 = normalizeWhitespace(row[0] ?? "");
    const col1 = normalizeWhitespace(row[1] ?? "");
    if (col0) currentCategoryDisplay = col0;
    if (!currentCategoryDisplay) continue;

    const categoryId = CATEGORY_MAP[currentCategoryDisplay];
    if (!categoryId) {
      throw new Error(`Row ${r}: unrecognized category "${currentCategoryDisplay}" — add it to CATEGORY_MAP`);
    }
    const itemLabel = col1 || currentCategoryDisplay;

    for (const [col, policyId] of columnToPolicyId) {
      const cellRaw = row[col] ?? "";
      const text = cleanCellText(cellRaw);
      if (!text) continue;

      const categories = byPolicy.get(policyId)!;
      if (!categories.has(categoryId)) categories.set(categoryId, []);
      categories.get(categoryId)!.push({ label: itemLabel, text });
    }
  }

  await fs.mkdir(OUT_DIR, { recursive: true });
  for (const policy of policies) {
    const categories = byPolicy.get(policy.id)!;
    const content = {
      policyId: policy.id,
      categories: CATEGORY_ORDER.filter((id) => categories.has(id)).map((id) => ({
        category: id,
        items: categories.get(id)!,
      })),
    };

    const result = policyDetailsContentSchema.safeParse(content);
    if (!result.success) {
      throw new Error(`Generated content for ${policy.id} failed validation: ${result.error.message}`);
    }

    const outFile = path.join(OUT_DIR, `${policy.id}.json`);
    await fs.writeFile(outFile, `${JSON.stringify(result.data, null, 2)}\n`, "utf-8");
    console.log(`✓ ${path.relative(ROOT, outFile)} (${content.categories.length} categories)`);
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
