/**
 * Imports Ditto's Product Playbook "Features Description" CSV — a plain
 * glossary (term, description) — into content/definitions.json, classifying
 * each term under the same PolicyDetailCategoryId taxonomy used by
 * content/policy-details/*.json. Re-run whenever an updated glossary CSV is
 * provided — it fully regenerates content/definitions.json from scratch.
 *
 * Usage: npx tsx scripts/import-definitions.ts <path-to-csv>
 */
import { parse } from "csv-parse/sync";
import { promises as fs } from "fs";
import path from "path";
import { definitionsContentSchema } from "../schemas/content";
import type { DefinitionEntry, PolicyDetailCategoryId } from "../types";

const ROOT = process.cwd();
const OUT_FILE = path.join(ROOT, "content", "definitions.json");

/** Glossary term -> its PolicyDetailCategoryId, matched against where the term appears in content/policy-details/*.json. */
const TERM_CATEGORY: Record<string, PolicyDetailCategoryId> = {
  "Maturity Age": "maturity-age",
  Variants: "variants",
  "Terminal Illness": "inbuilt-benefits",
  "Life Stage benefit": "inbuilt-benefits",
  "Smart Exit Benefit": "inbuilt-benefits",
  "Cover Continuance Benefit": "inbuilt-benefits",
  "Instant payout on claim intimation": "inbuilt-benefits",
  "Renewability at Maturity": "inbuilt-benefits",
  "Lifeline Plus": "inbuilt-benefits",
  "Parent Protect Care": "inbuilt-benefits",
  "Critical Illness": "paid-add-ons",
  "Waiver of Premium": "paid-add-ons",
  "Accidental death benefit": "paid-add-ons",
  "Disability benefit": "paid-add-ons",
  "Increasing cover": "other-optional-features",
  "Decreasing cover": "other-optional-features",
  "OCI/ PIO": "nri-guidelines",
};

function normalizeWhitespace(s: string): string {
  return s.replace(/\s+/g, " ").trim();
}

function cleanCellText(s: string): string {
  return s
    .replace(/\r\n/g, "\n")
    .trim()
    .replace(/\n{3,}/g, "\n\n");
}

async function main() {
  const csvPath = process.argv[2];
  if (!csvPath) {
    console.error("Usage: npx tsx scripts/import-definitions.ts <path-to-csv>");
    process.exit(1);
  }

  const raw = await fs.readFile(csvPath, "utf-8");
  const rows: string[][] = parse(raw, { relax_column_count: true });

  const definitions: DefinitionEntry[] = [];
  for (let r = 0; r < rows.length; r++) {
    const row = rows[r];
    if (!row) continue;
    const label = normalizeWhitespace(row[1] ?? "");
    const text = cleanCellText(row[2] ?? "");
    if (!label || !text || label === "Features") continue;

    const category = TERM_CATEGORY[label];
    if (!category) {
      throw new Error(`Row ${r}: unrecognized glossary term "${label}" — add it to TERM_CATEGORY`);
    }
    definitions.push({ category, label, text });
  }

  const content = { definitions };
  const result = definitionsContentSchema.safeParse(content);
  if (!result.success) {
    throw new Error(`Generated definitions failed validation: ${result.error.message}`);
  }

  await fs.writeFile(OUT_FILE, `${JSON.stringify(result.data, null, 2)}\n`, "utf-8");
  console.log(`✓ ${path.relative(ROOT, OUT_FILE)} (${definitions.length} definitions)`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
