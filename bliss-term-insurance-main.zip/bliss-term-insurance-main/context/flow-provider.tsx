"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { CustomerInfo, Residency } from "@/types";
import { DEFAULT_CUSTOMER } from "@/config/defaults";
import { POLICY_PRESETS } from "@/config/policy-presets";
import { ageFromDob } from "@/lib/calc/age";
import { clearPersistedFlowState, loadPersistedFlowState, savePersistedFlowState } from "@/lib/flow-persistence";

/**
 * Flow-level state shared across steps: the customer's advisory inputs (Control
 * Panel) and the selected policy set (Policy Panel). Both are captured in the
 * right-rail band and consumed downstream — the customer info by the cover /
 * eligibility logic, the policy selection by Recommendations and Riders. Typed
 * context, persisted to localStorage (lib/flow-persistence.ts) so a hard
 * refresh mid-call doesn't lose the advisor's inputs — `startOver()` is the
 * explicit, advisor-initiated way to clear it back to defaults.
 *
 * Policy selection is tracked independently per residency (own manual picks,
 * own secondary-recommendation toggle), seeded from config/policy-presets.ts,
 * so switching Resident <-> NRI swaps to that residency's own remembered
 * customization rather than sharing one flat list.
 */
/** Which right-rail panel is open, shared so any component can trigger one (e.g. an "Edit" link). */
export type ActivePanel = "control" | "policy" | "summary" | null;

interface FlowState {
  customer: CustomerInfo;
  /** Merge a partial update into the customer form. */
  setCustomer: (patch: Partial<CustomerInfo>) => void;
  /** Whole years derived from `customer.dob` (null until a valid DOB is set). */
  age: number | null;
  /** Insurer segment derived from citizenship — drives Recommendations. */
  residency: Residency;
  /**
   * Effective policy ids for the current residency — the advisor's manual
   * picks, plus the residency's secondary-recommendation policy when
   * enabled. This is what Recommendations and the Inbuilt Features table
   * read.
   */
  selectedPolicies: string[];
  /** The current residency's manual picks only (excludes the secondary pick) — what the Policy Panel edits directly. */
  manualSelectedPolicies: string[];
  setManualSelectedPolicies: (ids: string[]) => void;
  /** Whether the current residency's secondary-recommendation policy is included. */
  secondaryRecommendationEnabled: boolean;
  setSecondaryRecommendationEnabled: (enabled: boolean) => void;
  /** The current residency's designated secondary-recommendation policy id, or null if none configured. */
  secondaryRecommendationPolicyId: string | null;
  activePanel: ActivePanel;
  setActivePanel: (panel: ActivePanel) => void;
  /** The price-revision caution strip was closed for this customer's call; Start Over brings it back. */
  priceBannerDismissed: boolean;
  dismissPriceBanner: () => void;
  /** Clears persisted inputs and resets the whole flow (customer + both residencies' policy picks) back to defaults. */
  startOver: () => void;
  /** False until persisted inputs have been loaded — before that, `customer` is just the defaults, not the real session. */
  hydrated: boolean;
}

const FlowContext = createContext<FlowState | null>(null);

function defaultPoliciesByResidency(): Record<Residency, string[]> {
  return {
    resident: [...POLICY_PRESETS.resident.defaultPolicyIds],
    nri: [...POLICY_PRESETS.nri.defaultPolicyIds],
  };
}

export function FlowProvider({ children }: { children: React.ReactNode }) {
  const [customer, setCustomerState] = useState<CustomerInfo>(DEFAULT_CUSTOMER);
  const [policiesByResidency, setPoliciesByResidency] = useState<Record<Residency, string[]>>(
    defaultPoliciesByResidency,
  );
  const [secondaryEnabledByResidency, setSecondaryEnabledByResidency] = useState<Record<Residency, boolean>>({
    resident: false,
    nri: false,
  });
  const [activePanel, setActivePanel] = useState<ActivePanel>(null);
  const [priceBannerDismissed, setPriceBannerDismissed] = useState(false);
  const dismissPriceBanner = useCallback(() => setPriceBannerDismissed(true), []);
  const [hydrated, setHydrated] = useState(false);

  // Load persisted inputs once on mount (client-only — SSR has no
  // localStorage, so the first render always matches the defaults above,
  // then this swaps in the real values right after).
  useEffect(() => {
    const persisted = loadPersistedFlowState();
    if (persisted) {
      setCustomerState(persisted.customer);
      setPoliciesByResidency(persisted.policiesByResidency);
      setSecondaryEnabledByResidency(persisted.secondaryEnabledByResidency);
    }
    setHydrated(true);
  }, []);

  // Persist on every change, but only once hydration above has run — otherwise
  // this fires first (with the pre-hydration defaults) and clobbers whatever
  // was actually saved before the load effect gets a chance to apply it.
  useEffect(() => {
    if (!hydrated) return;
    savePersistedFlowState({ customer, policiesByResidency, secondaryEnabledByResidency });
  }, [hydrated, customer, policiesByResidency, secondaryEnabledByResidency]);

  const setCustomer = useCallback((patch: Partial<CustomerInfo>) => {
    setCustomerState((prev) => ({ ...prev, ...patch }));
  }, []);

  const startOver = useCallback(() => {
    clearPersistedFlowState();
    setCustomerState(DEFAULT_CUSTOMER);
    setPoliciesByResidency(defaultPoliciesByResidency());
    setSecondaryEnabledByResidency({ resident: false, nri: false });
    setActivePanel(null);
    setPriceBannerDismissed(false);
  }, []);

  const age = useMemo(() => ageFromDob(customer.dob), [customer.dob]);
  const residency: Residency = customer.citizenship === "nri" ? "nri" : "resident";

  const manualSelectedPolicies = policiesByResidency[residency];
  const secondaryRecommendationEnabled = secondaryEnabledByResidency[residency];
  const secondaryRecommendationPolicyId = POLICY_PRESETS[residency].secondaryPolicyId;

  const setManualSelectedPolicies = useCallback(
    (ids: string[]) => {
      setPoliciesByResidency((prev) => ({ ...prev, [residency]: ids }));
    },
    [residency],
  );

  const setSecondaryRecommendationEnabled = useCallback(
    (enabled: boolean) => {
      setSecondaryEnabledByResidency((prev) => ({ ...prev, [residency]: enabled }));
    },
    [residency],
  );

  const selectedPolicies = useMemo(() => {
    if (
      secondaryRecommendationEnabled &&
      secondaryRecommendationPolicyId &&
      !manualSelectedPolicies.includes(secondaryRecommendationPolicyId)
    ) {
      return [...manualSelectedPolicies, secondaryRecommendationPolicyId];
    }
    return manualSelectedPolicies;
  }, [manualSelectedPolicies, secondaryRecommendationEnabled, secondaryRecommendationPolicyId]);

  const value = useMemo(
    () => ({
      customer,
      setCustomer,
      age,
      residency,
      selectedPolicies,
      manualSelectedPolicies,
      setManualSelectedPolicies,
      secondaryRecommendationEnabled,
      setSecondaryRecommendationEnabled,
      secondaryRecommendationPolicyId,
      activePanel,
      setActivePanel,
      priceBannerDismissed,
      dismissPriceBanner,
      startOver,
      hydrated,
    }),
    [
      customer,
      setCustomer,
      age,
      residency,
      selectedPolicies,
      manualSelectedPolicies,
      setManualSelectedPolicies,
      secondaryRecommendationEnabled,
      setSecondaryRecommendationEnabled,
      secondaryRecommendationPolicyId,
      activePanel,
      priceBannerDismissed,
      dismissPriceBanner,
      startOver,
      hydrated,
    ],
  );

  return <FlowContext.Provider value={value}>{children}</FlowContext.Provider>;
}

export function useFlow(): FlowState {
  const ctx = useContext(FlowContext);
  if (!ctx) throw new Error("useFlow must be used within FlowProvider");
  return ctx;
}
