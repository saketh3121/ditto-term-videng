/**
 * Milestone/expense-projection constants — all in ONE place, clearly labelled
 * as tunable, same convention as config/assumptions.ts. Ported from the
 * milestone-calculator kit's inline constants; never hardcode these inside a
 * component or lib/calc file.
 */

export type Tier = "tier1" | "tier2";
export type MilestoneKey = "marriage" | "firstChild" | "secondChild";
export type IncomeBracket = 0 | 1 | 2 | 3 | 4;
export type MilestoneAges = Record<MilestoneKey, number>;
export type IncludedMilestones = Record<MilestoneKey, boolean>;
export type MultiplierRow = readonly [number, number, number, number, number];

export interface MilestoneDef {
  key: MilestoneKey;
  label: string;
  age: number;
}

/** Milestones shown on the projection, in display order. */
export const MILESTONES: readonly MilestoneDef[] = Object.freeze([
  { key: "marriage", label: "Marriage", age: 29 },
  { key: "firstChild", label: "First child", age: 33 },
  { key: "secondChild", label: "Second child", age: 37 },
]);

export const DEFAULT_MILESTONE_AGES: MilestoneAges = Object.freeze({
  marriage: 29,
  firstChild: 33,
  secondChild: 37,
});

export const MILESTONE_AGE_MIN = 18;
export const MILESTONE_AGE_MAX = 60;

/** Income brackets — index by gross annual income (₹). */
export const INCOME_BRACKET_LABELS = Object.freeze([
  "<₹5L",
  "₹5-15L",
  "₹15-30L",
  "₹30-50L",
  "₹50L+",
] as const);

/** Milestone step-up multipliers, table[tier][milestone][bracket]. */
export const MILESTONE_MULTIPLIERS: Record<Tier, Record<MilestoneKey, MultiplierRow>> = Object.freeze({
  tier1: {
    marriage: [1.1, 1.2, 1.25, 1.28, 1.3],
    firstChild: [1.18, 1.3, 1.4, 1.45, 1.47],
    secondChild: [1.12, 1.22, 1.3, 1.33, 1.35],
  },
  tier2: {
    marriage: [1.08, 1.16, 1.2, 1.23, 1.25],
    firstChild: [1.14, 1.25, 1.32, 1.37, 1.4],
    secondChild: [1.1, 1.18, 1.24, 1.27, 1.3],
  },
});

/** No bar/anchor is generated past this age. */
export const PROJECTION_END_AGE = 60;

export const DEFAULT_INFLATION_RATE = 0.05;
export const INFLATION_RATE_MIN = 0.03;
export const INFLATION_RATE_MAX = 0.1;
export const INFLATION_RATE_STEP = 0.005;

/** ₹/mo default if the user opts into personal goals but doesn't set an amount. */
export const PERSONAL_GOALS_BASE_MONTHLY = 25_000;

/** Assumed years-after-youngest-kid until financial independence (drives the ideal-tenure range). */
export const KID_INDEPENDENCE_MIN = 25;
export const KID_INDEPENDENCE_MAX = 30;

/** Fixed at the source app's only call site — deliberately NOT tied to the adjustable inflation rate. */
export const COVER_DISCOUNT_RATE = 0.05;

/** Ideal cover is rounded up to the nearest this-many rupees for a clean, sellable figure. */
export const COVER_ROUNDING = 500_000;

/** Basic Calculator's own rounding rule for the final recommended cover
 *  figure — nearest ₹10L, never below BASIC_COVER_FLOOR. Deliberately
 *  separate from COVER_ROUNDING, which still governs loans/existing cover
 *  and Advanced mode's own cover amount (unchanged, ceil-to-nearest-5L). */
export const BASIC_COVER_ROUNDING = 1_000_000;
export const BASIC_COVER_FLOOR = 5_000_000;

/** At or above this "cover until" age, the Control Panel input and the Profile Summary banner both flag a caution — not a hard block, just a heads-up that it's an unusually long tenure. */
export const TENURE_WARNING_AGE = 70;
