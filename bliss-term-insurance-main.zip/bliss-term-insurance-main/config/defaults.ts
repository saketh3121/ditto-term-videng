import type { CustomerInfo } from "@/types";

/**
 * Session-only defaults. Reload resets to these (deliberate — the tool never
 * persists customer data). Tunable placeholders, all in one place.
 */

/** Blank Control-Panel form. */
export const DEFAULT_CUSTOMER: CustomerInfo = {
  name: "",
  gender: "male",
  dob: "",
  annualIncome: "",
  monthlyExpenses: "",
  employment: "salaried",
  pincode: "",
  citizenship: "indian",
  hasPEDs: false,
  pedDetails: "",
  tobaccoUser: false,
  education: "graduate",
  preferredCoverAge: "",
  existingCoverAmount: "",
  uninsuredLoans: "",
  chatId: "",
};
