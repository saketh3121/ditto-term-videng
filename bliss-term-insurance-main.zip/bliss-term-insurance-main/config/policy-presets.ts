import type { Residency } from "@/types";

/**
 * Editorially-curated default policy picks per residency, plus one
 * designated "secondary recommendation" the advisor can add with a single
 * checkbox (see components/steps/recommendations.tsx). Tunable, clearly
 * labelled — same convention as config/assumptions.ts.
 */

export interface ResidencyPolicyPreset {
  /** Shown by default until the advisor customizes the selection in the Policy Panel. */
  defaultPolicyIds: string[];
  /** The one extra policy the "secondary recommendation" checkbox can add. */
  secondaryPolicyId: string | null;
}

export const POLICY_PRESETS: Record<Residency, ResidencyPolicyPreset> = {
  resident: {
    defaultPolicyIds: ["axis-max-smart-term-plan-plus", "hdfc-c2p-supreme-plus", "icici-iprotect-smart-plus"],
    secondaryPolicyId: "bajaj-etouch-ii",
  },
  nri: {
    defaultPolicyIds: ["bajaj-etouch-ii", "axis-max-smart-term-plan-plus", "hdfc-c2p-supreme-plus"],
    secondaryPolicyId: "icici-iprotect-smart-plus",
  },
};
