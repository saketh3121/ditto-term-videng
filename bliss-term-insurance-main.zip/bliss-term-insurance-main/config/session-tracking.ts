/**
 * Session-logging rules — tunable, all in one place (same convention as
 * config/assumptions.ts). Read by lib/session/* on both client and server,
 * so the browser and the log record can never disagree on a threshold.
 */

/** A section counts as viewed only after this much on-screen time with the tab visible — filters out click-throughs. */
export const SESSION_MIN_DWELL_MS = 5_000;

/** "Navigated through the presentation" = at least this many distinct presentation steps viewed after the required details were entered. */
export const SESSION_MIN_SLIDES_AFTER_DETAILS = 2;

/** Minimum share of tracked sections (presentation steps + Resources pages) viewed for a session to qualify. */
export const SESSION_QUALIFYING_COVERAGE_PCT = 34;

/** Background writes are throttled to at most one per this interval per session (plus one on tab hide / session end). */
export const SESSION_FLUSH_INTERVAL_MS = 20_000;

/**
 * Free-text PED notes are health information typed by the advisor — kept
 * out of the log by default. The structured hasPEDs yes/no is always logged.
 */
export const SESSION_LOG_PED_DETAILS = false;
