import { SUPER_ADMIN_EMAIL } from "@/config/auth";

/**
 * The admin CMS's structural constants — repo target, branch name, PR title,
 * field order. One source of truth, read by lib/cms/* and the admin routes;
 * never duplicated.
 */

export const CMS_REPO_OWNER = "sakdittoeth";
export const CMS_REPO_NAME = "bliss-term-insurance";
export const CMS_BASE_BRANCH = "main";
export const CMS_BRANCH_NAME = "cms/pending-content-edits";
export const CMS_MERGE_METHOD = "squash" as const;

export const CMS_PR_TITLE = "CMS: pending content edits";

/** Commit author for automated writes with no signed-in editor behind them
 *  (super-admin auto-seed, the access-request queue, the approve-access
 *  endpoint). Must be a real, Vercel-team-connected GitHub identity — a
 *  fictional email here (e.g. a made-up "bot@" address) authors a commit
 *  Vercel's GitHub integration then refuses to auto-deploy, since it can't
 *  match the author to a team member. Reuses SUPER_ADMIN_EMAIL since that
 *  account is already the one deploys are trusted from. */
export const CMS_BOT_AUTHOR = { name: "Bliss Term Advisory", email: SUPER_ADMIN_EMAIL };

/** Mirrors schemas/content.ts insurerSchema field order. */
export const CMS_INSURER_FIELDS = [
  "id",
  "name",
  "logo",
  "csr",
  "complaintsPer10k",
  "asr",
  "annualBusinessCrore",
  "annualBusinessLabel",
  "segments",
] as const;

/** Mirrors schemas/content.ts policySchema field order. */
export const CMS_POLICY_FIELDS = ["id", "name", "insurerId", "insurerName"] as const;
