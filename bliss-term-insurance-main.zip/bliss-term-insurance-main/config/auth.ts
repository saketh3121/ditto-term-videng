/**
 * Non-secret auth constants — env-overridable, defaulted here rather than
 * inlined in lib/auth.ts so they're one place to change.
 */

export const ALLOWED_EMAIL_DOMAIN = process.env.ALLOWED_EMAIL_DOMAIN ?? "joinditto.in";

/** Always allowed in, and auto-seeded with role "admin" on first sign-in
 *  if content/advisors/ doesn't already have an entry for it. */
export const SUPER_ADMIN_EMAIL = (process.env.SUPER_ADMIN_EMAIL ?? "pappu.naga@joinditto.in").toLowerCase();
