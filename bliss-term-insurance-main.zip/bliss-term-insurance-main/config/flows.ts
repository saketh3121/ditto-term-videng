import flowsContent from "@/content/flows.json";
import type { FlowsContent } from "@/types";

/**
 * The flow's structure lives here and ONLY here. The sidebar, the routing,
 * and the Back/Continue buttons all read from this list. Reordering or adding
 * a step is a one-place, type-checked edit — not a hand-sync across
 * steps.js + App.jsx + interstitials.js like the old term app.
 */

const content = flowsContent as FlowsContent;

export type StepId =
  | "eligibility"
  | "cover-amount"
  | "riders"
  | "recommendations"
  | "premium-options"
  | "why-now"
  | "why-ditto";

export interface SubStep {
  /** DOM id of the section this sub-step scrolls to. */
  id: string;
  title: string;
}

export interface Step {
  id: StepId;
  n: number;
  label: string;
  /** Scroll-anchored sub-sections; the sidebar expands these for the active step. */
  subSteps: SubStep[];
}

const ORDER: StepId[] = [
  "eligibility",
  "cover-amount",
  "recommendations",
  "riders",
  "premium-options",
  "why-now",
  "why-ditto",
];

export const STEPS: Step[] = ORDER.map((id, i) => {
  const meta = content.steps[id];
  if (!meta) {
    throw new Error(`Missing flow label for step "${id}" in content/flows.json`);
  }
  return { id, n: i + 1, label: meta.label, subSteps: content.subSteps?.[id] ?? [] };
});

export const FLOW_META = content.flow;

export function stepById(id: string): Step | undefined {
  return STEPS.find((s) => s.id === id);
}

/** The id of the first step — the walkthrough's entry point. */
export function firstStepId(): StepId {
  const first = STEPS[0];
  if (!first) throw new Error("config/flows.ts: no steps defined");
  return first.id;
}

export function adjacentSteps(id: StepId): { prev?: Step; next?: Step } {
  const i = STEPS.findIndex((s) => s.id === id);
  return { prev: STEPS[i - 1], next: STEPS[i + 1] };
}
