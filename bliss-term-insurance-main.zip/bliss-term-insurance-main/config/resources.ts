import resourcesContent from "@/content/resources.json";
import type { ResourcesContent } from "@/types";

/**
 * Resources nav section — pinned to the bottom of the left sidebar, outside
 * the numbered step flow (no Back/Continue, no "next step" chevron). Same
 * id-list + content-map split as config/flows.ts, kept separate from it
 * since Resources isn't part of the advisor's step-by-step walkthrough.
 *
 * `href` is explicit per entry rather than derived from `id` because
 * Specific Illnesses owns its own nested route tree (an index page plus a
 * per-policy detail page) instead of the generic /flow/resources/[resourceId]
 * template that Inbuilt Features uses.
 */

const content = resourcesContent as ResourcesContent;

export type ResourceId = "inbuilt-features" | "specific-illnesses";

export interface Resource {
  id: ResourceId;
  label: string;
  href: string;
}

const ORDER: { id: ResourceId; href: string }[] = [
  { id: "inbuilt-features", href: "/flow/resources/inbuilt-features" },
  { id: "specific-illnesses", href: "/flow/resources/specific-illnesses" },
];

export const RESOURCES: Resource[] = ORDER.map(({ id, href }) => {
  const meta = content.items[id];
  if (!meta) {
    throw new Error(`Missing resource label for "${id}" in content/resources.json`);
  }
  return { id, href, label: meta.label };
});

export const RESOURCES_SECTION_LABEL = content.sectionLabel;

export function resourceById(id: string): Resource | undefined {
  return RESOURCES.find((r) => r.id === id);
}
