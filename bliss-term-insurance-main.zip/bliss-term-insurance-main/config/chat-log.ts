/**
 * Target for the per-session chat log — deliberately a repo SEPARATE from
 * CMS_REPO_OWNER/CMS_REPO_NAME (config/cms.ts). Writing these records into
 * this app's own repo would commit to a branch Vercel watches and trigger a
 * deploy or preview build per write. Env-driven; lib/cms/chat-log.ts throws
 * a clear error if unset rather than silently no-op-ing.
 *
 * Layout in that repo: sessions/<IST date>/<chatId>_<sessionId>.json, one
 * small file per session (lib/session/record.ts). The older logs/<YYYY-MM>.json
 * files hold the pre-session, one-line-per-Save history and are no longer
 * written to.
 */
export const CHATLOG_REPO_OWNER = process.env.CHATLOG_GITHUB_OWNER ?? "";
export const CHATLOG_REPO_NAME = process.env.CHATLOG_GITHUB_REPO ?? "";
export const CHATLOG_BASE_BRANCH = process.env.CHATLOG_GITHUB_BRANCH ?? "main";
