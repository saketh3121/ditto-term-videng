/**
 * Cover-calculator constants — all in ONE place, clearly labelled as tunable
 * placeholders (per the original spec). Never hardcode these inside a page.
 */
export const ASSUMPTIONS = {
  /** Age at which income/expenses are assumed to stop. */
  retirementAge: 60,
  /** Floor for a computed policy term, in years. */
  minPolicyTerm: 5,
} as const;
