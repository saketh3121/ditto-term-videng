import { z } from "zod";

/**
 * Zod schemas — the runtime guard that backs the compile-time types.
 *
 * `lib/content.ts` parses every JSON file through these. If a content editor
 * renames a key, drops a required field, or fat-fingers a number as a string,
 * `npm run validate:content` (and the CI step, and the loader itself) throws a
 * precise error naming the file and field. This is the mechanism that makes a
 * content change safe: bad data cannot render as a blank card on a call.
 */

export const residencySchema = z.enum(["resident", "nri"]);

export const insurerSchema = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  logo: z.string().min(1),
  csr: z.number().min(0).max(100),
  complaintsPer10k: z.number().min(0),
  asr: z.number().min(0).max(100),
  annualBusinessCrore: z.number().min(0),
  annualBusinessLabel: z.string().min(1),
  segments: z.array(residencySchema).min(1),
});

export const policySchema = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  insurerId: z.string().min(1),
  insurerName: z.string().min(1),
});

export const policiesContentSchema = z.object({
  policies: z.array(policySchema).min(1),
});

export const metricKeySchema = z.enum(["csr", "complaintsPer10k", "asr", "annualBusinessCrore"]);

export const keyMetricSchema = z.object({
  field: metricKeySchema,
  title: z.string(),
  description: z.string(),
  industryLabel: z.string(),
  industryValue: z.string(),
  dittoValue: z.string(),
  columnHeader: z.string(),
  columnSuffix: z.string(),
});

export const recommendationsContentSchema = z.object({
  eyebrow: z.string(),
  title: z.string(),
  titleAccent: z.string(),
  subtitle: z.string(),
  keyMetricsHeading: z.string(),
  keyMetricsLead: z.string(),
  keyMetrics: z.array(keyMetricSchema).min(1),
  compareHeading: z.string(),
  residentHeading: z.string(),
  nriHeading: z.string(),
  insurerColumnLabel: z.string(),
  viewPolicyDetailsLabel: z.string(),
  footnote: z.string(),
  emptyNote: z.string(),
  secondaryRecommendationToggleLabel: z.string(),
});

export const nriMedicalDetailEntrySchema = z.object({
  insurerId: z.string().min(1),
  details: z.string().min(1),
});

export const nriGuidelinesContentSchema = z.object({
  heading: z.string(),
  gccLabel: z.string(),
  nonGccLabel: z.string(),
  tableHeading: z.string(),
  insurerColumnLabel: z.string(),
  detailsColumnLabel: z.string(),
  gcc: z.array(nriMedicalDetailEntrySchema).min(1),
  nonGcc: z.array(nriMedicalDetailEntrySchema).min(1),
  indiaBannerHeading: z.string(),
  indiaBannerText: z.string(),
});

export const inbuiltFeatureEntrySchema = z.object({
  available: z.boolean(),
  mainContent: z.string().nullable(),
  detailText: z.string().nullable(),
});

export const inbuiltFeatureSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  detailSummary: z.string(),
  byPolicy: z.record(z.string(), inbuiltFeatureEntrySchema),
});

export const inbuiltFeatureCategorySchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  features: z.array(inbuiltFeatureSchema).min(1),
});

export const inbuiltFeaturesContentSchema = z.object({
  categories: z.array(inbuiltFeatureCategorySchema).min(1),
});

export const inbuiltFeaturesPageContentSchema = z.object({
  eyebrow: z.string(),
  title: z.string(),
  titleAccent: z.string(),
  subtitle: z.string(),
  parametersLabel: z.string(),
  naLabel: z.string(),
  emptyNote: z.string(),
});

export const resourcesContentSchema = z.object({
  sectionLabel: z.string(),
  items: z.record(z.string(), z.object({ label: z.string() })),
});

export const illnessListSchema = z.object({
  heading: z.string().min(1),
  items: z.array(z.string().min(1)),
});

export const specificIllnessesContentSchema = z.object({
  lists: z.record(z.string(), illnessListSchema),
  policies: z.record(z.string(), z.object({ wop: z.array(z.string()), ci: z.array(z.string()) })),
});

export const specificIllnessesPageContentSchema = z.object({
  eyebrow: z.string(),
  title: z.string(),
  titleAccent: z.string(),
  subtitle: z.string(),
  indexIntro: z.string(),
  wopSectionHeading: z.string(),
  ciSectionHeading: z.string(),
  noDataNote: z.string(),
  backToIndexLabel: z.string(),
});

export const staticComparisonColumnSchema = z.object({
  insurerId: z.string().min(1),
  policyId: z.string().min(1),
});

export const staticCellKindSchema = z.enum(["check", "cross", "text"]);

export const staticComparisonCellSchema = z.object({
  kind: staticCellKindSchema,
  text: z.string(),
  footnoteMarker: z.string().nullable(),
});

export const staticComparisonRowSchema = z.object({
  label: z.string().min(1),
  cells: z.record(z.string(), staticComparisonCellSchema),
  linksToIllnessList: z.boolean().optional(),
});

export const staticComparisonFootnoteSchema = z.object({
  marker: z.string().min(1),
  text: z.string(),
});

export const staticComparisonTableSchema = z.object({
  columns: z.array(staticComparisonColumnSchema).min(1),
  rows: z.array(staticComparisonRowSchema).min(1),
  footnotes: z.array(staticComparisonFootnoteSchema),
  disclaimer: z.string(),
});

export const ridersContentSchema = z.object({
  wop: staticComparisonTableSchema,
  ci: staticComparisonTableSchema,
  others: inbuiltFeaturesContentSchema,
});

export const ridersPageCopySchema = z.object({
  eyebrow: z.string(),
  title: z.string(),
  titleAccent: z.string(),
  subtitle: z.string(),
  wopTabLabel: z.string(),
  ciTabLabel: z.string(),
  othersTabLabel: z.string(),
  wopHeading: z.string(),
  ciHeading: z.string(),
  othersHeading: z.string(),
  parametersLabel: z.string(),
  naLabel: z.string(),
  emptyNote: z.string(),
  wopDefinition: z.string().min(1),
  ciDefinition: z.string().min(1),
  fullListLabel: z.string().min(1),
});

export const payTermComparisonRowSchema = z.object({
  icon: z.string().min(1),
  feature: z.string().min(1),
  regularPay: z.string().min(1),
  limitedPay: z.string().min(1),
});

export const premiumOptionsContentSchema = z.object({
  eyebrow: z.string(),
  title: z.string(),
  titleAccent: z.string(),
  subtitle: z.string(),
  howOftenHeading: z.string(),
  howOftenIntro: z.string(),
  howOftenDisclaimers: z.array(z.string().min(1)).min(1),
  howLongHeading: z.string(),
  howLongIntro: z.string(),
  payTermComparisonHeading: z.string(),
  payTermComparisonRegularLabel: z.string(),
  payTermComparisonLimitedLabel: z.string(),
  payTermComparisonRows: z.array(payTermComparisonRowSchema).min(1),
});

export const profileSummaryBannerContentSchema = z.object({
  editLabel: z.string(),
  namePlaceholder: z.string(),
  /** Appended straight after the customer's name, e.g. name + "'s Profile". */
  profileHeadingSuffix: z.string(),
  ageLabel: z.string(),
  ageUnit: z.string(),
  monthlyExpensesLabel: z.string(),
  tobaccoLabel: z.string(),
  tobaccoYes: z.string(),
  tobaccoNo: z.string(),
  existingCoverLabel: z.string(),
  annualIncomeLabel: z.string(),
  residencyLabel: z.string(),
  residentValue: z.string(),
  nriValue: z.string(),
  chosenTenureLabel: z.string(),
  chosenTenureUpToTemplate: z.string(),
  /** Shown next to the chosen-tenure stat when the "cover until" age reaches or exceeds TENURE_WARNING_AGE. */
  chosenTenureWarning: z.string(),
  uninsuredLoansLabel: z.string(),
  notAvailable: z.string(),
});

export const eligibilityComparisonCopySchema = z.object({
  over: z.string(),
  within: z.string(),
  disclaimer: z.string(),
});

export const coverAmountContentSchema = z.object({
  eyebrow: z.string(),
  title: z.string(),
  titleAccent: z.string(),
  subtitle: z.string(),
  advancedIntro: z.string(),
  policyTermLabel: z.string(),
  suggestedCoverLabel: z.string(),
  adjustedLabel: z.string(),
  baseCoverLabel: z.string(),
  loansLabel: z.string(),
  existingCoverLabel: z.string(),
  purchaseNowLabel: z.string(),
  policyTermUnit: z.string(),
  idealTenureLabel: z.string(),
  idealTenureUnit: z.string(),
  banner: profileSummaryBannerContentSchema,
  eligibilityTableHeading: z.string(),
  eligibilityTableCaption: z.string(),
  eligibilityBelowSuggestedLabel: z.string(),
  eligibilityComparison: eligibilityComparisonCopySchema,
  /** Sub-heading shown above the Max Eligibility / Suggested Cover tiles. */
  howMuchCoverHeading: z.string(),
  /** Sub-heading shown above the expense/cover projection chart (Basic and Advanced). */
  projectionChartHeading: z.string(),
  /** Shown in place of the Suggested Cover figures when monthly expense hasn't been entered yet in the Control Panel. */
  emptyStateMessage: z.string(),
});

export const profileAssuranceSchema = z.object({
  icon: z.string().min(1),
  title: z.string(),
  body: z.string(),
});


export const profileFactorSchema = z.object({
  id: z.string().min(1),
  icon: z.string().min(1),
  title: z.string(),
  body: z.string(),
});

export const profileContentSchema = z.object({
  eyebrow: z.string(),
  title: z.string(),
  titleAccent: z.string(),
  subtitle: z.string(),
  assurances: z.array(profileAssuranceSchema).min(1),
  factors: z.array(profileFactorSchema).min(1),
});

export const whyNowCardSchema = z.object({
  icon: z.string().min(1),
  title: z.string(),
  body: z.string(),
});

export const whyNowContentSchema = z.object({
  eyebrow: z.string(),
  heading: z.string(),
  headingAccent: z.string(),
  cards: z.array(whyNowCardSchema).min(1),
});

export const whyDittoCardSchema = z.object({
  title: z.string(),
  body: z.string(),
});

export const linkedInReviewSchema = z.object({
  customerName: z.string().min(1),
  mediumLink: z.string().min(1),
  review: z.string().min(1),
});

export const whyDittoContentSchema = z.object({
  eyebrow: z.string(),
  title: z.string(),
  titleAccent: z.string(),
  cards: z.array(whyDittoCardSchema).min(1),
  reviewsSectionLabel: z.string(),
  reviews: z.array(linkedInReviewSchema),
});

export const subStepContentSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
});

export const flowsContentSchema = z.object({
  flow: z.object({ title: z.string(), description: z.string() }),
  steps: z.record(z.string(), z.object({ label: z.string() })),
  subSteps: z.record(z.string(), z.array(subStepContentSchema)).optional(),
});

export const welcomeContentSchema = z.object({
  badge: z.string(),
  heading: z.string(),
  headingAccent: z.string(),
  advisorEyebrow: z.string(),
  advisorName: z.string(),
  advisorTitle: z.string(),
  advisorIntro: z.string(),
  ctaLabel: z.string(),
  ctaMicrocopy: z.string(),
  valueProps: z
    .array(
      z.object({
        icon: z.string().min(1),
        title: z.string(),
        description: z.string(),
      }),
    )
    .min(1),
});

export const controlPanelContentSchema = z.object({
  iconTitle: z.string(),
  title: z.string(),
  subtitle: z.string(),
  nameLabel: z.string(),
  namePlaceholder: z.string(),
  genderLabel: z.string(),
  genderMale: z.string(),
  genderFemale: z.string(),
  dobLabel: z.string(),
  ageLabel: z.string(),
  ageUnit: z.string(),
  annualIncomeLabel: z.string(),
  monthlyExpensesLabel: z.string(),
  amountPlaceholder: z.string(),
  employmentLabel: z.string(),
  employmentSalaried: z.string(),
  employmentSelfEmployed: z.string(),
  pincodeLabel: z.string(),
  pincodePlaceholder: z.string(),
  citizenshipLabel: z.string(),
  citizenshipIndian: z.string(),
  citizenshipNri: z.string(),
  pedsLabel: z.string(),
  pedsYes: z.string(),
  pedsNo: z.string(),
  pedDetailsLabel: z.string(),
  pedDetailsPlaceholder: z.string(),
  tobaccoLabel: z.string(),
  tobaccoYes: z.string(),
  tobaccoNo: z.string(),
  educationLabel: z.string(),
  educationPostGraduate: z.string(),
  educationGraduate: z.string(),
  educationDiploma: z.string(),
  educationHsc: z.string(),
  educationSsc: z.string(),
  educationBelow10th: z.string(),
  preferredCoverAgeLabel: z.string(),
  preferredCoverAgePlaceholder: z.string(),
  preferredCoverAgeWarning: z.string(),
  existingCoverAmountLabel: z.string(),
  uninsuredLoansLabel: z.string(),
  chatIdLabel: z.string(),
  chatIdPlaceholder: z.string(),
  chatIdError: z.string(),
  saveLabel: z.string(),
});

export const policyPanelContentSchema = z.object({
  iconTitle: z.string(),
  title: z.string(),
  subtitle: z.string(),
  searchPlaceholder: z.string(),
  selectedTemplate: z.string(),
  clearLabel: z.string(),
  applyLabel: z.string(),
  emptyLabel: z.string(),
});

export const chromeContentSchema = z.object({
  brand: z.string(),
  homeLink: z.string(),
  nextStepLabel: z.string(),
  menuLabel: z.string(),
  themeToggleTitle: z.string(),
  sidebarCollapseTitle: z.string(),
  sidebarExpandTitle: z.string(),
  segmentControlTitle: z.string(),
  closeLabel: z.string(),
  startOverLabel: z.string(),
  startOverConfirm: z.string(),
  priceRevisionBanner: z
    .object({
      policyId: z.string().min(1),
      message: z.string().min(1),
      expiresAt: z.string().min(1),
    })
    .optional(),
  controlPanel: controlPanelContentSchema,
  policyPanel: policyPanelContentSchema,
});

export const policyDetailCategoryIdSchema = z.enum([
  "entry-age",
  "maturity-age",
  "educational-qualification",
  "annual-income",
  "sum-assured",
  "pincode-restriction",
  "smoker-timeline",
  "premium-payment",
  "variants",
  "inbuilt-benefits",
  "paid-add-ons",
  "other-optional-features",
  "discounts-offered",
  "nri-guidelines",
  "domestic-housewife-profile",
  "nri-housewife-profiles",
]);

export const policyDetailsPageCopySchema = z.object({
  backLabel: z.string(),
  categoryLabels: z.record(policyDetailCategoryIdSchema, z.string()),
});

export const policyDetailSubItemSchema = z.object({
  label: z.string().min(1),
  text: z.string().min(1),
});

export const policyDetailItemSchema = z.object({
  label: z.string().min(1),
  text: z.string().min(1),
  subItems: z.array(policyDetailSubItemSchema).optional(),
});

export const policyDetailCategorySchema = z.object({
  category: policyDetailCategoryIdSchema,
  items: z.array(policyDetailItemSchema).min(1),
});

export const policyDetailsContentSchema = z.object({
  policyId: z.string().min(1),
  categories: z.array(policyDetailCategorySchema).min(1),
});

export const definitionEntrySchema = z.object({
  category: policyDetailCategoryIdSchema,
  label: z.string().min(1),
  text: z.string().min(1),
});

export const definitionsContentSchema = z.object({
  definitions: z.array(definitionEntrySchema).min(1),
});

export const abbreviationEntrySchema = z.object({
  abbr: z.string().min(1),
  expansion: z.string().min(1),
});

export const abbreviationsContentSchema = z.object({
  abbreviations: z.array(abbreviationEntrySchema).min(1),
});

export const adminNavContentSchema = z.object({
  brand: z.string(),
  dashboardLabel: z.string(),
  insurersLabel: z.string(),
  policiesLabel: z.string(),
  reviewLabel: z.string(),
  signedInAsTemplate: z.string(),
  signOutLabel: z.string(),
});

export const adminDashboardContentSchema = z.object({
  heading: z.string(),
  subtitle: z.string(),
  insurersCardTitle: z.string(),
  policiesCardTitle: z.string(),
  manageLabel: z.string(),
  pendingBannerTemplate: z.string(),
  pendingBannerEmptyLabel: z.string(),
  pendingBannerCta: z.string(),
});

export const adminInsurerFormContentSchema = z.object({
  createHeading: z.string(),
  editHeading: z.string(),
  nameLabel: z.string(),
  namePlaceholder: z.string(),
  logoLabel: z.string(),
  logoPlaceholder: z.string(),
  csrLabel: z.string(),
  complaintsPer10kLabel: z.string(),
  asrLabel: z.string(),
  annualBusinessCroreLabel: z.string(),
  annualBusinessLabelLabel: z.string(),
  segmentsLabel: z.string(),
  segmentResident: z.string(),
  segmentNri: z.string(),
  saveLabel: z.string(),
  cancelLabel: z.string(),
  savedMessage: z.string(),
  duplicateIdError: z.string(),
});

export const adminPolicyFormContentSchema = z.object({
  createHeading: z.string(),
  editHeading: z.string(),
  idLabel: z.string(),
  idPlaceholder: z.string(),
  nameLabel: z.string(),
  namePlaceholder: z.string(),
  insurerLabel: z.string(),
  saveLabel: z.string(),
  cancelLabel: z.string(),
  savedMessage: z.string(),
  duplicateIdError: z.string(),
});

export const adminReviewContentSchema = z.object({
  heading: z.string(),
  subtitle: z.string(),
  emptyLabel: z.string(),
  restrictedMessage: z.string(),
  checksPendingLabel: z.string(),
  checksPassedLabel: z.string(),
  checksFailedLabel: z.string(),
  approveLabel: z.string(),
  approveSuccessMessage: z.string(),
  rejectLabel: z.string(),
  rejectConfirmLabel: z.string(),
  mergeConflictMessage: z.string(),
});

export const adminContentSchema = z.object({
  nav: adminNavContentSchema,
  dashboard: adminDashboardContentSchema,
  insurerForm: adminInsurerFormContentSchema,
  policyForm: adminPolicyFormContentSchema,
  review: adminReviewContentSchema,
});

export const advisorRoleSchema = z.enum(["admin", "member"]);

export const advisorSchema = z.object({
  email: z.string().email(),
  name: z.string().min(1),
  tactId: z.string().min(1).optional(),
  role: advisorRoleSchema,
});

/** react-pdf only decodes PNG/JPEG — a WebP/AVIF path would fail at render time, mid-call. */
const pdfPngPathSchema = z.string().regex(/^\/pdf\/images\/[\w-]+\.png$/, "must be a PNG under /pdf/images/");
const fourStrings = z.object({ question: z.string(), mode: z.string(), bar: z.string(), line: z.string() });

export const pdfSummaryContentSchema = z.object({
  panel: z.object({
    iconTitle: z.string(),
    title: z.string(),
    subtitle: z.string(),
    pilotBadge: z.string(),
    previewHeading: z.string(),
    customerLabel: z.string(),
    ageLabel: z.string(),
    coverLabel: z.string(),
    termLabel: z.string(),
    insurersLabel: z.string(),
    editHint: z.string(),
    editInControlPanelLabel: z.string(),
    editInPolicyPanelLabel: z.string(),
    advisorNameLabel: z.string(),
    discussedOnLabel: z.string(),
    missingHeading: z.string(),
    missingName: z.string(),
    missingDob: z.string(),
    missingMonthlyExpenses: z.string(),
    missingInsurers: z.string(),
    missingAdvisorName: z.string(),
    downloadLabel: z.string(),
    preparingLabel: z.string(),
    errorMessage: z.string(),
    fileNamePrefix: z.string().min(1),
    footnote: z.string(),
  }),
  pdf: z.object({
    whatsappNumber: z.string().regex(/^\d{10,15}$/, "digits only, with country code"),
    topBarLabel: z.string(),
    cover: z.object({
      headline: z.string(),
      sub: z.string(),
      preparedForLabel: z.string(),
      advisorLabel: z.string(),
      issuedLabel: z.string(),
    }),
    personal: z.object({
      title: z.string(),
      sub: z.string(),
      proposerLabel: z.string(),
      residencyLabel: z.string(),
      tobaccoLabel: z.string(),
      rows: z.object({
        employment: z.string(),
        education: z.string(),
        annualIncome: z.string(),
        monthlyExpenses: z.string(),
        uninsuredLoans: z.string(),
        existingCover: z.string(),
      }),
      none: z.string(),
    }),
    outlook: z.object({ title: z.string(), sub: z.string(), yAxisLabel: z.string(), legendLabel: z.string() }),
    npv: z.object({ title: z.string(), sub: z.string(), yAxisLabel: z.string(), claimAgeLabel: z.string() }),
    coverSuggested: z.object({
      suggestedLabel: z.string(),
      termLabel: z.string(),
      termUnit: z.string(),
      breakdown: z.object({ base: z.string(), loans: z.string(), existing: z.string() }),
      termNote: z.string(),
      floorNote: z.string(),
      insurersTitle: z.string(),
      insurersSub: z.string(),
      tableHeaders: z.object({
        insurers: z.string(),
        claims: z.string(),
        claimsSub: z.string(),
        annualBusiness: z.string(),
        annualBusinessSub: z.string(),
        amount: z.string(),
        amountSub: z.string(),
        complaints: z.string(),
        complaintsSub: z.string(),
      }),
      footnote: z.string(),
      cta: z.object({ question: z.string(), sub: z.string(), button: z.string(), message: z.string() }),
    }),
    insurerLogos: z.record(z.string(), pdfPngPathSchema),
    riders: z.object({
      title: z.string(),
      sub: z.string(),
      cards: z
        .array(
          z.object({
            title: z.string(),
            body: z.string(),
            eventText: z.string(),
            calloutText: z.string(),
            recommended: z.boolean(),
          }),
        )
        .length(2, "the riders page lays out exactly two cards"),
      timelineLabels: z.object({ currentAge: z.string(), coverMaturity: z.string() }),
      recommendedBadge: z.string(),
    }),
    payments: z.object({
      title: z.string(),
      sub: z.string(),
      cards: z.object({
        regular: fourStrings,
        retirement: fourStrings,
        limited: z.object({
          mode: z.string(),
          bar: z.string(),
          freeBar: z.string(),
          line: z.string(),
          options: z.array(z.number().int().positive()).min(1),
          chipLabel: z.string(),
          exampleYears: z.number().int().positive(),
          questionOlder: z.string(),
          questionDecades: z.string(),
          lineNoChips: z.string(),
        }),
      }),
      footnote: z.string(),
      banner: z.object({ headline: z.string(), body: z.string() }),
      whyLimited: z.object({
        title: z.string(),
        titleAccent: z.string(),
        rows: z.array(z.object({ label: z.string(), body: z.string() })),
      }),
    }),
    whyNow: z.object({
      title: z.string(),
      sub: z.string(),
      cards: z.array(z.object({ title: z.string(), body: z.string() })).length(4, "the page lays out a 2x2 grid"),
    }),
    whyDitto: z.object({
      title: z.string(),
      sub: z.string(),
      cards: z
        .array(
          z.object({
            icon: pdfPngPathSchema,
            title: z.string(),
            body: z.string(),
            cta: z
              .object({ before: z.string(), link: z.string(), after: z.string(), href: z.string().url() })
              .optional(),
          }),
        )
        .length(3, "the page lays out three columns"),
    }),
    whatsapp: z.object({ eyebrow: z.string(), headline: z.string(), cta: z.string() }),
    disclaimer: z.string(),
  }),
});

/** Registry so the validate-content script can iterate every collection. */
export const schemas = {
  insurer: insurerSchema,
  policiesContent: policiesContentSchema,
  recommendationsContent: recommendationsContentSchema,
  nriGuidelinesContent: nriGuidelinesContentSchema,
  flowsContent: flowsContentSchema,
  welcomeContent: welcomeContentSchema,
  chromeContent: chromeContentSchema,
  adminContent: adminContentSchema,
  policyDetailsContent: policyDetailsContentSchema,
  definitionsContent: definitionsContentSchema,
  coverAmountContent: coverAmountContentSchema,
  profileContent: profileContentSchema,
  policyDetailsPageCopy: policyDetailsPageCopySchema,
  whyNowContent: whyNowContentSchema,
  whyDittoContent: whyDittoContentSchema,
  inbuiltFeaturesContent: inbuiltFeaturesContentSchema,
  inbuiltFeaturesPageContent: inbuiltFeaturesPageContentSchema,
  resourcesContent: resourcesContentSchema,
  specificIllnessesContent: specificIllnessesContentSchema,
  specificIllnessesPageContent: specificIllnessesPageContentSchema,
  ridersContent: ridersContentSchema,
  ridersPageCopy: ridersPageCopySchema,
  premiumOptionsContent: premiumOptionsContentSchema,
  advisor: advisorSchema,
  pdfSummaryContent: pdfSummaryContentSchema,
} as const;
