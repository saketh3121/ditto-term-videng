import "next-auth";
import "next-auth/jwt";
import type { AdvisorRole } from "@/types";

declare module "next-auth" {
  interface Session {
    user: {
      name: string;
      email: string;
      image?: string | null;
      role: AdvisorRole;
    };
  }
  interface User {
    role?: AdvisorRole;
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    role?: AdvisorRole;
  }
}
