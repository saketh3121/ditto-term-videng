/**
 * Shared domain + content types.
 *
 * These are the single source of truth for the *shape* of every piece of
 * content. The zod schemas in `schemas/` validate JSON against these at build
 * time; components consume the inferred types. Rename a field here and the
 * compiler will walk you through every place that must change — nothing breaks
 * silently.
 */

export type Residency = "resident" | "nri";

/** A single term-insurance policy option, owned by one insurer. */
export interface Policy {
  /** Slug — unique across all insurers. */
  id: string;
  /** Plan name without the insurer prefix, e.g. "Click 2 Protect Supreme Plus". */
  name: string;
  /** Owning insurer's slug — must equal an insurer `id`. */
  insurerId: string;
  /** Denormalised insurer display name so the picker needs no join. */
  insurerName: string;
}

/** The policies collection (content/policies.json). */
export interface PoliciesContent {
  policies: Policy[];
}

export type Employment = "salaried" | "self-employed";
export type Citizenship = "indian" | "nri";
export type Gender = "male" | "female";

/** Highest education qualification, ordered highest to lowest. */
export type EducationLevel =
  | "post-graduate"
  | "graduate"
  | "diploma"
  | "hsc"
  | "ssc"
  | "below-10th";

/**
 * Customer inputs captured in the Control Panel. Session-only advisory data —
 * consumed downstream (cover calc, recommendations, riders). Numeric fields are
 * kept as raw input strings; parse at the point of use.
 */
export interface CustomerInfo {
  name: string;
  gender: Gender;
  /** ISO date, "YYYY-MM-DD"; age is derived from it. */
  dob: string;
  annualIncome: string;
  monthlyExpenses: string;
  employment: Employment;
  pincode: string;
  citizenship: Citizenship;
  hasPEDs: boolean;
  pedDetails: string;
  /** Used tobacco in the past 3 years. */
  tobaccoUser: boolean;
  education: EducationLevel;
  /** Raw input string — the age the customer wants cover to run until, when no kid-milestone drives the ideal-tenure calc. */
  preferredCoverAge: string;
  /** Raw input string — sum insured under any existing policy, if any. Blank means none entered, not "none held". */
  existingCoverAmount: string;
  /** Raw input string — any uninsured loan liability to add on top of the suggested cover. */
  uninsuredLoans: string;
  /** Mandatory — the advisor's pasted DittoHQ chat link, e.g. "https://dittohq.in/whatsapp/chats?chat=CH515923". Validated by lib/chat-id.ts before Save is allowed. */
  chatId: string;
}

/** One insurer's published metrics (transcribed from IRDAI figures). */
export interface Insurer {
  /** Slug — must equal the filename stem, e.g. "hdfc-life". */
  id: string;
  name: string;
  logo: string;
  /** Claim Settlement Ratio, %. Higher is better. */
  csr: number;
  /** Complaints per 10,000 claims. Lower is better. */
  complaintsPer10k: number;
  /** Amount Settlement Ratio, %. Higher is better. */
  asr: number;
  /** Annual premium collected, in crore (raw number for charts). */
  annualBusinessCrore: number;
  /** Display string, e.g. "₹30,560 Crore". */
  annualBusinessLabel: string;
  /** Which recommendation sets this insurer appears in. */
  segments: Residency[];
}

/** A single metric's polarity — drives chart colour + "higher/lower is better". */
export type MetricKey = "csr" | "complaintsPer10k" | "asr" | "annualBusinessCrore";

/**
 * The fixed taxonomy for a policy's detail content (eligibility, benefits,
 * riders, NRI/housewife underwriting, …), sourced from Ditto's product
 * playbook. One source of truth, mirrored by policyDetailCategoryIdSchema
 * in schemas/content.ts (hand-synced, same convention as Residency above).
 */
export type PolicyDetailCategoryId =
  | "entry-age"
  | "maturity-age"
  | "educational-qualification"
  | "annual-income"
  | "sum-assured"
  | "pincode-restriction"
  | "smoker-timeline"
  | "premium-payment"
  | "variants"
  | "inbuilt-benefits"
  | "paid-add-ons"
  | "other-optional-features"
  | "discounts-offered"
  | "nri-guidelines"
  | "domestic-housewife-profile"
  | "nri-housewife-profiles";

/** A further breakdown of one PolicyDetailItem's `text`, added when refined later. */
export interface PolicyDetailSubItem {
  label: string;
  text: string;
}

/** One labeled fact within a category, e.g. { label: "Min Age", text: "18" }. */
export interface PolicyDetailItem {
  label: string;
  text: string;
  /**
   * Optional finer breakdown of `text` — absent today. When a text-heavy
   * cell (e.g. "Variants") is later refined into named sub-points, it's
   * added here without changing this item's shape or breaking older data.
   */
  subItems?: PolicyDetailSubItem[];
}

export interface PolicyDetailCategory {
  category: PolicyDetailCategoryId;
  items: PolicyDetailItem[];
}

/** One policy's full detail content (content/policy-details/<policyId>.json). */
export interface PolicyDetailsContent {
  /** Must equal an existing Policy.id. */
  policyId: string;
  categories: PolicyDetailCategory[];
}

/**
 * One glossary entry — a policy-agnostic, plain-English definition of a
 * feature/term (e.g. "Waiver of Premium"), classified under the same
 * PolicyDetailCategoryId taxonomy as the per-policy detail items so a term
 * appearing in a policy's data can be looked up here by label.
 */
export interface DefinitionEntry {
  category: PolicyDetailCategoryId;
  label: string;
  text: string;
}

/** The full glossary (content/definitions.json). */
export interface DefinitionsContent {
  definitions: DefinitionEntry[];
}

/**
 * One abbreviation → full-form pair (e.g. "SA" → "Sum Assured"), used to
 * annotate abbreviations wherever they appear in copy with a hover tooltip.
 * Unlike DefinitionEntry, this is a flat lookup with no category — the match
 * is purely on the abbreviation token itself.
 */
export interface AbbreviationEntry {
  abbr: string;
  expansion: string;
}

/** The full abbreviation glossary (content/abbreviations.json). */
export interface AbbreviationsContent {
  abbreviations: AbbreviationEntry[];
}

/**
 * One of the 4 insurer-reliability metrics — drives both a "Why these four
 * metrics" legend tile (hover/click reveals `description` + the industry/
 * Ditto reference values) and a column in the insurer comparison table.
 */
export interface KeyMetric {
  field: MetricKey;
  title: string;
  description: string;
  industryLabel: string;
  industryValue: string;
  dittoValue: string;
  columnHeader: string;
  columnSuffix: string;
}

/** Page copy contract for the Recommendations step. */
export interface RecommendationsContent {
  eyebrow: string;
  title: string;
  titleAccent: string;
  subtitle: string;
  keyMetricsHeading: string;
  keyMetricsLead: string;
  keyMetrics: KeyMetric[];
  compareHeading: string;
  residentHeading: string;
  nriHeading: string;
  insurerColumnLabel: string;
  viewPolicyDetailsLabel: string;
  footnote: string;
  emptyNote: string;
  /** Deliberately terse and unlabelled with a policy name — a discreet toggle tucked in the corner, not a call to action. */
  secondaryRecommendationToggleLabel: string;
}

/** One insurer's medical-abroad details for a single region tab (GCC/Non-GCC). */
export interface NriMedicalDetailEntry {
  /** Must equal an existing Insurer.id. */
  insurerId: string;
  details: string;
}

/** Content for the collapsible NRI Guidelines table under Recommendations'
 *  comparison section — shown only for NRI customer profiles. */
export interface NriGuidelinesContent {
  heading: string;
  gccLabel: string;
  nonGccLabel: string;
  tableHeading: string;
  insurerColumnLabel: string;
  detailsColumnLabel: string;
  gcc: NriMedicalDetailEntry[];
  nonGcc: NriMedicalDetailEntry[];
  indiaBannerHeading: string;
  indiaBannerText: string;
}

/** One feature's content for a single policy — a cell in the Inbuilt Features table. */
export interface InbuiltFeatureEntry {
  /** False when this policy simply doesn't offer the feature. */
  available: boolean;
  /** Shown directly in the table cell. Null when unavailable. */
  mainContent: string | null;
  /** Fuller breakdown shown in the cell's info-button popover. Null when unavailable or no further detail exists. */
  detailText: string | null;
}

/** One feature row in the Inbuilt Features table, one entry per policy id. */
export interface InbuiltFeature {
  id: string;
  title: string;
  /** Short caption of what the info-button breakdown covers, shown above `detailText` in the popover. */
  detailSummary: string;
  byPolicy: Record<string, InbuiltFeatureEntry>;
}

/** One collapsible section of the Inbuilt Features table (currently just "Inbuilt Benefits"). */
export interface InbuiltFeatureCategory {
  id: string;
  title: string;
  features: InbuiltFeature[];
}

/** The full Inbuilt Features comparison matrix (content/inbuilt-features.json). */
export interface InbuiltFeaturesContent {
  categories: InbuiltFeatureCategory[];
}

/** Page copy for the Resources > Inbuilt Features page (content/pages/inbuilt-features.json). */
export interface InbuiltFeaturesPageContent {
  eyebrow: string;
  title: string;
  titleAccent: string;
  subtitle: string;
  parametersLabel: string;
  /** Shown in a cell when a currently-displayed policy lacks a feature the row is shown for. */
  naLabel: string;
  emptyNote: string;
}

/** The Resources nav section pinned to the bottom of the sidebar (content/resources.json). */
export interface ResourcesContent {
  sectionLabel: string;
  items: Record<string, { label: string }>;
}

/** One headed block of covered conditions — a WOP/CI tier, or a TPD/Terminal-Illness clause, verbatim from the policy wording. */
export interface IllnessList {
  heading: string;
  items: string[];
}

/**
 * Full WOP/CI illness-list matrix (content/specific-illnesses.json). `lists`
 * holds each distinct block once (insurers reuse the same list across
 * several of their own plans); `policies` points each policyId at the
 * block ids that make up its WOP and CI riders. A policyId absent from
 * `policies` has no rider illness data (e.g. the rider isn't offered).
 */
export interface SpecificIllnessesContent {
  lists: Record<string, IllnessList>;
  policies: Record<string, { wop: string[]; ci: string[] }>;
}

/** Page copy for the Resources > Specific Illnesses pages (content/pages/specific-illnesses.json). */
export interface SpecificIllnessesPageContent {
  eyebrow: string;
  title: string;
  titleAccent: string;
  subtitle: string;
  indexIntro: string;
  wopSectionHeading: string;
  ciSectionHeading: string;
  noDataNote: string;
  backToIndexLabel: string;
}

/** One insurer/policy column in a StaticComparisonTable. */
export interface StaticComparisonColumn {
  insurerId: string;
  policyId: string;
}

export type StaticCellKind = "check" | "cross" | "text";

/** One cell in a StaticComparisonTable — a fixed value, not derived from any calc. */
export interface StaticComparisonCell {
  kind: StaticCellKind;
  /** Display text for "text" cells; unused (empty) for "check"/"cross". */
  text: string;
  /** Which footnote (by marker, e.g. "*", "^") this cell's (i) button shows, if any. */
  footnoteMarker: string | null;
}

export interface StaticComparisonRow {
  label: string;
  /** Keyed by policyId — WOP/CI details vary policy-to-policy within the same insurer, not just insurer-to-insurer. */
  cells: Record<string, StaticComparisonCell>;
  /** When true, every non-empty cell in this row gets a "Full List" link to that policy's Specific Illnesses page (Resources). */
  linksToIllnessList?: boolean;
}

export interface StaticComparisonFootnote {
  marker: string;
  text: string;
}

/**
 * A fixed-row comparison table sourced directly from an editorial
 * spreadsheet (WOP/CI riders). One column per policy (all 11 are defined
 * here); which columns actually render is driven by the advisor's current
 * policy selection, same resolution as InbuiltFeaturesContent.
 */
export interface StaticComparisonTable {
  columns: StaticComparisonColumn[];
  rows: StaticComparisonRow[];
  footnotes: StaticComparisonFootnote[];
  disclaimer: string;
}

/** The three Recommended Riders comparison matrices (content/riders.json), one per pill. */
export interface RidersContent {
  wop: StaticComparisonTable;
  ci: StaticComparisonTable;
  others: InbuiltFeaturesContent;
}

/** Page copy contract for the Recommended Riders step (content/pages/riders.json). */
export interface RidersPageCopy {
  eyebrow: string;
  title: string;
  titleAccent: string;
  subtitle: string;
  wopTabLabel: string;
  ciTabLabel: string;
  othersTabLabel: string;
  wopHeading: string;
  ciHeading: string;
  othersHeading: string;
  parametersLabel: string;
  naLabel: string;
  emptyNote: string;
  /** Shown above the pasted WOP explainer artwork (public/illustrations/wop-timeline.png). */
  wopDefinition: string;
  ciDefinition: string;
  /** Link text appended to illness-count cells (rows with linksToIllnessList) — jumps to Resources > Specific Illnesses. */
  fullListLabel: string;
}

/** Copy for the Policy Details in-place view (swapped in from Recommendations). */
export interface PolicyDetailsPageCopy {
  backLabel: string;
  /** Human-readable section title per category, e.g. "inbuilt-benefits" -> "Inbuilt Features". */
  categoryLabels: Record<PolicyDetailCategoryId, string>;
}

/** Profile snapshot banner atop the Cover Amount step. */
export interface ProfileSummaryBannerContent {
  editLabel: string;
  /** Shown when the customer's name hasn't been entered yet. */
  namePlaceholder: string;
  /** Appended straight after the customer's name, e.g. name + "'s Profile". */
  profileHeadingSuffix: string;
  ageLabel: string;
  ageUnit: string;
  monthlyExpensesLabel: string;
  tobaccoLabel: string;
  tobaccoYes: string;
  tobaccoNo: string;
  existingCoverLabel: string;
  annualIncomeLabel: string;
  residencyLabel: string;
  residentValue: string;
  nriValue: string;
  chosenTenureLabel: string;
  /** "{age}" substituted with the Control Panel's "Preferred age of cover" input. Appended after the label, e.g. "Chosen Tenure (Upto 65)". */
  chosenTenureUpToTemplate: string;
  /** Shown next to the chosen-tenure stat when the "cover until" age reaches or exceeds TENURE_WARNING_AGE. */
  chosenTenureWarning: string;
  uninsuredLoansLabel: string;
  /** "—" — used for every field with no data source yet. */
  notAvailable: string;
}

/** The "over" / "within" callout plus disclaimer shown under the max-eligibility table. */
export interface EligibilityComparisonCopy {
  /** Shown when the suggested cover exceeds every insurer's eligibility. */
  over: string;
  /** Shown when the suggested cover falls at or within the eligibility range — also reused for "under" (deliberately the same message, not a distinct warning). */
  within: string;
  disclaimer: string;
}

/** Page copy contract for the Cover Amount step. */
export interface CoverAmountContent {
  eyebrow: string;
  title: string;
  titleAccent: string;
  subtitle: string;
  /** Admin-only — Advanced mode is only reachable to signed-in advisors with role "admin" (see cover-amount.tsx). */
  advancedIntro: string;
  policyTermLabel: string;
  suggestedCoverLabel: string;
  adjustedLabel: string;
  baseCoverLabel: string;
  loansLabel: string;
  existingCoverLabel: string;
  purchaseNowLabel: string;
  policyTermUnit: string;
  idealTenureLabel: string;
  idealTenureUnit: string;
  banner: ProfileSummaryBannerContent;
  eligibilityTableHeading: string;
  eligibilityTableCaption: string;
  eligibilityBelowSuggestedLabel: string;
  eligibilityComparison: EligibilityComparisonCopy;
  /** Sub-heading shown above the Max Eligibility / Suggested Cover tiles. */
  howMuchCoverHeading: string;
  /** Sub-heading shown above the expense/cover projection chart (Basic and Advanced). */
  projectionChartHeading: string;
  /** Shown in place of the Suggested Cover figures when monthly expense hasn't been entered yet in the Control Panel. */
  emptyStateMessage: string;
}

/** Page copy contract for the Premium Payment Options step. */
export interface PremiumOptionsContent {
  eyebrow: string;
  title: string;
  titleAccent: string;
  subtitle: string;
  howOftenHeading: string;
  howOftenIntro: string;
  howOftenDisclaimers: string[];
  howLongHeading: string;
  /** Shown above the pasted Limited-vs-Regular-Pay artwork (public/illustrations/premium-term-comparison.png). */
  howLongIntro: string;
  payTermComparisonHeading: string;
  payTermComparisonRegularLabel: string;
  payTermComparisonLimitedLabel: string;
  payTermComparisonRows: PayTermComparisonRow[];
}

/**
 * One feature-by-feature row in the Regular-vs-Limited-Pay comparison
 * table. No per-row "winner" — the table leans toward Limited Pay
 * entirely through the Limited Pay column's own visual treatment (see
 * PayTermComparisonTable), not a row-by-row verdict.
 */
export interface PayTermComparisonRow {
  /** Lucide icon name, resolved dynamically. */
  icon: string;
  feature: string;
  regularPay: string;
  limitedPay: string;
}

/** One reassurance card in the Profile step's "Before we begin" hero band. */
export interface ProfileAssurance {
  /** Lucide icon name, resolved dynamically. */
  icon: string;
  title: string;
  body: string;
}

/**
 * How a factor card behaves: `readonly` mirrors a value already collected in
 * the Control Panel (with an Edit link back to it, no duplicate input);
 * `input` is a genuinely new field collected right here; `info` is
 * narrative-only, no value at all.
 */
/** One of the 8 factor tiles in the Profile step's hover-reveal grid. */
export interface ProfileFactor {
  /** Stable key. */
  id: string;
  /** Lucide icon name, resolved dynamically. */
  icon: string;
  title: string;
  /** Revealed on hover/focus. May contain inline "<bold>...</bold>" spans for emphasis. */
  body: string;
}

/** Page copy contract for the Profile (eligibility) step. */
export interface ProfileContent {
  eyebrow: string;
  title: string;
  titleAccent: string;
  subtitle: string;
  assurances: ProfileAssurance[];
  factors: ProfileFactor[];
}

/** One card in the Why Now Matters 2x2 grid. */
export interface WhyNowCard {
  /** Lucide icon name, resolved dynamically. */
  icon: string;
  title: string;
  body: string;
}

/** Page copy contract for the Why Now Matters step. */
export interface WhyNowContent {
  eyebrow: string;
  heading: string;
  /** Exact substring of `heading` to render in the accent colour. */
  headingAccent: string;
  cards: WhyNowCard[];
}

/** One of the Why Ditto hover-reveal pillar cards. */
export interface WhyDittoCard {
  title: string;
  body: string;
}

/** One real, already-public LinkedIn customer testimonial. */
export interface LinkedInReview {
  customerName: string;
  /** URL back to the original LinkedIn post. */
  mediumLink: string;
  review: string;
}

/** Page copy contract for the Why Ditto step. */
export interface WhyDittoContent {
  eyebrow: string;
  title: string;
  titleAccent: string;
  cards: WhyDittoCard[];
  reviewsSectionLabel: string;
  reviews: LinkedInReview[];
}

/** One scroll-anchored sub-section within a step page. */
export interface SubStepContent {
  /** DOM id of the target section — the sidebar scrolls to it. */
  id: string;
  title: string;
}

/** Flow + step labels (structure itself lives in config/flows.ts). */
export interface FlowsContent {
  flow: { title: string; description: string };
  steps: Record<string, { label: string }>;
  /** Optional per-step sub-section labels, keyed by stepId. */
  subSteps?: Record<string, SubStepContent[]>;
}

/** One value-prop tile on the welcome screen. */
export interface WelcomeValueProp {
  /** Lucide icon name, resolved dynamically. */
  icon: string;
  title: string;
  description: string;
}

/** Page copy contract for the welcome / landing screen. */
export interface WelcomeContent {
  badge: string;
  heading: string;
  headingAccent: string;
  advisorEyebrow: string;
  advisorName: string;
  advisorTitle: string;
  /** Intro sentence; "{name}" is substituted with the advisor's first name. */
  advisorIntro: string;
  ctaLabel: string;
  ctaMicrocopy: string;
  valueProps: WelcomeValueProp[];
}

/** Control Panel (customer info) labels. */
export interface ControlPanelContent {
  iconTitle: string;
  title: string;
  subtitle: string;
  nameLabel: string;
  namePlaceholder: string;
  genderLabel: string;
  genderMale: string;
  genderFemale: string;
  dobLabel: string;
  ageLabel: string;
  ageUnit: string;
  annualIncomeLabel: string;
  monthlyExpensesLabel: string;
  amountPlaceholder: string;
  employmentLabel: string;
  employmentSalaried: string;
  employmentSelfEmployed: string;
  pincodeLabel: string;
  pincodePlaceholder: string;
  citizenshipLabel: string;
  citizenshipIndian: string;
  citizenshipNri: string;
  pedsLabel: string;
  pedsYes: string;
  pedsNo: string;
  pedDetailsLabel: string;
  pedDetailsPlaceholder: string;
  tobaccoLabel: string;
  tobaccoYes: string;
  tobaccoNo: string;
  educationLabel: string;
  educationPostGraduate: string;
  educationGraduate: string;
  educationDiploma: string;
  educationHsc: string;
  educationSsc: string;
  educationBelow10th: string;
  preferredCoverAgeLabel: string;
  preferredCoverAgePlaceholder: string;
  /** Shown when the entered "cover until" age reaches or exceeds TENURE_WARNING_AGE (config/milestone-assumptions.ts). */
  preferredCoverAgeWarning: string;
  existingCoverAmountLabel: string;
  uninsuredLoansLabel: string;
  chatIdLabel: string;
  chatIdPlaceholder: string;
  chatIdError: string;
  saveLabel: string;
}

/** Policy Panel (policy multi-select) labels. */
export interface PolicyPanelContent {
  iconTitle: string;
  title: string;
  subtitle: string;
  searchPlaceholder: string;
  selectedTemplate: string;
  clearLabel: string;
  applyLabel: string;
  emptyLabel: string;
}

/** Persistent chrome labels — top bar, sidebar, and shell affordances. */
export interface ChromeContent {
  brand: string;
  homeLink: string;
  nextStepLabel: string;
  menuLabel: string;
  themeToggleTitle: string;
  sidebarCollapseTitle: string;
  sidebarExpandTitle: string;
  segmentControlTitle: string;
  closeLabel: string;
  /** Icon-button label — clears persisted inputs and resets the whole flow. */
  startOverLabel: string;
  /** Confirmation prompt shown before startOverLabel actually resets anything. */
  startOverConfirm: string;
  /** Optional, time-bound caution strip under the top bar on every advisor
   *  page — shown only while `policyId` is among the advisor's selected
   *  policies and the current time is before `expiresAt`. Delete the whole
   *  field once the notice is no longer relevant; no code change needed. */
  priceRevisionBanner?: {
    /** Must equal an existing Policy.id (content/policies.json). */
    policyId: string;
    message: string;
    /** ISO 8601 datetime, IST — the banner stops showing at/after this instant. */
    expiresAt: string;
  };
  controlPanel: ControlPanelContent;
  policyPanel: PolicyPanelContent;
}

/** Admin nav labels. */
export interface AdminNavContent {
  brand: string;
  dashboardLabel: string;
  insurersLabel: string;
  policiesLabel: string;
  reviewLabel: string;
  /** "{email}" is substituted with the signed-in user's email. */
  signedInAsTemplate: string;
  signOutLabel: string;
}

/** Admin dashboard copy. */
export interface AdminDashboardContent {
  heading: string;
  subtitle: string;
  insurersCardTitle: string;
  policiesCardTitle: string;
  manageLabel: string;
  /** "{count}" is substituted with the number of pending changes. */
  pendingBannerTemplate: string;
  pendingBannerEmptyLabel: string;
  pendingBannerCta: string;
}

/** Admin insurer create/edit form copy. */
export interface AdminInsurerFormContent {
  createHeading: string;
  editHeading: string;
  nameLabel: string;
  namePlaceholder: string;
  logoLabel: string;
  logoPlaceholder: string;
  csrLabel: string;
  complaintsPer10kLabel: string;
  asrLabel: string;
  annualBusinessCroreLabel: string;
  annualBusinessLabelLabel: string;
  segmentsLabel: string;
  segmentResident: string;
  segmentNri: string;
  saveLabel: string;
  cancelLabel: string;
  savedMessage: string;
  duplicateIdError: string;
}

/** Admin policy create/edit form copy. */
export interface AdminPolicyFormContent {
  createHeading: string;
  editHeading: string;
  idLabel: string;
  idPlaceholder: string;
  nameLabel: string;
  namePlaceholder: string;
  insurerLabel: string;
  saveLabel: string;
  cancelLabel: string;
  savedMessage: string;
  duplicateIdError: string;
}

/** Admin review (diff + approve/reject) copy. */
export interface AdminReviewContent {
  heading: string;
  subtitle: string;
  emptyLabel: string;
  restrictedMessage: string;
  checksPendingLabel: string;
  checksPassedLabel: string;
  checksFailedLabel: string;
  approveLabel: string;
  approveSuccessMessage: string;
  rejectLabel: string;
  rejectConfirmLabel: string;
  mergeConflictMessage: string;
}

/** Full admin CMS content contract (content/admin.json). */
export interface AdminContent {
  nav: AdminNavContent;
  dashboard: AdminDashboardContent;
  insurerForm: AdminInsurerFormContent;
  policyForm: AdminPolicyFormContent;
  review: AdminReviewContent;
}

export type AdvisorRole = "admin" | "member";

/** One allowlisted sign-in (content/advisors/<slug>.json). */
export interface Advisor {
  email: string;
  name: string;
  tactId?: string;
  role: AdvisorRole;
}

/** Customer Summary PDF (content/pdf-summary.json) — the admin-only panel
 *  copy plus every string printed on the generated PDF. `{name}` tokens are
 *  filled by lib/pdf/summary-model.ts. */
export interface PdfSummaryPanelContent {
  iconTitle: string;
  title: string;
  subtitle: string;
  pilotBadge: string;
  previewHeading: string;
  customerLabel: string;
  ageLabel: string;
  coverLabel: string;
  termLabel: string;
  insurersLabel: string;
  editHint: string;
  editInControlPanelLabel: string;
  editInPolicyPanelLabel: string;
  advisorNameLabel: string;
  discussedOnLabel: string;
  missingHeading: string;
  missingName: string;
  missingDob: string;
  missingMonthlyExpenses: string;
  missingInsurers: string;
  missingAdvisorName: string;
  downloadLabel: string;
  preparingLabel: string;
  errorMessage: string;
  fileNamePrefix: string;
  footnote: string;
}

export interface PdfRiderCardContent {
  title: string;
  body: string;
  eventText: string;
  calloutText: string;
  recommended: boolean;
}

export interface PdfWhyDittoCardContent {
  /** Path under public/, PNG only (react-pdf can't decode WebP/AVIF). */
  icon: string;
  title: string;
  body: string;
  cta?: { before: string; link: string; after: string; href: string };
}

export interface PdfDocumentContent {
  /** International format, no "+" — used in wa.me links. */
  whatsappNumber: string;
  topBarLabel: string;
  cover: { headline: string; sub: string; preparedForLabel: string; advisorLabel: string; issuedLabel: string };
  personal: {
    title: string;
    sub: string;
    proposerLabel: string;
    residencyLabel: string;
    tobaccoLabel: string;
    rows: {
      employment: string;
      education: string;
      annualIncome: string;
      monthlyExpenses: string;
      uninsuredLoans: string;
      existingCover: string;
    };
    none: string;
  };
  outlook: { title: string; sub: string; yAxisLabel: string; legendLabel: string };
  npv: { title: string; sub: string; yAxisLabel: string; claimAgeLabel: string };
  coverSuggested: {
    suggestedLabel: string;
    termLabel: string;
    termUnit: string;
    breakdown: { base: string; loans: string; existing: string };
    termNote: string;
    /** Shown on the cover card when BASIC_COVER_FLOOR lifted the base above the computed need. */
    floorNote: string;
    insurersTitle: string;
    insurersSub: string;
    tableHeaders: {
      insurers: string;
      claims: string;
      claimsSub: string;
      annualBusiness: string;
      annualBusinessSub: string;
      amount: string;
      amountSub: string;
      complaints: string;
      complaintsSub: string;
    };
    footnote: string;
    cta: { question: string; sub: string; button: string; message: string };
  };
  /** Insurer.id -> PNG path under public/. This app's own /logos files include WebP/AVIF, which react-pdf can't decode. */
  insurerLogos: Record<string, string>;
  riders: {
    title: string;
    sub: string;
    cards: PdfRiderCardContent[];
    timelineLabels: { currentAge: string; coverMaturity: string };
    recommendedBadge: string;
  };
  payments: {
    title: string;
    sub: string;
    cards: {
      regular: { question: string; mode: string; bar: string; line: string };
      retirement: { question: string; mode: string; bar: string; line: string };
      limited: {
        mode: string;
        bar: string;
        freeBar: string;
        line: string;
        options: number[];
        chipLabel: string;
        exampleYears: number;
        questionOlder: string;
        questionDecades: string;
        lineNoChips: string;
      };
    };
    footnote: string;
    banner: { headline: string; body: string };
    whyLimited: { title: string; titleAccent: string; rows: { label: string; body: string }[] };
  };
  whyNow: { title: string; sub: string; cards: { title: string; body: string }[] };
  whyDitto: { title: string; sub: string; cards: PdfWhyDittoCardContent[] };
  whatsapp: { eyebrow: string; headline: string; cta: string };
  disclaimer: string;
}

export interface PdfSummaryContent {
  panel: PdfSummaryPanelContent;
  pdf: PdfDocumentContent;
}
