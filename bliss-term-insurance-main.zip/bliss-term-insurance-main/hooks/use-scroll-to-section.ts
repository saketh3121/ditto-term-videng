"use client";

import { useCallback } from "react";

const SCROLL_OFFSET = 24;

/**
 * Smooth-scroll to a section by DOM id. The flow content scrolls inside the
 * <main> element (not the window), so we compute the offset relative to that
 * container. Used by the sidebar sub-step links.
 */
export function useScrollToSection() {
  return useCallback((sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (!element) return;

    const scrollContainer = element.closest("main");
    if (!scrollContainer) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
      return;
    }

    const containerRect = scrollContainer.getBoundingClientRect();
    const elementRect = element.getBoundingClientRect();
    const top =
      elementRect.top -
      containerRect.top +
      scrollContainer.scrollTop -
      SCROLL_OFFSET;

    scrollContainer.scrollTo({ top, behavior: "smooth" });
  }, []);
}
