import { DiffView } from "@/components/admin/diff-view";
import { ReviewActions } from "@/components/admin/review-actions";
import { auth } from "@/lib/auth";
import { buildFullDiff } from "@/lib/cms/pending-changes";
import { isAdminEmail } from "@/lib/cms/roles";
import adminContent from "@/content/admin.json";
import type { AdminContent } from "@/types";

const CONTENT = (adminContent as AdminContent).review;

export default async function AdminReviewPage() {
  const session = await auth();
  const isAdmin = await isAdminEmail(session?.user?.email);

  if (!isAdmin) {
    return (
      <div className="flex flex-col gap-2">
        <h1 className="text-h2 font-bold text-text-primary">{CONTENT.heading}</h1>
        <p className="text-text-secondary">{CONTENT.restrictedMessage}</p>
      </div>
    );
  }

  const changes = await buildFullDiff();

  return (
    <div className="flex max-w-3xl flex-col gap-6">
      <div>
        <h1 className="text-h2 font-bold text-text-primary">{CONTENT.heading}</h1>
        <p className="mt-1 text-text-secondary">{CONTENT.subtitle}</p>
      </div>

      {changes.length === 0 ? (
        <p className="text-sm text-text-muted">{CONTENT.emptyLabel}</p>
      ) : (
        <>
          <DiffView changes={changes} />
          <ReviewActions content={CONTENT} />
        </>
      )}
    </div>
  );
}
