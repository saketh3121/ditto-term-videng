import { notFound } from "next/navigation";
import { InsurerForm } from "@/components/admin/insurer-form";
import { getStagedOrLiveInsurer } from "@/lib/cms/staged-content";
import adminContent from "@/content/admin.json";
import type { AdminContent } from "@/types";

const CONTENT = (adminContent as AdminContent).insurerForm;

export default async function EditInsurerPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const insurer = await getStagedOrLiveInsurer(id);
  if (!insurer) notFound();

  return <InsurerForm mode="edit" initial={insurer} content={CONTENT} />;
}
