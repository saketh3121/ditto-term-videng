import Link from "next/link";
import { Button } from "@/components/ui/button";
import { InsurerTable } from "@/components/admin/insurer-table";
import { getInsurers } from "@/lib/content";
import { buildFullDiff } from "@/lib/cms/pending-changes";

export default async function AdminInsurersPage() {
  const [insurers, changes] = await Promise.all([getInsurers(), buildFullDiff()]);
  const pendingIds = new Set(
    changes.filter((c) => c.recordType === "insurer").map((c) => c.recordId),
  );

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h1 className="text-h2 font-bold text-text-primary">Insurers</h1>
        <Link href="/admin/insurers/new">
          <Button>New insurer</Button>
        </Link>
      </div>
      <InsurerTable insurers={insurers} pendingIds={pendingIds} />
    </div>
  );
}
