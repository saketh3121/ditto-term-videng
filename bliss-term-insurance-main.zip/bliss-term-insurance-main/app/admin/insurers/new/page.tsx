import { InsurerForm } from "@/components/admin/insurer-form";
import adminContent from "@/content/admin.json";
import type { AdminContent } from "@/types";

const CONTENT = (adminContent as AdminContent).insurerForm;

export default function NewInsurerPage() {
  return <InsurerForm mode="create" initial={null} content={CONTENT} />;
}
