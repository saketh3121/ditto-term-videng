import Link from "next/link";
import { Button } from "@/components/ui/button";
import { PolicyTable } from "@/components/admin/policy-table";
import { getPoliciesLive, groupPoliciesByInsurer } from "@/lib/cms/policies-live";
import { buildFullDiff } from "@/lib/cms/pending-changes";

export default async function AdminPoliciesPage() {
  const [{ policies }, changes] = await Promise.all([getPoliciesLive(), buildFullDiff()]);
  const groups = groupPoliciesByInsurer(policies);
  const pendingIds = new Set(
    changes.filter((c) => c.recordType === "policy").map((c) => c.recordId),
  );

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h1 className="text-h2 font-bold text-text-primary">Policies</h1>
        <Link href="/admin/policies/new">
          <Button>New policy</Button>
        </Link>
      </div>
      <PolicyTable groups={groups} pendingIds={pendingIds} />
    </div>
  );
}
