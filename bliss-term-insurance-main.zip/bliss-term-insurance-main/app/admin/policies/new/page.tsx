import { PolicyForm } from "@/components/admin/policy-form";
import { getInsurers } from "@/lib/content";
import adminContent from "@/content/admin.json";
import type { AdminContent } from "@/types";

const CONTENT = (adminContent as AdminContent).policyForm;

export default async function NewPolicyPage() {
  const insurers = await getInsurers();
  return <PolicyForm mode="create" initial={null} insurers={insurers} content={CONTENT} />;
}
