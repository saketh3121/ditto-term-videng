import { notFound } from "next/navigation";
import { PolicyForm } from "@/components/admin/policy-form";
import { getInsurers } from "@/lib/content";
import { getStagedOrLivePolicies } from "@/lib/cms/staged-content";
import adminContent from "@/content/admin.json";
import type { AdminContent } from "@/types";

const CONTENT = (adminContent as AdminContent).policyForm;

export default async function EditPolicyPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const [{ policies }, insurers] = await Promise.all([getStagedOrLivePolicies(), getInsurers()]);
  const policy = policies.find((p) => p.id === id) ?? null;
  if (!policy) notFound();

  return <PolicyForm mode="edit" initial={policy} insurers={insurers} content={CONTENT} />;
}
