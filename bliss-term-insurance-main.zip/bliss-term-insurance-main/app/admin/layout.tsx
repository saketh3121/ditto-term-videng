import { AdminNav } from "@/components/admin/admin-nav";
import { PendingChangesBanner } from "@/components/admin/pending-changes-banner";
import { auth } from "@/lib/auth";
import { buildFullDiff } from "@/lib/cms/pending-changes";
import { isAdminEmail } from "@/lib/cms/roles";
import adminContent from "@/content/admin.json";
import type { AdminContent } from "@/types";

const CONTENT = adminContent as AdminContent;

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await auth();
  const email = session?.user?.email;
  if (!email) {
    // Defense in depth — proxy.ts already redirects unauthenticated /admin
    // requests to /login before this ever renders.
    return null;
  }

  const [changes, isAdmin] = await Promise.all([buildFullDiff(), isAdminEmail(email)]);

  return (
    <div className="text-scale-reset flex min-h-screen flex-col bg-bg-primary">
      <AdminNav content={CONTENT.nav} email={email} isAdmin={isAdmin} />
      <PendingChangesBanner content={CONTENT.dashboard} changes={changes} />
      <main className="flex-1 px-6 py-6">{children}</main>
    </div>
  );
}
