import Link from "next/link";
import { getInsurers } from "@/lib/content";
import { getPoliciesLive } from "@/lib/cms/policies-live";
import adminContent from "@/content/admin.json";
import type { AdminContent } from "@/types";

const CONTENT = (adminContent as AdminContent).dashboard;

export default async function AdminDashboardPage() {
  const [insurers, { policies }] = await Promise.all([getInsurers(), getPoliciesLive()]);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-h1 font-bold text-text-primary">{CONTENT.heading}</h1>
        <p className="mt-1 text-text-secondary">{CONTENT.subtitle}</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Link
          href="/admin/insurers"
          className="rounded-lg border border-border-default bg-bg-card p-5 transition-colors hover:bg-hover-surface"
        >
          <p className="text-xs font-semibold uppercase tracking-wide text-text-muted">
            {CONTENT.insurersCardTitle}
          </p>
          <p className="mt-2 text-2xl font-bold text-text-primary">{insurers.length}</p>
          <p className="mt-2 text-xs font-semibold text-accent-blue">{CONTENT.manageLabel} →</p>
        </Link>
        <Link
          href="/admin/policies"
          className="rounded-lg border border-border-default bg-bg-card p-5 transition-colors hover:bg-hover-surface"
        >
          <p className="text-xs font-semibold uppercase tracking-wide text-text-muted">
            {CONTENT.policiesCardTitle}
          </p>
          <p className="mt-2 text-2xl font-bold text-text-primary">{policies.length}</p>
          <p className="mt-2 text-xs font-semibold text-accent-blue">{CONTENT.manageLabel} →</p>
        </Link>
      </div>
    </div>
  );
}
