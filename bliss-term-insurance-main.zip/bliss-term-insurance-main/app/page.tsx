"use client";

import { Fragment } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import * as LucideIcons from "lucide-react";
import { ArrowRight } from "lucide-react";
import { TopBar } from "@/components/layout/top-bar";
import { firstStepId } from "@/config/flows";
import welcomeContent from "@/content/pages/welcome.json";
import type { WelcomeContent } from "@/types";

const CONTENT = welcomeContent as WelcomeContent;

type IconComponent = React.ComponentType<{ className?: string; strokeWidth?: number }>;

function getIcon(name: string): IconComponent {
  const map = LucideIcons as unknown as Record<string, IconComponent>;
  return map[name] ?? LucideIcons.ShieldCheck;
}

/** Wrap the "{name}" placeholder in a bold primary span within the intro. */
function renderIntroWithName(template: string, name: string) {
  const parts = template.split("{name}");
  return parts.map((part, i) => (
    <Fragment key={i}>
      {part}
      {i < parts.length - 1 && (
        <span className="font-semibold text-text-primary">{name}</span>
      )}
    </Fragment>
  ));
}

/** Welcome / landing — outside the guided flow, with its own layout. */
export default function LandingPage() {
  const { data: session } = useSession();
  const advisorName = session?.user?.name ?? CONTENT.advisorName;

  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden bg-bg-primary">
      {/* Decorative glows */}
      <div
        aria-hidden
        className="bg-glow-accent pointer-events-none absolute top-1/2 -left-[320px] h-[485px] w-[640px] -translate-y-1/2"
      />
      <div
        aria-hidden
        className="bg-glow-accent pointer-events-none absolute top-1/2 -right-[160px] h-[485px] w-[640px] -translate-y-1/2 opacity-50"
      />

      <TopBar />

      <main className="relative z-10 flex flex-1 flex-col items-center px-4 pt-10 pb-12">
        {/* Badge */}
        <div className="mb-3 inline-flex items-center gap-2 rounded-pill border border-accent-blue-border bg-accent-blue-soft px-4 py-2 animate-fade-in-up">
          <span className="text-sm text-accent-blue">{CONTENT.badge}</span>
        </div>

        {/* Heading */}
        <h1 className="mb-14 text-center font-display text-4xl font-extrabold tracking-tight text-text-primary animate-fade-in-up md:text-6xl lg:text-[105px] lg:leading-[0.98] lg:tracking-[-2px]">
          {CONTENT.heading}{" "}
          <span className="text-accent-blue">{CONTENT.headingAccent}</span>
        </h1>

        {/* Cards */}
        <div className="flex w-full max-w-[1056px] flex-col items-center gap-10">
          {/* Advisor card */}
          <div className="relative flex min-h-[240px] w-full flex-col gap-5 overflow-hidden rounded-hero border border-accent-blue-border bg-bg-card-accent px-8 py-7 animate-fade-in-up">
            {/* Concentric rings */}
            <span
              aria-hidden
              className="pointer-events-none absolute -right-[120px] -bottom-[120px] h-[320px] w-[320px] rounded-full border border-accent-sky/10"
            />
            <span
              aria-hidden
              className="pointer-events-none absolute -right-[60px] -bottom-[60px] h-[200px] w-[200px] rounded-full border border-accent-sky/10"
            />

            <div className="relative z-[1] flex items-center gap-4">
              <div className="bg-gradient-avatar inline-flex h-14 w-14 shrink-0 items-center justify-center rounded-full text-xl font-bold tracking-[-0.02em] text-white ring-4 ring-accent-blue/10">
                {advisorName.charAt(0).toUpperCase()}
              </div>
              <div>
                <div className="mb-1.5 text-[13px] font-semibold uppercase tracking-[0.12em] text-accent-blue">
                  {CONTENT.advisorEyebrow}
                </div>
                <div className="text-[28px] font-bold leading-[1.2] tracking-[-0.015em] text-text-primary">
                  {advisorName}
                </div>
                <div className="mt-0.5 text-[16px] text-text-secondary">
                  {CONTENT.advisorTitle}
                </div>
              </div>
            </div>

            <p className="relative z-[1] mt-0 mb-0 ml-[72px] mr-[72px] text-[19px] leading-[1.55] text-text-secondary">
              {renderIntroWithName(CONTENT.advisorIntro, advisorName)}
            </p>

            <div className="relative z-[1] mt-2 flex flex-col items-center gap-2">
              <Link
                href={`/flow/${firstStepId()}`}
                className="inline-flex items-center justify-center gap-2 rounded-pill bg-accent-blue px-10 py-4 text-base font-medium text-white shadow-md transition-all hover:gap-3 hover:shadow-lg"
              >
                {CONTENT.ctaLabel}
                <ArrowRight className="h-4 w-4" />
              </Link>
              <p className="text-xs text-text-muted">{CONTENT.ctaMicrocopy}</p>
            </div>
          </div>

          {/* Value props */}
          <div className="grid w-full grid-cols-1 gap-10 md:grid-cols-3">
            {CONTENT.valueProps.map((prop) => {
              const Icon = getIcon(prop.icon);
              return (
                <div
                  key={prop.title}
                  className="min-h-[210px] rounded-hero border border-border-default bg-bg-card px-8 pt-9 pb-8 animate-fade-in-up"
                >
                  <Icon className="mb-5 h-6 w-6 text-accent-blue" strokeWidth={1.8} />
                  <h3 className="text-base font-semibold text-text-primary">
                    {prop.title}
                  </h3>
                </div>
              );
            })}
          </div>
        </div>
      </main>
    </div>
  );
}
