"use client";

import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { ChevronDown } from "lucide-react";
import { TopBar } from "@/components/layout/top-bar";
import { LeftSidebar } from "@/components/layout/left-sidebar";
import { RightSidebar } from "@/components/layout/right-sidebar";
import { adjacentSteps, type StepId } from "@/config/flows";
import { cn } from "@/lib/utils";
import chromeContent from "@/content/chrome.json";
import type { ChromeContent } from "@/types";

const CHROME = chromeContent as ChromeContent;

/**
 * Persistent flow shell: top bar + collapsible step rail + scrollable content
 * + thin right rail. The animated "Next Step" chevron and the mobile nav
 * drawer live here so every step inherits the same layout and motion.
 */
export default function FlowLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const params = useParams();
  const router = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);

  const stepId = params.stepId as string | undefined;
  const next = stepId ? adjacentSteps(stepId as StepId).next : undefined;

  return (
    <div className="flex h-screen flex-col bg-bg-primary">
      <TopBar showMenu onMenuClick={() => setMobileOpen(true)} />

      <div className="flex min-h-0 flex-1 overflow-hidden">
        {/* Desktop step rail */}
        <LeftSidebar />

        {/* Mobile nav drawer */}
        <div
          className={cn(
            "fixed inset-0 z-50 lg:hidden",
            mobileOpen ? "pointer-events-auto" : "pointer-events-none",
          )}
          aria-hidden={!mobileOpen}
        >
          <div
            className={cn(
              "absolute inset-0 bg-black/40 transition-opacity duration-200",
              mobileOpen ? "opacity-100" : "opacity-0",
            )}
            onClick={() => setMobileOpen(false)}
          />
          <div
            className={cn(
              "absolute left-0 top-0 h-full w-[380px] border-r border-border-default bg-bg-sidebar transition-transform duration-200 ease-out",
              mobileOpen ? "translate-x-0" : "-translate-x-full",
            )}
          >
            <LeftSidebar
              className="flex w-full border-r-0"
              collapsible={false}
              onNavigate={() => setMobileOpen(false)}
            />
          </div>
        </div>

        {/* Scrollable content */}
        <main className="min-w-0 flex-1 overflow-y-auto px-4 py-6 lg:px-12 lg:py-12">
          <div className="mx-auto max-w-[1120px]">{children}</div>

          {next && (
            <div className="flex flex-col items-center gap-2 py-10">
              <span className="select-none text-[13px] font-semibold uppercase tracking-[0.12em] text-text-muted">
                {CHROME.nextStepLabel}
              </span>
              <button
                onClick={() => router.push(`/flow/${next.id}`)}
                aria-label={`Go to ${next.label}`}
                title={next.label}
                className="flex h-10 w-10 cursor-pointer items-center justify-center rounded-full border border-border-default bg-bg-card text-text-muted shadow-sm transition-colors hover:border-accent-blue/40 hover:bg-accent-blue/5 hover:text-accent-blue"
              >
                <ChevronDown className="h-5 w-5 animate-bounce-down" strokeWidth={2} />
              </button>
            </div>
          )}
        </main>

        {/* Thin right rail */}
        <RightSidebar />
      </div>
    </div>
  );
}
