import { notFound } from "next/navigation";
import { PageShell } from "@/components/layout/page-shell";
import { CoverAmountStep } from "@/components/steps/cover-amount";
import { PremiumOptions } from "@/components/steps/premium-options";
import { ProfileStep } from "@/components/steps/profile-step";
import { Recommendations } from "@/components/steps/recommendations";
import { Riders } from "@/components/steps/riders";
import { WhyDitto } from "@/components/steps/why-ditto";
import { WhyNow } from "@/components/steps/why-now";
import { getAllPolicyDetails, getInsurers, getInsurersBySegment } from "@/lib/content";
import { stepById, STEPS } from "@/config/flows";
import coverAmountContent from "@/content/pages/cover-amount.json";
import policyDetailsContent from "@/content/pages/policy-details.json";
import premiumOptionsContent from "@/content/pages/premium-options.json";
import profileContent from "@/content/pages/profile.json";
import recommendationsContent from "@/content/pages/recommendations.json";
import ridersPageContent from "@/content/pages/riders.json";
import whyDittoContent from "@/content/pages/why-ditto.json";
import whyNowContent from "@/content/pages/why-now.json";
import type {
  CoverAmountContent,
  PolicyDetailsPageCopy,
  PremiumOptionsContent,
  ProfileContent,
  RecommendationsContent,
  RidersPageCopy,
  WhyDittoContent,
  WhyNowContent,
} from "@/types";

/** Pre-render every step route from the single flow definition. */
export function generateStaticParams() {
  return STEPS.map((s) => ({ stepId: s.id }));
}

export default async function StepPage({
  params,
}: {
  params: Promise<{ stepId: string }>;
}) {
  const { stepId } = await params;
  const step = stepById(stepId);
  if (!step) notFound();

  // Recommendations is the fully-built vertical slice (the proven pattern).
  if (step.id === "recommendations") {
    const content = recommendationsContent as RecommendationsContent;
    const policyDetailsCopy = policyDetailsContent as PolicyDetailsPageCopy;
    const [resident, nri, allInsurers, allPolicyDetails] = await Promise.all([
      getInsurersBySegment("resident"),
      getInsurersBySegment("nri"),
      getInsurers(),
      getAllPolicyDetails(),
    ]);
    const policyDetailsByPolicyId = Object.fromEntries(allPolicyDetails.map((p) => [p.policyId, p]));
    return (
      <PageShell
        eyebrow={content.eyebrow}
        title={content.title}
        titleAccent={content.titleAccent}
        subtitle={content.subtitle}
      >
        <Recommendations
          content={content}
          insurersBySegment={{ resident, nri }}
          allInsurers={allInsurers}
          policyDetailsByPolicyId={policyDetailsByPolicyId}
          policyDetailsCopy={policyDetailsCopy}
        />
      </PageShell>
    );
  }

  if (step.id === "riders") {
    const content = ridersPageContent as RidersPageCopy;
    const allInsurers = await getInsurers();
    return (
      <PageShell
        eyebrow={content.eyebrow}
        title={content.title}
        titleAccent={content.titleAccent}
        subtitle={content.subtitle}
      >
        <Riders content={content} allInsurers={allInsurers} />
      </PageShell>
    );
  }

  if (step.id === "eligibility") {
    const content = profileContent as ProfileContent;
    return (
      <PageShell
        eyebrow={content.eyebrow}
        title={content.title}
        titleAccent={content.titleAccent}
        subtitle={content.subtitle}
      >
        <ProfileStep content={content} />
      </PageShell>
    );
  }

  if (step.id === "cover-amount") {
    const content = coverAmountContent as CoverAmountContent;
    return (
      <PageShell
        eyebrow={content.eyebrow}
        title={content.title}
        titleAccent={content.titleAccent}
        subtitle={content.subtitle}
      >
        <CoverAmountStep content={content} />
      </PageShell>
    );
  }

  if (step.id === "premium-options") {
    const content = premiumOptionsContent as PremiumOptionsContent;
    return (
      <PageShell
        eyebrow={content.eyebrow}
        title={content.title}
        titleAccent={content.titleAccent}
        subtitle={content.subtitle}
      >
        <PremiumOptions content={content} />
      </PageShell>
    );
  }

  if (step.id === "why-now") {
    const content = whyNowContent as WhyNowContent;
    // headingAccent ("now") sits mid-heading, not at the end like every
    // other step — split around the exact substring rather than relying on
    // PageShell's usual trailing title/titleAccent pair.
    const [before, after] = content.heading.split(content.headingAccent);
    return (
      <PageShell
        eyebrow={content.eyebrow}
        title={
          <>
            {before}
            <span className="text-accent-blue">{content.headingAccent}</span>
            {after}
          </>
        }
      >
        <WhyNow content={content} />
      </PageShell>
    );
  }

  if (step.id === "why-ditto") {
    const content = whyDittoContent as WhyDittoContent;
    return (
      <PageShell eyebrow={content.eyebrow} title={content.title} titleAccent={content.titleAccent}>
        <WhyDitto content={content} />
      </PageShell>
    );
  }

  // Remaining steps: routed and framed, awaiting their content component.
  return (
    <PageShell
      eyebrow={`STEP ${String(step.n).padStart(2, "0")}`}
      title={step.label}
      subtitle="This step is scaffolded and routed. Its content component is the next phase of the build."
    >
      <div className="flex flex-col items-center gap-2 rounded-hero border border-dashed border-border-default bg-bg-card px-6 py-16 text-center">
        <p className="text-base font-semibold text-text-primary">{step.label}</p>
        <p className="text-sm text-text-muted">Content component coming next.</p>
      </div>
    </PageShell>
  );
}
