import { notFound } from "next/navigation";
import { PageShell } from "@/components/layout/page-shell";
import { InbuiltFeaturesPage } from "@/components/steps/inbuilt-features-page";
import { getInsurers } from "@/lib/content";
import { resourceById, RESOURCES } from "@/config/resources";
import inbuiltFeaturesPageContent from "@/content/pages/inbuilt-features.json";
import type { InbuiltFeaturesPageContent, Insurer } from "@/types";

/**
 * Pre-render only the resources this generic template actually renders.
 * Specific Illnesses owns its own route tree (app/flow/resources/specific-illnesses/)
 * with a more specific static segment that Next resolves first — listing it
 * here too would generate a colliding static path for the same URL.
 */
export function generateStaticParams() {
  return RESOURCES.filter((r) => r.id === "inbuilt-features").map((r) => ({ resourceId: r.id }));
}

export default async function ResourcePage({
  params,
}: {
  params: Promise<{ resourceId: string }>;
}) {
  const { resourceId } = await params;
  const resource = resourceById(resourceId);
  if (!resource) notFound();

  if (resource.id === "inbuilt-features") {
    const content = inbuiltFeaturesPageContent as InbuiltFeaturesPageContent;
    const allInsurers = await getInsurers();
    const insurersById: Record<string, Insurer> = {};
    for (const insurer of allInsurers) insurersById[insurer.id] = insurer;

    return (
      <PageShell
        eyebrow={content.eyebrow}
        title={content.title}
        titleAccent={content.titleAccent}
        subtitle={content.subtitle}
      >
        <InbuiltFeaturesPage content={content} insurersById={insurersById} />
      </PageShell>
    );
  }

  notFound();
}
