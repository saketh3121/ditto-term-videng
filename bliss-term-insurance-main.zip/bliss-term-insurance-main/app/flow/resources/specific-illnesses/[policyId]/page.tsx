import { notFound } from "next/navigation";
import { PageShell } from "@/components/layout/page-shell";
import { BackToIndexLink } from "@/components/steps/back-to-index-link";
import { IllnessListSection } from "@/components/steps/illness-list-section";
import { policyById, POLICIES } from "@/lib/policies";
import { hasIllnessData, illnessListsForPolicy, policyIdsWithIllnessData } from "@/lib/specific-illnesses";
import specificIllnessesPageContent from "@/content/pages/specific-illnesses.json";
import type { SpecificIllnessesPageContent } from "@/types";

/** Pre-render only the policies that actually have WOP/CI illness-list data. */
export function generateStaticParams() {
  return policyIdsWithIllnessData(POLICIES.map((p) => p.id)).map((policyId) => ({ policyId }));
}

export default async function SpecificIllnessesPolicyPage({
  params,
}: {
  params: Promise<{ policyId: string }>;
}) {
  const { policyId } = await params;
  const policy = policyById(policyId);
  if (!policy || !hasIllnessData(policyId)) notFound();

  const content = specificIllnessesPageContent as SpecificIllnessesPageContent;
  const wopLists = illnessListsForPolicy(policyId, "wop");
  const ciLists = illnessListsForPolicy(policyId, "ci");

  return (
    <PageShell eyebrow={`${content.eyebrow} · ${policy.insurerName}`} title={policy.name} subtitle={content.subtitle}>
      <div className="flex flex-col gap-10">
        <BackToIndexLink indexHref="/flow/resources/specific-illnesses" label={content.backToIndexLabel} />

        <IllnessListSection id="wop" heading={content.wopSectionHeading} lists={wopLists} emptyNote={content.noDataNote} />
        <IllnessListSection id="ci" heading={content.ciSectionHeading} lists={ciLists} emptyNote={content.noDataNote} />
      </div>
    </PageShell>
  );
}
