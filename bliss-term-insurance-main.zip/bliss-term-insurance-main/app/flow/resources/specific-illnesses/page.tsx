import Link from "next/link";
import { PageShell } from "@/components/layout/page-shell";
import { policiesByInsurer } from "@/lib/policies";
import { hasIllnessData } from "@/lib/specific-illnesses";
import specificIllnessesPageContent from "@/content/pages/specific-illnesses.json";
import type { SpecificIllnessesPageContent } from "@/types";

/** Resources > Specific Illnesses index: every policy, grouped by insurer, linking to its own WOP/CI illness-list page where data exists. */
export default function SpecificIllnessesIndexPage() {
  const content = specificIllnessesPageContent as SpecificIllnessesPageContent;
  const groups = policiesByInsurer();

  return (
    <PageShell
      eyebrow={content.eyebrow}
      title={content.title}
      titleAccent={content.titleAccent}
      subtitle={content.subtitle}
    >
      <div className="flex flex-col gap-8">
        <p className="max-w-[640px] text-base leading-[1.6] text-text-secondary">{content.indexIntro}</p>

        {groups.map((group) => (
          <div key={group.insurerId} className="flex flex-col gap-3">
            <h3 className="text-[13px] font-bold uppercase tracking-[0.12em] text-text-muted">
              {group.insurerName}
            </h3>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {group.policies.map((policy) =>
                hasIllnessData(policy.id) ? (
                  <Link
                    key={policy.id}
                    href={`/flow/resources/specific-illnesses/${policy.id}`}
                    className="rounded-card border border-border-default bg-bg-card px-5 py-4 text-sm font-semibold text-text-primary transition-colors hover:border-accent-blue/40 hover:bg-accent-blue-soft"
                  >
                    {policy.name}
                  </Link>
                ) : (
                  <div
                    key={policy.id}
                    className="flex flex-col gap-1 rounded-card border border-dashed border-border-default px-5 py-4 text-sm text-text-muted"
                  >
                    <span className="font-semibold">{policy.name}</span>
                    <span className="text-xs">{content.noDataNote}</span>
                  </div>
                ),
              )}
            </div>
          </div>
        ))}
      </div>
    </PageShell>
  );
}
