import { NextRequest, NextResponse } from "next/server";
import { ALLOWED_EMAIL_DOMAIN } from "@/config/auth";
import { writeAdvisorFile } from "@/lib/cms/advisors";

/**
 * Unauthenticated by design — this is a plain link an admin clicks from an
 * email client (see the Apps Script poller in docs/apps-script/). The shared
 * `APPROVAL_SECRET` is the only thing standing between "anyone who guesses
 * this URL" and "can add themselves to the allowlist", so it's checked
 * before anything else. See docs/AUTH.md for the full request→approve flow.
 */

function htmlPage(title: string, body: string, status: number): NextResponse {
  return new NextResponse(
    `<!DOCTYPE html><html><head><title>${title}</title></head><body><h2>${title}</h2><p>${body}</p></body></html>`,
    { status, headers: { "Content-Type": "text/html" } },
  );
}

export async function GET(req: NextRequest): Promise<NextResponse> {
  const email = (req.nextUrl.searchParams.get("email") ?? "").toLowerCase();
  const name = req.nextUrl.searchParams.get("name") ?? email;
  const secret = req.nextUrl.searchParams.get("secret") ?? "";

  const approvalSecret = process.env.APPROVAL_SECRET;
  if (!approvalSecret) return htmlPage("Configuration error", "APPROVAL_SECRET is not set.", 500);
  if (!secret || secret !== approvalSecret) {
    return htmlPage("Unauthorized", "Invalid or missing approval secret.", 401);
  }
  if (!email || !email.endsWith(`@${ALLOWED_EMAIL_DOMAIN}`)) {
    return htmlPage("Invalid email", `Must be a @${ALLOWED_EMAIL_DOMAIN} address.`, 400);
  }

  try {
    await writeAdvisorFile({ email, name, role: "member" });
  } catch (err) {
    console.error(`[approve-access] failed to write advisor file for ${email}:`, err);
    return htmlPage("Error", "Something went wrong writing the allowlist entry.", 500);
  }

  return htmlPage("Access approved", `${email} has been granted access. It'll take effect once the site redeploys.`, 200);
}
