import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { isChatLogConfigured, upsertSessionRecord } from "@/lib/cms/chat-log";
import { sessionLogPayloadSchema } from "@/lib/session/payload";
import { buildSessionRecord } from "@/lib/session/record";

/**
 * Receives session snapshots from components/session-tracker.tsx. An API
 * route rather than a Server Action so the tracker can send its last
 * snapshot with `fetch(..., { keepalive: true })` while the tab is closing.
 *
 * Gated by proxy.ts like every page, and re-checked here: the advisor's
 * identity comes from the auth session, never the request body, and the
 * engagement/coverage/qualified flags are recomputed from raw views.
 */
export async function POST(req: Request): Promise<NextResponse> {
  const session = await auth();
  const email = session?.user?.email;
  if (!email) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const parsed = sessionLogPayloadSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "invalid payload" }, { status: 400 });

  if (!isChatLogConfigured()) return NextResponse.json({ error: "chat log not configured" }, { status: 503 });

  const record = buildSessionRecord(parsed.data, { email, name: session.user?.name ?? email }, new Date());
  try {
    const result = await upsertSessionRecord(record);
    return NextResponse.json({ result });
  } catch (err) {
    console.error(`[session-log] failed to write ${record.chatId} (${record.sessionId}):`, err);
    return NextResponse.json({ error: "write failed" }, { status: 502 });
  }
}
