"use server";

import { auth } from "@/lib/auth";
import { getInsurers } from "@/lib/content";
import type { Insurer } from "@/types";

/**
 * Insurer metrics for the customer summary PDF, in the order requested.
 * Admin-only while the summary is piloted — re-checked here, not just by
 * hiding the button, since a server action is callable directly.
 */
export async function loadSummaryInsurers(insurerIds: string[]): Promise<Insurer[]> {
  const session = await auth();
  if (session?.user?.role !== "admin") throw new Error("loadSummaryInsurers: admin only");
  const all = await getInsurers();
  return insurerIds.map((id) => all.find((i) => i.id === id)).filter((i): i is Insurer => i !== undefined);
}
