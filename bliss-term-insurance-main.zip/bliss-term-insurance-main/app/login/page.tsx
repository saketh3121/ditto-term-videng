import { signIn } from "@/lib/auth";
import { Button } from "@/components/ui/button";

const ERROR_MESSAGES: Record<string, string> = {
  AccessDenied: "Your account isn't authorized to access this site.",
};

/** Google sign-in, restricted to Ditto advisors (@joinditto.in). */
export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ callbackUrl?: string; pending?: string; error?: string }>;
}) {
  const { callbackUrl, pending, error } = await searchParams;
  const isPending = pending === "true";
  const errorMessage = error ? (ERROR_MESSAGES[error] ?? "Something went wrong signing you in.") : null;

  return (
    <div className="text-scale-reset relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-bg-primary px-6">
      {/* Decorative glow */}
      <div
        aria-hidden
        className="bg-glow-accent pointer-events-none absolute top-1/2 left-1/2 h-[560px] w-[720px] -translate-x-1/2 -translate-y-1/2"
      />

      <div className="relative z-10 flex w-full max-w-md flex-col items-center gap-6 rounded-hero border border-border-default bg-bg-card px-8 py-12 text-center animate-fade-in-up">
        <h1 className="text-3xl font-bold text-text-primary">
          ditto<span className="text-accent-blue">.</span>
        </h1>

        {isPending ? (
          <p className="max-w-sm text-text-secondary">
            Your request has been sent to an admin — you&apos;ll get access shortly. Try signing in
            again once you&apos;ve been approved.
          </p>
        ) : (
          <>
            <p className="max-w-sm text-text-secondary">
              Advisor sign-in. Use your <strong className="text-text-primary">@joinditto.in</strong>{" "}
              Google account.
            </p>
            {errorMessage && <p className="max-w-sm text-sm text-bad">{errorMessage}</p>}
            <form
              action={async () => {
                "use server";
                await signIn("google", { redirectTo: callbackUrl ?? "/" });
              }}
            >
              <Button size="lg" type="submit">
                Continue with Google
              </Button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
