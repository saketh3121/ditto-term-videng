import type { Metadata } from "next";
import { Inter, JetBrains_Mono } from "next/font/google";
import { Providers } from "@/components/providers";
import "./globals.css";

/**
 * Site-wide type face per the Ditto brand guidelines — Inter, restricted to
 * Regular/SemiBold/Bold. Body copy and headings/sub-headings alike are this
 * one family; hierarchy comes from weight and size, not a second family or
 * italics.
 */
const inter = Inter({
  subsets: ["latin"],
  weight: ["400", "600", "700"],
  variable: "--font-inter",
  display: "swap",
});

/** Numeric/data face — large rupee figures only (cover amounts, premiums). */
const jetbrainsMono = JetBrains_Mono({ subsets: ["latin"], variable: "--font-jetbrains-mono" });

export const metadata: Metadata = {
  title: "Ditto — Term Insurance Advisory",
  description: "Advisor-led guide to choosing the right term cover.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en"
      className={`${inter.variable} ${jetbrainsMono.variable}`}
      suppressHydrationWarning
    >
      <body className="text-scale-1_25x">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
