// Google Apps Script project — lives OUTSIDE this repo (script.google.com),
// deployed as a time-driven trigger, not a Web App (nothing calls into it;
// it only reads GitHub and sends Gmail). This file is a checked-in reference
// copy so it's version-controlled somewhere, but Apps Script itself is
// authored/run from its own project, not from this git history.
//
// Setup: see docs/AUTH.md "Apps Script poller setup".
//
// Script Properties needed (Project Settings > Script Properties):
//   GITHUB_PAT        — fine-grained PAT, scoped to sakdittoeth/bliss-term-insurance
//                        only, Contents: Read and write (needs write to delete
//                        processed request files)
//   REPO              — "sakdittoeth/bliss-term-insurance"
//   APPROVAL_SECRET   — must match this app's APPROVAL_SECRET env var exactly
//   APP_BASE_URL      — e.g. "https://bliss-term-insurance.vercel.app"
//   ADMIN_EMAIL       — where approval emails go

function pollPendingRequests() {
  const props = PropertiesService.getScriptProperties();
  const pat = props.getProperty("GITHUB_PAT");
  const repo = props.getProperty("REPO");
  const secret = props.getProperty("APPROVAL_SECRET");
  const baseUrl = props.getProperty("APP_BASE_URL");
  const adminEmail = props.getProperty("ADMIN_EMAIL");

  const listUrl = `https://api.github.com/repos/${repo}/contents/pending-requests`;
  const headers = { Authorization: `Bearer ${pat}`, Accept: "application/vnd.github+json" };

  let files;
  try {
    const res = UrlFetchApp.fetch(listUrl, { headers, muteHttpExceptions: true });
    if (res.getResponseCode() === 404) return; // folder doesn't exist yet — nothing queued
    files = JSON.parse(res.getContentText());
  } catch (e) {
    console.error("Failed to list pending-requests: " + e);
    return;
  }

  files.forEach((file) => {
    if (!file.name.endsWith(".json")) return;

    const fileRes = UrlFetchApp.fetch(file.download_url, { headers });
    const request = JSON.parse(fileRes.getContentText()); // { name, email, requestedAt }

    const approveUrl =
      `${baseUrl}/api/approve-access?email=${encodeURIComponent(request.email)}` +
      `&name=${encodeURIComponent(request.name)}` +
      `&secret=${encodeURIComponent(secret)}`;

    GmailApp.sendEmail(
      adminEmail,
      `Access request: ${request.email}`,
      `${request.name} (${request.email}) requested access.\n\nApprove: ${approveUrl}`,
      {
        htmlBody: `<p>${request.name} (${request.email}) requested access.</p><p><a href="${approveUrl}">Approve access</a></p>`,
      },
    );

    // Delete the processed file so it isn't re-emailed next run.
    UrlFetchApp.fetch(`https://api.github.com/repos/${repo}/contents/${file.path}`, {
      method: "delete",
      headers: { ...headers, "Content-Type": "application/json" },
      payload: JSON.stringify({
        message: `processed request from ${request.email}`,
        sha: file.sha,
        branch: "main",
      }),
      muteHttpExceptions: true,
    });
  });
}
