# Editing guide

How to make common changes safely. Every recipe here is designed so a mistake
is caught by the build, not by a customer on a call.

## Change a heading or paragraph

1. Open the page's file in `content/pages/` (e.g. `recommendations.json`).
2. Edit the string. Save.
3. `npm run validate:content` confirms the shape still matches. Done.

If you rename or remove a key, the build fails with the exact file + field —
that's the safety net working. Update the matching type in `types/` and schema
in `schemas/` if the shape genuinely changed.

## Add or change an insurer

1. Add a file `content/insurers/<slug>.json` (slug = the `id`).
2. Match the shape in `types/index.ts` (`Insurer`); `schemas/content.ts`
   validates it.
3. That's it — the loader (`lib/content.ts`), the sidebar, the charts, and the
   comparison all pick it up automatically. **There is no second list to edit.**
   (Contrast the old app, which required editing two hardcoded logo maps.)

## Tune the cover calculator

`config/assumptions.ts` — edit `retirementAge`, `inflationRate`,
`minPolicyTerm`, `coverRoundingLakh`. All constants are here, labelled. The
logic in `lib/calc/cover.ts` has unit tests (`cover.test.ts`) that run in CI.

## Change shell / navigation labels

Top-bar, sidebar, and shell affordance strings live in `content/chrome.json`
(brand, Home link, "Next Step", collapse/expand titles, …). The welcome screen's
copy lives in `content/pages/welcome.json`. Both are validated on
`npm run validate:content`.

## Add or reorder a flow step

`config/flows.ts` is the single source of truth. Add the step id to `ORDER` and
a label in `content/flows.json`. The route, the left-rail entry, and the
animated Next Step chevron all follow. Then create
`components/steps/<step>.tsx` and branch to it in `app/flow/[stepId]/page.tsx`.

To give a step scroll-anchored sub-sections (they appear indented under the
active step in the sidebar and smooth-scroll on click), add a `subSteps` entry
for its id in `content/flows.json` and render a matching `<section id="…">` in
the step component (see `recommendations.tsx`).

## The shell & its motion

The persistent flow shell (`app/flow/layout.tsx`) is: top bar + collapsible
left rail (`left-sidebar.tsx`, 240↔60px) + scrollable `<main>` + thin right rail
(`right-sidebar.tsx`). Motion is deliberately small and lives in
`app/globals.css`: the bouncing Next Step chevron (`animate-bounce-down`), the
sidebar width transition, hover `transition-colors`, smooth anchor scrolling,
the mobile drawer slide-in, and a gentle `animate-fade-in-up` on hero content.
All of it respects `prefers-reduced-motion`. Colours come only from the tokens
in `globals.css` — never hardcode a hex in a component.

## Add a chart

Add a component in `components/charts/`. Keep it presentational (data in via
props), theme-aware (use CSS variables, never hex), and reusable across steps.

## Before you push

```bash
npm run check   # typecheck + lint + validate:content + test
```
