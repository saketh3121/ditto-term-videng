# Dark mode archived

Dark mode is **archived** — there's no toggle anywhere in the UI and the app
always renders light, regardless of the visitor's system preference or any
theme previously stored in their browser.

The underlying capability is left intact and dormant: `next-themes` is still
installed and wraps the tree, the `.dark` CSS token overrides in
`app/globals.css` are untouched, and every `-dark.png` illustration/logo
variant on disk is still there. Restoring is reverting the edits below, not
rebuilding the feature.

## What changed

| File | Archived state | Restore to |
|---|---|---|
| `components/providers.tsx` | `<ThemeProvider forcedTheme="light" ...>` | drop `forcedTheme` |
| `components/layout/top-bar.tsx` | no theme toggle button; logo hardcoded to `/ditto-logo.png` | re-add the toggle button and the `mounted && theme === "dark"` logo ternary (see git history) |
| `components/layout/right-sidebar.tsx` | no theme toggle rail button | re-add the toggle `RailButton` (see git history) |
| `components/steps/premium-term-comparison.tsx` | illustration src fixed to `PaymentTerm_{F\|M}.png` | restore the `mounted && theme === "dark" ? "-dark" : ""` suffix |
| `components/steps/rider-illustration-tile.tsx` | illustration src fixed to `{WOP\|CI}_{F\|M}.png` | restore the `-dark` suffix logic |

`content/chrome.json`'s `themeToggleTitle` field and the `.dark` block in
`app/globals.css` were **not** touched — both stay in place, unused, ready
for the toggle to read from again.

## Restore steps

1. Revert the five files above (git history has the pre-archive versions).
2. Run `npm run check` and `npm run build` to confirm green.
3. Manually toggle light/dark once in a browser to confirm the class swap
   and the `-dark` asset variants both still resolve correctly.
