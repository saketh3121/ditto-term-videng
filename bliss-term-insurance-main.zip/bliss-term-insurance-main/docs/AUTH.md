# Auth — Google sign-in, allowlist, and access requests

Google sign-in is live and gates the whole site (`/`, `/flow/*`, `/admin/*`) —
see `proxy.ts`. Only `/login`, the NextAuth routes, and the unauthenticated
`/api/approve-access` link stay open.

## How it works

1. An advisor signs in with Google. `lib/auth.ts`'s `signIn` callback rejects
   anything outside `@<ALLOWED_EMAIL_DOMAIN>` (`config/auth.ts`, default
   `joinditto.in`).
2. Within that domain, only advisors present in `content/advisors/*.json` get
   in. Each has a `role`: `"admin"` | `"member"` — `role: "admin"` gates the
   `/admin/review` screen and the approve/reject/merge actions
   (`lib/cms/roles.ts`'s `isAdminEmail`, the single source of truth for admin
   status — there's no separate admin list to keep in sync).
3. `SUPER_ADMIN_EMAIL` (`config/auth.ts`, default `pappu.naga@joinditto.in`)
   always gets in and self-seeds its own `role: "admin"` entry on first
   sign-in if one doesn't already exist.
4. An in-domain account that ISN'T on the allowlist doesn't get a bare
   denial — it lands on `/login?pending=true` and triggers the access-request
   flow below.

## The allowlist store

Plain git-committed JSON, consistent with this repo's content-as-data
architecture (CLAUDE.md) — one file per advisor:

```
content/advisors/<email-slug>.json   →  { "email", "name", "tactId"?, "role" }
```

Read via `lib/content.ts`'s `getAdvisorByEmail` / `getAllAdvisors` (validated
against `schemas/content.ts`'s `advisorSchema`, wired into
`npm run validate:content`). **Writes never touch the filesystem in
production** — Vercel's filesystem is read-only — they go through the GitHub
Contents API instead, via `lib/cms/advisors.ts`'s `writeAdvisorFile()`
(reusing the same `upsertFile()` + `CMS_GITHUB_TOKEN` Octokit plumbing the
admin CMS already uses, just committing straight to `main` instead of the
CMS's PR branch). The site picks up a new/changed advisor file on the next
deploy.

## Access-request flow

`@joinditto.in`'s Google Workspace blocks both direct SMTP from third-party
senders and externally-triggered Apps Script Web Apps — the same restriction
`ditto-health-insurance-bliss` hit, which is why this mirrors that app's
GitHub-as-queue design rather than calling a transactional email API
directly:

```
unregistered @joinditto.in user attempts sign-in
        │
        ▼
lib/email.ts writes pending-requests/<ts>-<slug>.json to `main` via GitHub Contents API
        │
        ▼
Google Apps Script (time-driven trigger, every 5 min) polls that folder
        │
        ▼
Apps Script emails the admin a one-click "Approve" link, then deletes the file
        │
        ▼
Admin clicks the link → GET /api/approve-access?email=...&name=...&secret=...
        │
        ▼
app/api/approve-access/route.ts writes content/advisors/<slug>.json (role: member) via the same GitHub API path
        │
        ▼
Host auto-deploys `main` → the requester can sign in once that finishes
```

Nothing in this flow touches the production filesystem directly.

### Apps Script poller setup

Lives outside this repo, as its own Apps Script project (script.google.com) —
a reference copy is checked in at
[`docs/apps-script/poll-pending-requests.js`](apps-script/poll-pending-requests.js)
so it's version-controlled somewhere, but must be pasted into an actual Apps
Script project to run.

1. script.google.com → New project → paste
   `docs/apps-script/poll-pending-requests.js`.
2. Project Settings → Script Properties → add `GITHUB_PAT`, `REPO`,
   `APPROVAL_SECRET`, `APP_BASE_URL`, `ADMIN_EMAIL` (see the file's header
   comment for what each holds).
3. Triggers (clock icon) → Add Trigger → `pollPendingRequests` → Time-driven →
   Minutes timer → Every 5 minutes.
4. First run prompts an OAuth consent for the script's own Gmail/UrlFetch
   scopes — approve as the admin account that should send these emails.
5. No Web App deployment needed — it's purely an outbound poller, nothing
   calls into it.

This project should be **dedicated to this repo**, separate from
`ditto-health-insurance-bliss`'s poller — its own trigger, its own PAT
scoped only to `sakdittoeth/bliss-term-insurance`, so an issue with one
site's poller can't affect the other's.

## Env vars

| Variable | Required | Notes |
|---|---|---|
| `AUTH_GOOGLE_ID` / `AUTH_GOOGLE_SECRET` | yes | Google Cloud Console OAuth client. Redirect URI: `<origin>/api/auth/callback/google` for every environment. |
| `AUTH_SECRET` | yes | NextAuth session encryption. Generate: `npx auth secret` or `openssl rand -base64 33`. |
| `ALLOWED_EMAIL_DOMAIN` | no | Defaults to `joinditto.in` (`config/auth.ts`). |
| `SUPER_ADMIN_EMAIL` | no | Defaults to `pappu.naga@joinditto.in` (`config/auth.ts`). |
| `CMS_GITHUB_TOKEN` | yes | Already required by the CMS — reused here for advisor + pending-request writes. Fine-grained PAT, this repo only, Contents: Read and write. |
| `APPROVAL_SECRET` | yes | Long random string. Must match the Apps Script's `APPROVAL_SECRET` Script Property exactly. |
| `NEXT_PUBLIC_SITE_URL` | recommended | Not required by the approve-access route itself (only ever hit via the emailed link), but useful to have set. |

## Adding an advisor manually

Skip the request flow entirely by committing a
`content/advisors/<email-slug>.json` file directly — same shape as the
existing seed files, `role: "member"` or `"admin"`.
