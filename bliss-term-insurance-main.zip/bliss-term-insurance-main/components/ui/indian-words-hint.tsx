import { numberToIndianWords } from "@/lib/format-indian-words";

/** Live "did I type that right" readout under a monetary input. Renders nothing until there's a positive value. */
export function IndianWordsHint({ value }: { value: string }) {
  const n = Number(value);
  if (!value || !Number.isFinite(n) || n <= 0) return null;
  return <p className="text-[14px] text-text-muted">{numberToIndianWords(n)}</p>;
}
