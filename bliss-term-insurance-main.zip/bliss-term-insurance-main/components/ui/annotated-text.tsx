import { annotateAbbreviations } from "@/lib/abbreviations";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

/**
 * Renders `text` with any glossary abbreviation (SA, WOP, ADB, …) marked with
 * a dotted underline (same color as the surrounding text — no tint); hovering
 * reveals its full expansion in a small tooltip. Plain text otherwise renders
 * unchanged. Safe to use anywhere a content string is
 * shown as a single line or paragraph — not for `whitespace-pre-line` blocks
 * broken across multiple lines by the caller (those should call this per line).
 */
export function AnnotatedText({ text }: { text: string }) {
  const segments = annotateAbbreviations(text);

  return (
    <>
      {segments.map((segment, i) =>
        segment.kind === "text" ? (
          <span key={i}>{segment.value}</span>
        ) : (
          <Tooltip key={i}>
            <TooltipTrigger className="m-0 inline border-0 border-b border-dotted border-current/50 bg-transparent p-0 text-inherit">
              {segment.abbr}
            </TooltipTrigger>
            <TooltipContent>{segment.expansion}</TooltipContent>
          </Tooltip>
        ),
      )}
    </>
  );
}
