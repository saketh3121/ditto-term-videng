import { formatRupees } from "@/lib/calc/cover";
import { cn } from "@/lib/utils";

/**
 * Renders a rupee figure with the "₹" glyph in the site's regular sans
 * face and only the digits/suffix in the monospace numeric face — JetBrains
 * Mono's ₹ glyph renders noticeably oversized next to its own digits, which
 * `formatRupees()` alone can't fix since it returns one glued-together
 * string. `prefix` (e.g. "+", "-") sits outside both, in the surrounding
 * (sans) flow.
 */
export function RupeeAmount({
  amount,
  prefix,
  className,
}: {
  amount: number;
  prefix?: string;
  className?: string;
}) {
  const formatted = formatRupees(amount);
  const symbol = formatted.slice(0, 1);
  const rest = formatted.slice(1);
  return (
    <span className={cn("font-sans", className)}>
      {prefix}
      {symbol}
      <span className="font-mono">{rest}</span>
    </span>
  );
}
