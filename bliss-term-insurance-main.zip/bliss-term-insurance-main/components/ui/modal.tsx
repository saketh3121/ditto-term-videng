"use client";

import { useState } from "react";
import { Dialog as DialogPrimitive } from "@base-ui/react/dialog";
import { Info, X } from "lucide-react";
import { AnnotatedText } from "@/components/ui/annotated-text";

/**
 * Centered info modal — replaces the earlier anchored-popover pattern for
 * table-cell (i) buttons. Structure per spec: bold title, one or more
 * labeled bullets (each an uppercase muted label, an optional plain lead
 * line, then either a single value line or a bulleted list), and an
 * optional trailing plain note. Backdrop click and Escape close it
 * (Base UI's Dialog handles both natively).
 */

export interface ModalBullet {
  label: string;
  lead?: string;
  value: string | string[];
}

export interface ModalPayload {
  title: string;
  bullets: ModalBullet[];
  note?: string;
}

function Modal({
  open,
  onOpenChange,
  payload,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  payload: ModalPayload | null;
}) {
  return (
    <DialogPrimitive.Root open={open} onOpenChange={onOpenChange}>
      <DialogPrimitive.Portal>
        <DialogPrimitive.Backdrop className="animate-fade-in fixed inset-0 z-50 bg-black/40" />
        <DialogPrimitive.Popup className="fixed left-1/2 top-1/2 z-50 max-h-[85vh] w-full max-w-[520px] -translate-x-1/2 -translate-y-1/2 overflow-y-auto rounded-card border border-border-default bg-bg-card p-6 outline-none">
          {payload && (
            <>
              <DialogPrimitive.Close
                aria-label="Close"
                className="absolute right-4 top-4 inline-flex h-8 w-8 cursor-pointer items-center justify-center rounded-md text-text-muted transition-colors hover:bg-hover-surface hover:text-text-primary"
              >
                <X className="h-4 w-4" />
              </DialogPrimitive.Close>
              {/* Heading:body ratio fixed at 1:0.75 (text-lg's current 22.5px * 0.75 =
                  16.875px) — label and body previously drifted independently
                  (a hand-picked 14px label next to text-sm body), so the two
                  never lined up. Label keeps its weight/case/color distinction;
                  only its size now matches the body tier below it. */}
              <DialogPrimitive.Title className="pr-10 text-lg font-bold text-text-primary">
                <AnnotatedText text={payload.title} />
              </DialogPrimitive.Title>
              <ul className="mt-4 flex flex-col gap-3">
                {payload.bullets.map((b, i) => (
                  <li key={i} className="flex flex-col gap-1">
                    <span className="text-[16.875px] font-semibold uppercase tracking-wide text-text-muted">
                      <AnnotatedText text={b.label} />
                    </span>
                    {b.lead && (
                      <span className="text-[16.875px] text-text-secondary">
                        <AnnotatedText text={b.lead} />
                      </span>
                    )}
                    {Array.isArray(b.value) ? (
                      <ul className="flex list-disc flex-col gap-1 pl-5">
                        {b.value.map((v, j) => (
                          <li key={j} className="whitespace-pre-line text-[16.875px] text-text-secondary">
                            <AnnotatedText text={v} />
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <span className="whitespace-pre-line text-[16.875px] text-text-secondary">
                        <AnnotatedText text={b.value} />
                      </span>
                    )}
                  </li>
                ))}
              </ul>
              {payload.note && (
                <p className="mt-4 whitespace-pre-line text-[16.875px] text-text-secondary">
                  <AnnotatedText text={payload.note} />
                </p>
              )}
            </>
          )}
        </DialogPrimitive.Popup>
      </DialogPrimitive.Portal>
    </DialogPrimitive.Root>
  );
}

/** Self-contained (i) trigger + modal, so call sites don't need to manage open state themselves. */
export function InfoModalButton({ payload, className }: { payload: ModalPayload; className?: string }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label={`More info about ${payload.title}`}
        className={
          className ??
          "inline-flex h-4 w-4 shrink-0 cursor-pointer items-center justify-center rounded-full text-text-muted transition-colors hover:bg-bg-card-elevated hover:text-accent-blue"
        }
      >
        <Info className="h-3.5 w-3.5" />
      </button>
      <Modal open={open} onOpenChange={setOpen} payload={payload} />
    </>
  );
}

export { Modal };
