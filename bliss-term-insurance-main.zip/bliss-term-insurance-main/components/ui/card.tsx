import { cn } from "@/lib/utils";

/** Standard surface. Token-driven background + border; no hardcoded colours. */
export function Card({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "bg-card border border-default rounded-[var(--radius-card)] p-6",
        className,
      )}
      {...props}
    />
  );
}
