import { cn } from "@/lib/utils";

/** Token-driven text/number/date input. */
export function Input({
  className,
  ...props
}: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        "h-10 w-full rounded-md border border-border-default bg-bg-card-elevated px-3 text-sm text-text-primary outline-none transition-colors placeholder:text-text-muted focus:border-accent-blue/50 focus:ring-2 focus:ring-accent-blue/15",
        className,
      )}
      {...props}
    />
  );
}
