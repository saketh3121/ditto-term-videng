"use client";

import { cn } from "@/lib/utils";

/** Compact segmented pill control for binary/short choices. */
export function Segmented({
  value,
  options,
  onChange,
  className,
}: {
  value: string;
  options: { value: string; label: string }[];
  onChange: (value: string) => void;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "inline-flex w-full gap-1 rounded-md border border-border-default p-1",
        className,
      )}
    >
      {options.map((option) => (
        <button
          key={option.value}
          type="button"
          onClick={() => onChange(option.value)}
          className={cn(
            "flex-1 rounded-[6px] px-3 py-1.5 text-xs font-semibold transition-colors cursor-pointer",
            value === option.value
              ? "bg-accent-blue text-white"
              : "text-text-secondary hover:text-text-primary",
          )}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}
