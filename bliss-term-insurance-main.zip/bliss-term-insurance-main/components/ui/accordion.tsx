"use client";

import * as React from "react";
import { Accordion as AccordionPrimitive } from "@base-ui/react/accordion";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

/** Thin, token-styled wrapper around Base UI's Accordion — used for the
 * Policy Details view's per-category collapsible sections. */

function AccordionRoot<Value = unknown>(props: AccordionPrimitive.Root.Props<Value>) {
  return <AccordionPrimitive.Root {...props} />;
}

function AccordionItem({ className, ...props }: AccordionPrimitive.Item.Props) {
  return (
    <AccordionPrimitive.Item
      data-slot="accordion-item"
      className={cn("flex flex-col scroll-mt-24", className)}
      {...props}
    />
  );
}

function AccordionTrigger({ className, children, ...props }: AccordionPrimitive.Trigger.Props) {
  return (
    <AccordionPrimitive.Header className="flex">
      <AccordionPrimitive.Trigger
        data-slot="accordion-trigger"
        className={cn(
          "group/accordion-trigger flex w-full cursor-pointer items-center gap-4 text-left outline-none",
          className,
        )}
        {...props}
      >
        {children}
      </AccordionPrimitive.Trigger>
    </AccordionPrimitive.Header>
  );
}

function AccordionPanel({ className, ...props }: AccordionPrimitive.Panel.Props) {
  return (
    <AccordionPrimitive.Panel data-slot="accordion-panel" className={cn("overflow-hidden", className)} {...props} />
  );
}

interface AccordionSectionProps {
  title: React.ReactNode;
  badge?: React.ReactNode;
  id?: string;
  defaultOpen?: boolean;
  children: React.ReactNode;
  className?: string;
  panelClassName?: string;
}

/** A single collapsible category card: title row (with optional badge) + chevron + panel. */
function AccordionSection({
  title,
  badge,
  id,
  defaultOpen = false,
  children,
  className,
  panelClassName,
}: AccordionSectionProps) {
  const value = id ?? String(title);
  return (
    <AccordionRoot defaultValue={defaultOpen ? [value] : []} className="flex flex-col">
      <AccordionItem
        value={value}
        id={id}
        className={cn("rounded-card border border-border-default bg-bg-card", className)}
      >
        <AccordionTrigger className="px-6 py-4 transition-colors hover:bg-bg-card-elevated">
          <h3 className="flex-1 text-base font-semibold text-text-primary">{title}</h3>
          {badge}
          <ChevronDown className="h-4 w-4 shrink-0 text-text-muted transition-transform group-data-[panel-open]/accordion-trigger:rotate-180" />
        </AccordionTrigger>
        <AccordionPanel className={cn("border-t border-border-subtle px-6 py-5", panelClassName)}>
          {children}
        </AccordionPanel>
      </AccordionItem>
    </AccordionRoot>
  );
}

export { AccordionRoot as Accordion, AccordionItem, AccordionTrigger, AccordionPanel, AccordionSection };
