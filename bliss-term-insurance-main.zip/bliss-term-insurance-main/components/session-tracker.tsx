"use client";

import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { SESSION_FLUSH_INTERVAL_MS } from "@/config/session-tracking";
import { useFlow } from "@/context/flow-provider";
import { sectionForPath } from "@/lib/session/sections";
import { addDwell, emptyTracker, syncWithCustomer, toPayload, type TrackerState } from "@/lib/session/tracker-state";
import type { CustomerInfo } from "@/types";

/**
 * Invisible per-session logger: watches the saved Control Panel inputs and
 * which presentation section is on screen, and reports a snapshot to
 * /api/session-log. The rules live in lib/session/*; this only wires them
 * to routing, timers, localStorage and the network.
 *
 * Stays out of the advisor's way: renders nothing, keeps its state outside
 * React (no re-renders), sends at most one write per
 * SESSION_FLUSH_INTERVAL_MS and only when something reportable changed,
 * plus one last send when the tab is hidden or the session ends. Failures
 * are logged to the console, never surfaced.
 */

const STORAGE_KEY = "ditto:session-tracking:v1";
const TICK_MS = 1000;

function loadTracker(): TrackerState {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? { ...emptyTracker(), ...(JSON.parse(raw) as Partial<TrackerState>) } : emptyTracker();
  } catch {
    return emptyTracker();
  }
}

function persistTracker(state: TrackerState): void {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Storage full or blocked — tracking continues in memory.
  }
}

/** True only when the server confirmed the write (a redirect to /login counts as failure). */
async function postSnapshot(body: object, keepalive: boolean): Promise<boolean> {
  try {
    const res = await fetch("/api/session-log", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      keepalive,
      redirect: "error",
    });
    if (!res.ok) console.warn(`[session-log] snapshot not saved (HTTP ${res.status})`);
    return res.ok;
  } catch (err) {
    console.warn("[session-log] snapshot not sent:", err);
    return false;
  }
}

function createSessionTracker() {
  let state: TrackerState | null = null;
  let section: string | null = null;
  let timer: ReturnType<typeof setTimeout> | null = null;
  /** Key of the snapshot currently being sent — a closing tab fires both "hidden" and "pagehide", and must not send it twice. */
  let inflightKey: string | null = null;

  const get = (): TrackerState => (state ??= loadTracker());
  const set = (next: TrackerState) => {
    state = next;
    persistTracker(next);
  };
  const unsent = (s: TrackerState) => {
    const payload = toPayload(s);
    if (!payload) return null;
    const key = JSON.stringify(payload);
    return key === s.lastSentKey ? null : { payload, key };
  };

  const schedule = () => {
    if (timer || !unsent(get())) return;
    timer = setTimeout(() => {
      timer = null;
      void flush(false);
    }, SESSION_FLUSH_INTERVAL_MS);
  };

  async function flush(keepalive: boolean): Promise<void> {
    const current = get();
    const pending = unsent(current);
    if (!pending || pending.key === inflightKey) return;
    if (inflightKey && !keepalive) return schedule();

    const seq = current.seq + 1;
    set({ ...current, seq });
    inflightKey = pending.key;
    const ok = await postSnapshot({ ...pending.payload, seq }, keepalive);
    inflightKey = null;
    const latest = get();
    if (ok && latest.sessionId === pending.payload.sessionId) set({ ...latest, lastSentKey: pending.key });
    schedule();
  }

  return {
    setPath(pathname: string | null) {
      section = sectionForPath(pathname);
    },
    syncCustomer(customer: CustomerInfo) {
      const { next, ended } = syncWithCustomer(get(), customer, new Date(), () => crypto.randomUUID());
      if (ended) {
        const final = unsent(ended);
        if (final) void postSnapshot({ ...final.payload, seq: ended.seq + 1 }, true);
      }
      set(next);
      schedule();
    },
    tick() {
      if (!section || document.visibilityState !== "visible") return;
      set(addDwell(get(), section, TICK_MS, new Date()));
      schedule();
    },
    flushNow() {
      void flush(true);
    },
    dispose() {
      if (timer) clearTimeout(timer);
      timer = null;
    },
  };
}

export function SessionTracker() {
  const { customer, hydrated } = useFlow();
  const pathname = usePathname();
  const [tracker] = useState(createSessionTracker);

  useEffect(() => tracker.setPath(pathname), [tracker, pathname]);

  // Only once persisted inputs are restored — so a reload isn't mistaken for Start Over.
  useEffect(() => {
    if (hydrated) tracker.syncCustomer(customer);
  }, [tracker, hydrated, customer]);

  useEffect(() => {
    const id = setInterval(() => tracker.tick(), TICK_MS);
    const onVisibility = () => {
      if (document.visibilityState === "hidden") tracker.flushNow();
    };
    const onPageHide = () => tracker.flushNow();
    document.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("pagehide", onPageHide);
    return () => {
      clearInterval(id);
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("pagehide", onPageHide);
      tracker.dispose();
    };
  }, [tracker]);

  return null;
}
