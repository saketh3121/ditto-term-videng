import type { ReactNode } from "react";
import { Document, Image, Link, Page, Path, StyleSheet, Svg, Text, View } from "@react-pdf/renderer";
import type { Style } from "@react-pdf/types";
import { NpvChart, OutlookChart, OutlookLegend } from "@/components/pdf/charts";
import { DetailIcon, DittoWordmark, InfoIcon, WhatsAppIcon } from "@/components/pdf/graphics";
import { C, registerPdfFonts } from "@/components/pdf/theme";
import pdfSummaryContent from "@/content/pdf-summary.json";
import { formatRupees } from "@/lib/calc/cover";
import { fillTemplate } from "@/lib/pdf/format";
import type { PdfInsurerRow, SummaryModel } from "@/lib/pdf/summary-model";
import type { PdfRiderCardContent, PdfSummaryContent } from "@/types";

/**
 * The customer-facing term plan summary: four A4 pages (595×842pt) in the
 * design's fixed geometry — cover + personal details + expense outlook;
 * NPV curve + suggested cover + insurers; riders + payment flexibility; why
 * now + why Ditto + WhatsApp CTA. Every figure comes from
 * lib/pdf/summary-model.ts; every string from content/pdf-summary.json.
 *
 * Browser-only: loaded via a dynamic import from lib/pdf/generate.tsx, so
 * @react-pdf/renderer never lands in the main bundle.
 *
 * Layout invariant: no element's extent may reach y=842 on any page —
 * react-pdf paginates overflow and emits a blank trailing page.
 */

registerPdfFonts();

const content = (pdfSummaryContent as PdfSummaryContent).pdf;

const MASCOT_NOTEPAD = "/pdf/images/mascot-notepad-crop.png";
const MASCOT_WAVE = "/pdf/images/mascot-wave-crop.png";
const MASCOT_PHONE = "/pdf/images/mascot-phone.png";

const s = StyleSheet.create({
  page: { fontFamily: "Inter", fontSize: 9, color: C.ink, backgroundColor: C.pageBg },
});

const heading20: Style = {
  fontFamily: "Inter",
  fontWeight: 600,
  fontSize: 20,
  letterSpacing: -0.25,
  lineHeight: 1.1,
  color: C.sectionHeading,
};
const sub10: Style = { fontFamily: "Inter", fontWeight: 400, fontSize: 10, lineHeight: 1.45, color: C.body, marginTop: 8 };
const ghost: Style = {
  position: "absolute",
  width: 200,
  textAlign: "right",
  fontFamily: "Inter",
  fontWeight: 300,
  fontSize: 68.6,
  letterSpacing: -0.86,
  lineHeight: 1,
  color: C.ghost,
};
const capsLabel: Style = { fontFamily: "Inter", fontWeight: 600, fontSize: 8, letterSpacing: 1, lineHeight: 1, color: C.muted };
const value10: Style = { fontFamily: "Inter", fontWeight: 500, fontSize: 10, lineHeight: 1, color: C.heading };

// ------------------------------------------------------------------ Page 1 --
// Navy hero 0–216; section 01 (details card) at y 304; section 02 (outlook)
// chart at y 590, legend at y 799.

function CoverHeader({ model }: { model: SummaryModel }) {
  const c = content.cover;
  return (
    <View style={{ height: 216, backgroundColor: C.navy }}>
      <View style={{ position: "absolute", left: 24, top: 24 }}>
        <DittoWordmark width={58} />
      </View>
      <Text
        style={{
          position: "absolute",
          right: 24,
          top: 24,
          width: 220,
          textAlign: "right",
          fontFamily: "Inter",
          fontWeight: 400,
          fontSize: 9,
          letterSpacing: 1.5,
          lineHeight: 1,
          color: C.onNavyLabel,
        }}
      >
        {content.topBarLabel}
      </Text>
      <View style={{ position: "absolute", left: 24, top: 67, width: 417 }}>
        <Text style={{ fontFamily: "Inter", fontWeight: 600, fontSize: 28, letterSpacing: -0.25, lineHeight: 1.1, color: C.white }}>
          {c.headline}
        </Text>
        <Text style={{ fontFamily: "Inter", fontWeight: 400, fontSize: 10, lineHeight: 1.45, color: C.onNavyLabel, marginTop: 8, maxWidth: 313 }}>
          {c.sub}
        </Text>
        {/* Fixed column widths (sum 384 = the gap before the mascot at x 408):
            long names wrap inside their column instead of pushing the date
            into the mascot. */}
        <View style={{ flexDirection: "row", gap: 12, marginTop: 20 }}>
          {(
            [
              [c.preparedForLabel, model.lead.name, 150],
              [c.advisorLabel, model.advisorName, 120],
              [c.issuedLabel, model.discussedOn, 90],
            ] as const
          ).map(([label, value, width]) => (
            <View key={label} style={{ width }}>
              <Text style={{ fontFamily: "Inter", fontWeight: 400, fontSize: 9, lineHeight: 1, color: C.onNavyLabel }}>{label}</Text>
              <Text style={{ fontFamily: "Inter", fontWeight: 500, fontSize: 11, lineHeight: 1.2, color: C.white, marginTop: 8 }}>
                {value}
              </Text>
            </View>
          ))}
        </View>
      </View>
      {/* Pre-cropped so its bottom sits exactly on the band edge — no clipping needed. */}
      <Image src={MASCOT_NOTEPAD} style={{ position: "absolute", left: 408, top: 36, width: 187, height: 180 }} />
    </View>
  );
}

function PersonalDetails({ model }: { model: SummaryModel }) {
  const p = content.personal;
  const l = model.lead;
  // Six detail rows at a 28pt pitch keep the card at its 182pt design height.
  const ROW_Y = [14, 42, 70, 98, 126, 154];
  const DIV_Y = [33, 61, 89, 117, 145];
  return (
    <View style={{ height: 182, backgroundColor: C.detailsCard, borderRadius: 12 }}>
      <View style={{ position: "absolute", left: 2, top: 2, width: 250, height: 178, backgroundColor: C.white, borderRadius: 10 }}>
        <Text style={[capsLabel, { position: "absolute", left: 12, top: 14 }]}>{p.proposerLabel}</Text>
        {/* 16pt fits ~20 characters on one line; longer names drop to 12pt so
            two lines still clear the divider at y 67. The non-breaking space
            keeps "(58)" attached to the surname instead of splitting it. */}
        <Text
          style={{
            position: "absolute",
            left: 12,
            top: 30,
            width: 226,
            fontFamily: "Inter",
            fontWeight: 500,
            fontSize: `${l.name} (${l.age})`.length > 20 ? 12 : 16,
            lineHeight: 1.15,
            color: C.heading,
          }}
        >
          {`${l.name}\u00A0(${l.age})`}
        </Text>
        <View style={{ position: "absolute", left: 12, top: 67, width: 175, height: 1, backgroundColor: C.border }} />
        <Text style={[capsLabel, { position: "absolute", left: 12, top: 88 }]}>{p.residencyLabel}</Text>
        <Text style={[value10, { position: "absolute", left: 12, top: 106 }]}>{l.residency}</Text>
        <Text style={[capsLabel, { position: "absolute", left: 12, top: 132 }]}>{p.tobaccoLabel}</Text>
        <Text style={[value10, { position: "absolute", left: 12, top: 150 }]}>{l.tobacco}</Text>
      </View>
      {DIV_Y.map((y) => (
        <View key={y} style={{ position: "absolute", left: 272, top: y, width: 267, height: 0.7, backgroundColor: C.border }} />
      ))}
      {l.rows.map((row, i) => {
        const y = ROW_Y[i] ?? 0;
        return (
          <View key={row.icon}>
            {/* +1 centers the 10pt glyph on the label's x-height. */}
            <View style={{ position: "absolute", left: 270, top: y + 1 }}>
              <DetailIcon name={row.icon} size={10} />
            </View>
            <Text style={[value10, { position: "absolute", left: 286, top: y, color: C.muted }]}>{row.label}</Text>
            <Text style={[value10, { position: "absolute", left: 339, top: y, width: 200, textAlign: "right" }]}>{row.value}</Text>
          </View>
        );
      })}
    </View>
  );
}

function PageOne({ model }: { model: SummaryModel }) {
  const o = content.outlook;
  const vars = { rate: +(model.inflationRate * 100).toFixed(1), endAge: model.projectionEndAge };
  return (
    <Page size="A4" style={s.page}>
      <CoverHeader model={model} />

      <Text style={[ghost, { right: 20, top: 220 }]}>01</Text>
      <View style={{ position: "absolute", left: 24, top: 239, width: 375 }}>
        <Text style={heading20}>{content.personal.title}</Text>
        <Text style={[sub10, { maxWidth: 358 }]}>{content.personal.sub}</Text>
      </View>
      <View style={{ position: "absolute", left: 20, top: 304, width: 555 }}>
        <PersonalDetails model={model} />
      </View>

      <Text style={[ghost, { right: 20, top: 495 }]}>02</Text>
      <View style={{ position: "absolute", left: 24, top: 507, width: 375 }}>
        <Text style={heading20}>{fillTemplate(o.title, vars)}</Text>
        <Text style={[sub10, { maxWidth: 341 }]}>{fillTemplate(o.sub, vars)}</Text>
      </View>
      <View style={{ position: "absolute", left: 0, top: 590, width: 595 }}>
        <OutlookChart rows={model.outlookRows} yAxisLabel={o.yAxisLabel} />
      </View>
      <View style={{ position: "absolute", left: 0, top: 799, width: 595 }}>
        <OutlookLegend label={o.legendLabel} />
      </View>
    </Page>
  );
}

// ------------------------------------------------------------------ Page 2 --
// Section 03 NPV curve at y 131; navy suggested-cover card at y 367;
// section 04 insurer table below it. Gray band from y 455. The card's
// breakdown/term sub-lines hide when there are no loans or existing cover.

const cardLabel: Style = { fontFamily: "Inter", fontWeight: 600, fontSize: 9.3, letterSpacing: 1.87, lineHeight: 1.2, color: C.onCardLabel };
const bigValue: Style = { fontFamily: "Inter", fontWeight: 700, fontSize: 29.8, letterSpacing: -0.64, lineHeight: 1.19 };
const cardNote: Style = { fontFamily: "Inter", fontWeight: 600, fontSize: 11.2, lineHeight: 1.5, color: C.onCardLabel };

function NavyCoverCard({ model }: { model: SummaryModel }) {
  const c = content.coverSuggested;
  // Non-breaking spaces keep "₹25 L" together when the breakdown wraps.
  const nb = (v: number): string => formatRupees(v).replace(/ /g, " ");
  const breakdown = model.hasBreakdown
    ? [
        `${nb(model.baseCover)} ${c.breakdown.base}`,
        model.loansRounded > 0 ? ` + ${nb(model.loansRounded)} ${c.breakdown.loans}` : "",
        model.existingRounded > 0 ? ` − ${nb(model.existingRounded)} ${c.breakdown.existing}` : "",
      ].join("")
    : "";
  const floorNote = model.floorApplied ? fillTemplate(c.floorNote, { floor: formatRupees(model.baseCover) }) : "";
  const coverNote = [breakdown, floorNote].filter(Boolean).join(" · ");
  const vars = {
    cover: formatRupees(model.suggestedCover),
    term: model.termYears,
    advisor: model.advisorName,
    first: model.advisorFirstName,
  };
  const waHref = `https://wa.me/${model.whatsappNumber}?text=${encodeURIComponent(fillTemplate(c.cta.message, vars))}`;
  return (
    <View style={{ backgroundColor: C.navyCard, borderRadius: 15, overflow: "hidden" }}>
      <View style={{ paddingVertical: 16, paddingHorizontal: 22, flexDirection: "row" }}>
        <View style={{ width: 232 }}>
          <Text style={cardLabel}>{c.suggestedLabel}</Text>
          <Text style={[bigValue, { color: C.white, marginTop: 5.6 }]}>{formatRupees(model.suggestedCover)}</Text>
          {coverNote ? <Text style={[cardNote, { marginTop: 4, width: 231 }]}>{coverNote}</Text> : null}
        </View>
        <View style={{ width: 1, backgroundColor: C.onCardRule, marginLeft: 22, marginRight: 22, marginVertical: -2 }} />
        <View style={{ width: 231 }}>
          <Text style={cardLabel}>{c.termLabel}</Text>
          <View style={{ flexDirection: "row", alignItems: "flex-end" }}>
            <Text style={[bigValue, { color: C.tenureGreen, marginTop: 5.6 }]}>{model.termYears}</Text>
            <Text style={[cardNote, { marginLeft: 4, marginBottom: 4 }]}>{c.termUnit}</Text>
          </View>
          <Text style={[cardNote, { marginTop: 4, width: 231 }]}>{fillTemplate(c.termNote, { age: model.coverEndAge })}</Text>
        </View>
      </View>
      {/* Hairline as its own View — react-pdf mis-colours a lone borderTop inside a coloured container. */}
      <View style={{ height: 0.7, backgroundColor: C.onCardStripRule }} />
      <View
        style={{
          height: 39.3,
          paddingHorizontal: 22,
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          backgroundColor: C.onCardStrip,
        }}
      >
        <View>
          <Text style={{ fontFamily: "Inter", fontWeight: 600, fontSize: 9, lineHeight: 1.2, color: C.white }}>
            {fillTemplate(c.cta.question, vars)}
          </Text>
          <Text style={{ fontFamily: "Inter", fontWeight: 400, fontSize: 7.5, lineHeight: 1.2, color: C.onCardSub, marginTop: 2 }}>
            {fillTemplate(c.cta.sub, vars)}
          </Text>
        </View>
        <Link src={waHref} style={{ textDecoration: "none" }}>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 4,
              backgroundColor: C.claimGreen,
              borderRadius: 6,
              paddingHorizontal: 8,
              paddingVertical: 4,
            }}
          >
            <WhatsAppIcon size={11} />
            <Text style={{ fontFamily: "Inter", fontWeight: 500, fontSize: 9, lineHeight: 1, color: C.white }}>
              {fillTemplate(c.cta.button, vars)}
            </Text>
          </View>
        </Link>
      </View>
    </View>
  );
}

// Column centers within the table's content box (content width 523.3).
const TABLE_COLS = [145.5, 255, 370.5, 476.5] as const;

function InsurerTable({ insurers }: { insurers: PdfInsurerRow[] }) {
  const h = content.coverSuggested.tableHeaders;
  const headCell = (x: number, title: string, subText: string) => (
    <View key={title} style={{ position: "absolute", left: x - 60, top: 0, width: 120, alignItems: "center" }}>
      <Text style={{ fontFamily: "Inter", fontWeight: 500, fontSize: 9.3, lineHeight: 1.2, color: C.heading }}>{title}</Text>
      <Text style={{ fontFamily: "Inter", fontWeight: 500, fontSize: 8.4, lineHeight: 1.2, color: C.tableHeadSub, marginTop: 3.7 }}>
        {subText}
      </Text>
    </View>
  );
  return (
    <View
      style={{
        backgroundColor: C.white,
        borderRadius: 11.2,
        borderWidth: 0.93,
        borderColor: C.tableBorder,
        paddingTop: 14,
        paddingHorizontal: 15.9,
        paddingBottom: 15.9,
      }}
    >
      <View style={{ height: 25.2 }}>
        <Text
          style={{
            position: "absolute",
            left: 0,
            bottom: 0,
            fontFamily: "Inter",
            fontWeight: 500,
            fontSize: 8.4,
            letterSpacing: 0.93,
            lineHeight: 1,
            color: C.tableHeadLabel,
          }}
        >
          {h.insurers}
        </Text>
        {headCell(TABLE_COLS[0], h.claims, h.claimsSub)}
        {headCell(TABLE_COLS[1], h.annualBusiness, h.annualBusinessSub)}
        {headCell(TABLE_COLS[2], h.amount, h.amountSub)}
        {headCell(TABLE_COLS[3], h.complaints, h.complaintsSub)}
      </View>
      <View style={{ height: 0.7, backgroundColor: C.tableRule, marginTop: 9.3 }} />
      <View style={{ paddingTop: 7.5 }}>
        {insurers.map((ins, rowIdx) => {
          const cells = [
            ins.csr.toFixed(1),
            Math.round(ins.annualBusinessCrore).toLocaleString("en-IN"),
            ins.asr.toFixed(1),
            String(Math.round(ins.complaintsPer10k)),
          ];
          return (
            <View key={ins.id}>
              {rowIdx > 0 ? <View style={{ height: 0.7, backgroundColor: C.tableRule, marginVertical: 9.3 }} /> : null}
              <View style={{ height: 15 }}>
                <View style={{ position: "absolute", left: 0, top: 0, flexDirection: "row", alignItems: "center", gap: 5.6 }}>
                  {ins.logo ? <Image src={ins.logo} style={{ width: 15, height: 15, objectFit: "contain" }} /> : null}
                  <Text style={{ fontFamily: "Inter", fontWeight: 500, fontSize: 9.3, lineHeight: 1, color: C.heading }}>{ins.name}</Text>
                </View>
                {cells.map((v, i) => (
                  <Text
                    key={i}
                    style={{
                      position: "absolute",
                      left: (TABLE_COLS[i] ?? 0) - 40,
                      top: 2.8,
                      width: 80,
                      textAlign: "center",
                      fontFamily: "Inter",
                      fontWeight: 600,
                      fontSize: 9.3,
                      lineHeight: 1,
                      color: C.heading,
                    }}
                  >
                    {v}
                  </Text>
                ))}
              </View>
            </View>
          );
        })}
      </View>
    </View>
  );
}

function PageTwo({ model }: { model: SummaryModel }) {
  const n = content.npv;
  const cs = content.coverSuggested;
  return (
    // Page bg is the band colour; the white block covers 0→455 so nothing's
    // extent reaches 842 (which would spawn a blank overflow page).
    <Page size="A4" style={[s.page, { backgroundColor: C.grayBand }]}>
      <View style={{ height: 455, backgroundColor: C.white }} />

      <Text style={[ghost, { right: 20, top: 13 }]}>03</Text>
      <View style={{ position: "absolute", left: 24, top: 24, width: 430 }}>
        <Text style={[heading20, { maxWidth: 424 }]}>{n.title}</Text>
        <Text style={[sub10, { color: C.bodyAlt }]}>{n.sub}</Text>
      </View>
      <View style={{ position: "absolute", left: 24, top: 115, width: 551, height: 1, backgroundColor: C.border }} />
      <View style={{ position: "absolute", left: 0, top: 131, width: 595 }}>
        <NpvChart rows={model.npvRows} peakAge={model.peakAge} peakNpv={model.peakNpv} peakLabel={formatRupees(model.peakNeedRounded)} labels={n} />
      </View>

      {/* Card + section 04 flow together, so the no-breakdown card tightens the stack. */}
      <View style={{ position: "absolute", left: 20, top: 367, width: 555 }}>
        <NavyCoverCard model={model} />
        <View style={{ marginTop: 24 }}>
          <Text style={[ghost, { right: 0, top: -5, color: C.ghostNumeral }]}>04</Text>
          <View style={{ width: 322, paddingTop: 8.5 }}>
            <Text style={[heading20, { fontSize: 18 }]}>{cs.insurersTitle}</Text>
            <Text style={[sub10, { color: C.bodyAlt }]}>{cs.insurersSub}</Text>
          </View>
        </View>
        <View style={{ marginTop: 12 }}>
          <InsurerTable insurers={model.insurers} />
        </View>
        <View style={{ flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 6, marginTop: 16 }}>
          <InfoIcon size={12} color={C.muted} />
          <Text style={{ fontFamily: "Inter", fontWeight: 400, fontSize: 9, lineHeight: 1, color: C.body }}>{cs.footnote}</Text>
        </View>
      </View>
    </Page>
  );
}

// ------------------------------------------------------------------ Page 3 --
// White 0–345 then gray band. Section 05 riders grid at (20, 89), cards 244
// tall; section 06 payments at y 433, cards 126 tall; navy banner at y 751.

const cardTitle: Style = { fontFamily: "Inter", fontWeight: 600, fontSize: 12, lineHeight: 1.1, color: C.heading };
const body10: Style = { fontFamily: "Inter", fontWeight: 400, fontSize: 10, lineHeight: 1.45, color: C.bodyText };

function AgeChip({ text }: { text: string }) {
  return (
    <View style={{ backgroundColor: C.navy, borderRadius: 8, paddingHorizontal: 8, paddingTop: 3.5, paddingBottom: 4 }}>
      <Text style={{ fontFamily: "Inter", fontWeight: 500, fontSize: 8, lineHeight: 1, color: C.white, textAlign: "center" }}>{text}</Text>
    </View>
  );
}

// Event timeline: caption over a diamond marker on a paying→free bar, age
// chips at the ends, callout below. The 0.4 event position is presentational.
function RiderTimeline({ eventText, calloutText }: { eventText: string; calloutText: string }) {
  const t = content.riders.timelineLabels;
  const W = 242.5;
  const ex = W * 0.4;
  const connector: Style = { position: "absolute", width: 0.8, backgroundColor: C.timelineConnector };
  return (
    <View style={{ width: W }}>
      <View style={{ height: 20 }}>
        <Text
          style={{
            position: "absolute",
            left: ex - 85,
            width: 170,
            top: 0,
            textAlign: "center",
            fontFamily: "Inter",
            fontWeight: 400,
            fontSize: 9,
            lineHeight: 1.25,
            color: C.timelineCaption,
          }}
        >
          {eventText}
        </Text>
      </View>
      <View style={{ height: 11 }}>
        <View style={[connector, { left: ex - 0.4, top: 1, height: 10 }]} />
      </View>
      <View style={{ height: 14 }}>
        <View style={{ position: "absolute", left: 0, top: 0, width: W, height: 13.5, borderRadius: 6.75, backgroundColor: C.timelineTrack }} />
        <View style={{ position: "absolute", left: 0, top: 0, width: ex, height: 13.5, borderRadius: 6.75, backgroundColor: C.navy }} />
        <Svg width={17} height={17} style={{ position: "absolute", left: ex - 8.5, top: -1.8 }}>
          <Path d="M8.5 1.8 L15.2 8.5 L8.5 15.2 L1.8 8.5 Z" fill={C.timelineMarker} stroke={C.white} strokeWidth={1.2} />
        </Svg>
      </View>
      <View style={{ marginTop: 5 }}>
        <View style={[connector, { left: ex - 0.4, top: -5, height: 31 }]} />
        <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
          <AgeChip text={t.currentAge} />
          <AgeChip text={t.coverMaturity} />
        </View>
        <View
          style={{
            alignSelf: "center",
            marginTop: 11,
            width: 200,
            backgroundColor: C.calloutBg,
            borderRadius: 8,
            paddingVertical: 8,
            paddingHorizontal: 12,
          }}
        >
          <Text style={{ fontFamily: "Inter", fontWeight: 400, fontSize: 10, lineHeight: 1.4, color: C.calloutText, textAlign: "center" }}>
            {calloutText}
          </Text>
        </View>
      </View>
    </View>
  );
}

function RiderCard({ index, card }: { index: number; card: PdfRiderCardContent }) {
  return (
    <View
      style={{
        flex: 1,
        height: 244,
        backgroundColor: C.white,
        borderWidth: 1,
        borderColor: C.cardBorder,
        borderRadius: 10,
        padding: 14,
        paddingTop: 15,
      }}
    >
      <Text style={body10}>{`0${index + 1}`}</Text>
      {card.recommended ? (
        <Text
          style={{
            position: "absolute",
            right: 14,
            top: 15,
            fontFamily: "Inter",
            fontWeight: 600,
            fontSize: 7.5,
            letterSpacing: 1,
            lineHeight: 1,
            color: C.recommendedText,
            backgroundColor: C.recommendedBg,
            borderRadius: 9,
            paddingHorizontal: 8,
            paddingTop: 3.5,
            paddingBottom: 4,
          }}
        >
          {content.riders.recommendedBadge}
        </Text>
      ) : null}
      <Text style={[cardTitle, { marginTop: 12, fontSize: 13 }]}>{card.title}</Text>
      <Text style={[body10, { marginTop: 5 }]}>{card.body}</Text>
      {/* Absolute so the timeline pins to the design's offset regardless of body wrap. */}
      <View style={{ position: "absolute", left: 14, top: 108, width: 242.5 }}>
        <RiderTimeline eventText={card.eventText} calloutText={card.calloutText} />
      </View>
    </View>
  );
}

function PayBar({ payingLabel, freeLabel, pct, barWidth }: { payingLabel: string; freeLabel?: string; pct: number; barWidth: number }) {
  const seg = (dark: boolean): Style => ({
    height: 11,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: dark ? C.navy : C.payFree,
  });
  const txt = (dark: boolean): Style => ({
    fontFamily: "Inter",
    fontWeight: 700,
    fontSize: 5.5,
    letterSpacing: 0.4,
    lineHeight: 1,
    color: dark ? C.white : C.blue,
    textAlign: "center",
  });
  // Paying segment is proportional but never narrower than its own label.
  const labelFloor = (payingLabel.length * 3.8 + 12) / barWidth;
  const p = Math.min(1, Math.max(labelFloor, pct));
  return (
    <View style={{ flexDirection: "row", height: 11, borderRadius: 5.5, overflow: "hidden", marginTop: 8 }}>
      <View style={[seg(true), { width: `${(p * 100).toFixed(1)}%` }]}>
        <Text style={txt(true)}>{payingLabel}</Text>
      </View>
      {p < 1 ? (
        <View style={[seg(false), { flex: 1 }]}>{freeLabel && p <= 0.6 ? <Text style={txt(false)}>{freeLabel}</Text> : null}</View>
      ) : null}
    </View>
  );
}

function OutlineChip({ text }: { text: string }) {
  return (
    <Text
      style={{
        fontFamily: "Inter",
        fontWeight: 500,
        fontSize: 6.5,
        lineHeight: 1,
        color: C.chipText,
        backgroundColor: C.white,
        borderWidth: 0.9,
        borderColor: C.border,
        borderRadius: 24,
        paddingHorizontal: 4,
        paddingTop: 2,
        paddingBottom: 2.5,
      }}
    >
      {text}
    </Text>
  );
}

function PaymentCard({ question, mode, bar, line, chips }: { question: string; mode: string; bar: ReactNode; line: string; chips?: ReactNode }) {
  return (
    <View style={{ flex: 1, height: 126, backgroundColor: C.white, borderWidth: 1, borderColor: C.cardBorder, borderRadius: 10, padding: 11 }}>
      <Text style={{ fontFamily: "Inter", fontWeight: 600, fontSize: 10.5, lineHeight: 1.3, color: C.heading }}>{question}</Text>
      <Text style={{ fontFamily: "Inter", fontWeight: 600, fontSize: 8, lineHeight: 1.2, color: C.blue, marginTop: 3 }}>{mode}</Text>
      {bar}
      <Text style={{ fontFamily: "Inter", fontWeight: 400, fontSize: 8.5, lineHeight: 1.4, color: C.bodyText, marginTop: 8 }}>{line}</Text>
      {chips ? <View style={{ flexDirection: "row", gap: 3, marginTop: 8 }}>{chips}</View> : null}
    </View>
  );
}

function PageThree({ model }: { model: SummaryModel }) {
  const r = content.riders;
  const p = content.payments;
  const { retirement, limited, totalYears, older, decades } = model.payments;
  // Inner bar width per card: row 555, gap 10, card padding 11 + border 1 a side.
  const cardCount = 1 + (retirement ? 1 : 0) + (limited ? 1 : 0);
  const barWidth = (555 - 10 * (cardCount - 1)) / cardCount - 24;
  return (
    <Page size="A4" style={[s.page, { backgroundColor: C.grayBand }]}>
      <View style={{ height: 345, backgroundColor: C.white }} />

      <Text style={[ghost, { right: 20, top: 10 }]}>05</Text>
      <Text style={[ghost, { right: 20, top: 339, color: C.ghostNumeral }]}>06</Text>

      <View style={{ position: "absolute", left: 24, top: 28, width: 375 }}>
        <Text style={heading20}>{r.title}</Text>
        <Text style={sub10}>{r.sub}</Text>
      </View>
      <View style={{ position: "absolute", left: 20, top: 89, width: 555, flexDirection: "row", gap: 12 }}>
        {r.cards.map((card, i) => (
          <RiderCard key={card.title} index={i} card={card} />
        ))}
      </View>

      <View style={{ position: "absolute", left: 24, top: 360, width: 430 }}>
        <Text style={[heading20, { fontSize: 16 }]}>{p.title}</Text>
        <Text style={sub10}>{p.sub}</Text>
      </View>
      <View style={{ position: "absolute", left: 20, top: 433, width: 555, flexDirection: "row", gap: 10 }}>
        <PaymentCard
          question={p.cards.regular.question}
          mode={p.cards.regular.mode}
          bar={<PayBar payingLabel={p.cards.regular.bar} pct={1} barWidth={barWidth} />}
          line={fillTemplate(p.cards.regular.line, { years: totalYears })}
        />
        {retirement ? (
          <PaymentCard
            question={p.cards.retirement.question}
            mode={fillTemplate(p.cards.retirement.mode, { age: retirement.age })}
            bar={<PayBar payingLabel={fillTemplate(p.cards.retirement.bar, { age: retirement.age })} pct={retirement.pct} barWidth={barWidth} />}
            line={p.cards.retirement.line}
          />
        ) : null}
        {limited ? (
          <PaymentCard
            question={older ? p.cards.limited.questionOlder : fillTemplate(p.cards.limited.questionDecades, { decades })}
            mode={p.cards.limited.mode}
            bar={
              <PayBar
                payingLabel={fillTemplate(p.cards.limited.bar, { n: limited.n })}
                freeLabel={p.cards.limited.freeBar}
                pct={limited.pct}
                barWidth={barWidth}
              />
            }
            line={fillTemplate(p.cards.limited.line, {
              n: limited.n,
              stop: limited.stopAge,
              free: limited.freeYears,
              yearsWord: limited.freeYears === 1 ? "year" : "years",
            })}
            chips={limited.options.map((n) => (
              <OutlineChip key={n} text={fillTemplate(p.cards.limited.chipLabel, { n })} />
            ))}
          />
        ) : null}
      </View>
      <Text style={{ position: "absolute", left: 24, top: 571, fontFamily: "Inter", fontWeight: 400, fontSize: 8.5, lineHeight: 1.3, color: C.muted }}>
        {p.footnote}
      </Text>

      {limited ? (
        <View style={{ position: "absolute", left: 20, top: 595, width: 555 }}>
          <Text style={{ fontFamily: "Inter", fontWeight: 600, fontSize: 12, letterSpacing: -0.15, lineHeight: 1.1, color: C.sectionHeading, marginLeft: 4 }}>
            {p.whyLimited.title}
            <Text style={{ color: C.blue }}>{p.whyLimited.titleAccent}</Text>
          </Text>
          <View style={{ marginTop: 9, gap: 4 }}>
            {p.whyLimited.rows.map((row) => (
              <View
                key={row.label}
                style={{
                  flexDirection: "row",
                  alignItems: "flex-start",
                  backgroundColor: C.calloutBg,
                  borderWidth: 0.7,
                  borderColor: C.calloutBorder,
                  borderRadius: 8,
                  paddingVertical: 8,
                  paddingHorizontal: 12,
                }}
              >
                <Text style={{ width: 190, fontFamily: "Inter", fontWeight: 600, fontSize: 10.5, lineHeight: 1.3, color: C.heading }}>{row.label}</Text>
                <Text style={{ flex: 1, marginLeft: 12, fontFamily: "Inter", fontWeight: 400, fontSize: 8.5, lineHeight: 1.45, color: C.body }}>
                  {fillTemplate(row.body, { years: totalYears })}
                </Text>
              </View>
            ))}
          </View>
        </View>
      ) : null}

      {/* Mascot is pre-cropped so its extent stays inside the banner (react-pdf drops clipped absolute images). */}
      <View style={{ position: "absolute", left: 20, top: 751, width: 555, height: 79, backgroundColor: C.navy }}>
        <Text
          style={{
            position: "absolute",
            left: 16,
            top: 12,
            width: 440,
            fontFamily: "Inter",
            fontWeight: 600,
            fontSize: 15,
            letterSpacing: -0.25,
            lineHeight: 1.25,
            color: C.white,
          }}
        >
          {p.banner.headline}
        </Text>
        <Text style={{ position: "absolute", left: 16, top: 51, width: 420, fontFamily: "Inter", fontWeight: 400, fontSize: 9, lineHeight: 1.45, color: C.onNavyLabel }}>
          {p.banner.body}
        </Text>
        <Image src={MASCOT_WAVE} style={{ position: "absolute", left: 458, top: 3, width: 82, height: 74 }} />
      </View>
    </Page>
  );
}

// ------------------------------------------------------------------ Page 4 --
// Three bands summing to the page: gray 0–354 (Why now), white 354–645 (Why
// Ditto), navy 645–842 (WhatsApp CTA, absolutely positioned — if it flowed,
// content would total exactly 842pt and react-pdf would emit a blank page).

const PAD4 = 24;
const p4Heading: Style = { ...heading20, color: C.heading };
const p4Sub: Style = { fontFamily: "Inter", fontWeight: 400, fontSize: 10, lineHeight: 1.45, color: C.bodyText, marginTop: 8, maxWidth: 382 };
const p4CardTitle: Style = { ...cardTitle, marginTop: 12 };
const p4CardBody: Style = { ...body10, marginTop: 5 };

function PageFour({ model }: { model: SummaryModel }) {
  const wn = content.whyNow;
  const wd = content.whyDitto;
  const wa = content.whatsapp;
  return (
    // Navy page bg so the 1px strip below the navy band reads as navy, not a white seam.
    <Page size="A4" style={[s.page, { backgroundColor: C.navy }]}>
      <View style={{ height: 354, backgroundColor: C.grayBand, paddingHorizontal: PAD4 }}>
        <Text style={[ghost, { right: 20, top: 10, color: C.ghostNumeral }]}>07</Text>
        <View style={{ marginTop: 28 }}>
          <Text style={p4Heading}>{wn.title}</Text>
          <Text style={p4Sub}>{wn.sub}</Text>
        </View>
        <View style={{ height: 1, backgroundColor: C.border, marginTop: 23 }} />
        <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between", rowGap: 24, marginTop: 20 }}>
          {wn.cards.map((card, i) => (
            <View key={card.title} style={{ width: 262 }}>
              <Text style={[body10, { color: C.blue }]}>{`0${i + 1}`}</Text>
              <Text style={p4CardTitle}>{card.title}</Text>
              <Text style={p4CardBody}>{card.body}</Text>
            </View>
          ))}
        </View>
      </View>

      <View style={{ height: 291, backgroundColor: C.white, paddingHorizontal: PAD4, paddingTop: 24 }}>
        <Text style={p4Heading}>{wd.title}</Text>
        <Text style={p4Sub}>{wd.sub}</Text>
        <View style={{ height: 1, backgroundColor: C.border, marginTop: 18 }} />
        <View style={{ flexDirection: "row", gap: 36, marginTop: 20 }}>
          {wd.cards.map((card) => (
            <View key={card.title} style={{ width: 155 }}>
              <Image src={card.icon} style={{ width: 42, height: 48, objectFit: "contain" }} />
              <Text style={p4CardTitle}>{card.title}</Text>
              <Text style={p4CardBody}>
                {card.body}
                {card.cta ? (
                  // The Link must restate font metrics — it doesn't inherit them,
                  // and a bare Link inside Text inflates that line's height.
                  <>
                    {" "}
                    {card.cta.before}
                    <Link
                      src={card.cta.href}
                      style={{ fontFamily: "Inter", fontWeight: 400, fontSize: 10, lineHeight: 1.45, color: C.blue, textDecoration: "underline" }}
                    >
                      {card.cta.link}
                    </Link>
                    {card.cta.after}
                  </>
                ) : null}
              </Text>
            </View>
          ))}
        </View>
      </View>

      <View style={{ position: "absolute", top: 645, left: 0, right: 0, height: 196, backgroundColor: C.navy, paddingHorizontal: PAD4, paddingTop: 24 }}>
        <Text style={{ fontFamily: "Inter", fontWeight: 400, fontSize: 9, letterSpacing: 1.5, color: C.onNavyLabel }}>{wa.eyebrow}</Text>
        <Text style={{ fontFamily: "Inter", fontWeight: 600, fontSize: 20, letterSpacing: -0.25, lineHeight: 1.1, color: C.white, marginTop: 14 }}>
          {fillTemplate(wa.headline, { advisor: model.advisorFirstName })}
        </Text>
        <Link src={`https://wa.me/${model.whatsappNumber}`} style={{ textDecoration: "none", marginTop: 12 }}>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              alignSelf: "flex-start",
              backgroundColor: C.claimGreen,
              borderRadius: 6,
              paddingHorizontal: 7,
              paddingVertical: 3.5,
              gap: 4,
            }}
          >
            <WhatsAppIcon size={14} />
            <Text style={{ fontFamily: "Inter", fontWeight: 500, fontSize: 12, color: C.white }}>{wa.cta}</Text>
          </View>
        </Link>
        <View style={{ height: 1, backgroundColor: C.onNavyRule, marginTop: 17 }} />
        <View style={{ flexDirection: "row", alignItems: "flex-start", gap: 6, marginTop: 18 }}>
          <InfoIcon size={12} color={C.onNavyLabel} />
          <Text style={{ fontFamily: "Inter", fontWeight: 400, fontSize: 9, color: C.onNavyLabel, lineHeight: 1.55, maxWidth: 429 }}>
            {content.disclaimer}
          </Text>
        </View>
      </View>

      {/* Page-level absolute child: react-pdf drops absolute images clipped inside
          a fixed-height View, and one spilling past y=842 loops pagination until
          OOM — so height 144 (bottom at 841), not the design's 147. */}
      <Image src={MASCOT_PHONE} style={{ position: "absolute", left: 464, top: 697, width: 147, height: 144 }} />
    </Page>
  );
}

export function SummaryDocument({ model }: { model: SummaryModel }) {
  return (
    <Document title={`Ditto Term Plan Summary — ${model.lead.name}`} author="Ditto Insurance" creator="Ditto Advisory">
      <PageOne model={model} />
      <PageTwo model={model} />
      <PageThree model={model} />
      <PageFour model={model} />
    </Document>
  );
}
