import { Line, Path, Svg, Text, Text as SvgText, View } from "@react-pdf/renderer";
import type { Style } from "@react-pdf/types";
import { C } from "@/components/pdf/theme";
import type { NpvCurveRow } from "@/lib/calc/expense-projection";
import { axisINR } from "@/lib/pdf/format";

/**
 * Chart renderers for the customer PDF, drawn with react-pdf SVG primitives.
 * Geometry is the design's (595-wide, absolutely positioned by the page).
 *
 * The outlook is a single inflation-only series — Basic cover has no
 * life-stage milestones, so the source design's stacked milestone segments,
 * drop-lines and captions are gone. The NPV bell curve is unchanged.
 */

// Round a raw step up to a pleasant 1/2/2.5/4/5/8/10 x 10^k value.
function niceStep(raw: number): number {
  if (!(raw > 0)) return 1;
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const norm = raw / mag;
  const step = [1, 2, 2.5, 4, 5, 8, 10].find((s) => s >= norm) ?? 10;
  return step * mag;
}

function roundedTopColumn(x: number, y: number, w: number, h: number, r: number): string {
  const rr = Math.min(r, w / 2, h);
  return [
    `M${x} ${y + h}`,
    `L${x} ${y + rr}`,
    `Q${x} ${y} ${x + rr} ${y}`,
    `L${x + w - rr} ${y}`,
    `Q${x + w} ${y} ${x + w} ${y + rr}`,
    `L${x + w} ${y + h}`,
    "Z",
  ].join(" ");
}

const capsLabel = (fill: string): Style =>
  ({ fontFamily: "Inter", fontWeight: 600, fontSize: 8, letterSpacing: 1, fill }) as Style;

const axisTitle: Style = {
  position: "absolute",
  width: 90,
  textAlign: "center",
  fontFamily: "Inter",
  fontWeight: 600,
  fontSize: 8,
  letterSpacing: 1,
  lineHeight: 1.25,
  color: C.muted,
  opacity: 0.4,
  transform: "rotate(-90deg)",
};

// ---------------------------------------------------------------- Outlook ---
// Plot x 61→556, baseline at local y 181, 32pt per axis step, 18pt bars.

const OUTLOOK = { width: 595, height: 200, plotL: 61, plotR: 556, baseline: 181, stepPitch: 32, barW: 18 };

export function OutlookChart({ rows, yAxisLabel }: { rows: { age: number; annual: number }[]; yAxisLabel: string }) {
  const { width, height, plotL, plotR, baseline, stepPitch, barW } = OUTLOOK;
  const maxTotal = Math.max(1, ...rows.map((r) => r.annual));
  const step = niceStep(maxTotal / 4);
  const nSteps = Math.max(4, Math.ceil(maxTotal / step));
  const ticks = Array.from({ length: nSteps + 1 }, (_, i) => i * step);
  const xFor = (i: number): number => plotL + 12 + ((plotR - plotL - 12 - barW) / Math.max(1, rows.length - 1)) * i;
  const yFor = (v: number): number => baseline - (v / step) * stepPitch;

  return (
    <View style={{ width, height, position: "relative" }}>
      <Text style={[axisTitle, { left: -24, top: 110 }]}>{yAxisLabel}</Text>
      <Svg width={width} height={height}>
        {ticks.map((v) => (
          <Line
            key={`g${v}`}
            x1={plotL}
            y1={yFor(v)}
            x2={plotR}
            y2={yFor(v)}
            stroke={C.gridline}
            strokeWidth={v === 0 ? 0.8 : 0.6}
            {...(v === 0 ? {} : { strokeDasharray: "2 2" })}
          />
        ))}
        {ticks.map((v) => (
          <SvgText key={`t${v}`} x={44} y={yFor(v) + 2.8} textAnchor="middle" style={capsLabel(C.muted)}>
            {axisINR(v)}
          </SvgText>
        ))}
        {rows.map((r, i) => {
          const x = xFor(i);
          const h = Math.max(0.5, (r.annual / step) * stepPitch);
          return (
            <Path key={`bar${r.age}`} d={roundedTopColumn(x, baseline - h, barW, h, 4)} fill={C.outlookBar} />
          );
        })}
        {rows.map((r, i) => (
          <SvgText
            key={`age${r.age}`}
            x={xFor(i) + barW / 2}
            y={baseline + 14.5}
            textAnchor="middle"
            style={capsLabel(C.muted)}
          >
            {String(r.age)}
          </SvgText>
        ))}
      </Svg>
    </View>
  );
}

export function OutlookLegend({ label }: { label: string }) {
  return (
    <View style={{ flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 6 }}>
      <View style={{ width: 8, height: 8, borderRadius: 2, backgroundColor: C.outlookBar }} />
      <Text style={{ fontFamily: "Inter", fontWeight: 400, fontSize: 10, lineHeight: 1, color: C.body }}>{label}</Text>
    </View>
  );
}

// -------------------------------------------------------------- NPV curve ---
// NPV(D) — the cover the family would need if a claim happened at age D.
// Blue curve, dashed crosshair + dot at the peak with a rupee annotation;
// the peak's age tick and CLAIM AGE caption render in green.

const NPV = { width: 595, height: 200, plotL: 61, plotR: 556, plotTop: 14, baseline: 155 };

export interface NpvChartProps {
  rows: NpvCurveRow[];
  peakAge: number | null;
  peakNpv: number;
  peakLabel: string;
  labels: { yAxisLabel: string; claimAgeLabel: string };
}

export function NpvChart({ rows, peakAge, peakNpv, peakLabel, labels }: NpvChartProps) {
  const { width, height, plotL, plotR, plotTop, baseline } = NPV;
  const first = rows[0];
  const lastRow = rows[rows.length - 1];
  if (!first || !lastRow || rows.length < 2 || peakNpv <= 0 || peakAge === null) {
    return <View style={{ width, height }} />;
  }

  const a0 = first.age;
  const aN = lastRow.age;
  const step = niceStep(peakNpv / 4);
  const nSteps = Math.max(3, Math.ceil(peakNpv / step));
  const ticks = Array.from({ length: nSteps + 1 }, (_, i) => i * step);
  const stepPitch = (baseline - plotTop) / nSteps;
  const xFor = (age: number): number => plotL + ((age - a0) / Math.max(1, aN - a0)) * (plotR - plotL);
  const yFor = (v: number): number => baseline - (v / step) * stepPitch;

  // Smooth path: quadratic segments aimed at the midpoints between points.
  const pts = rows.map((r) => [xFor(r.age), yFor(r.npv)] as const);
  const d = pts
    .map(([x, y], i) => {
      if (i === 0) return `M${x.toFixed(1)} ${y.toFixed(1)}`;
      const next = pts[i + 1];
      if (!next) return `L${x.toFixed(1)} ${y.toFixed(1)}`;
      return `Q${x.toFixed(1)} ${y.toFixed(1)} ${((x + next[0]) / 2).toFixed(1)} ${((y + next[1]) / 2).toFixed(1)}`;
    })
    .join(" ");

  // Age ticks every 5 years plus the final age; ticks colliding with the
  // green peak tick are dropped so the emphasis stays legible.
  const peakX = xFor(peakAge);
  const peakY = yFor(peakNpv);
  const ageTicks: number[] = [];
  for (let a = a0; a <= aN; a += 5) ageTicks.push(a);
  if (ageTicks[ageTicks.length - 1] !== aN) ageTicks.push(aN);
  const shownTicks = ageTicks.filter((a) => a === peakAge || Math.abs(xFor(a) - peakX) > 16);
  if (!shownTicks.includes(peakAge)) shownTicks.push(peakAge);
  const labelLeft = peakX > plotR - 90;

  return (
    <View style={{ width, height, position: "relative" }}>
      <Text style={[axisTitle, { left: -22, top: 68 }]}>{labels.yAxisLabel}</Text>
      <Svg width={width} height={height}>
        {ticks.map((v) => (
          <Line
            key={`g${v}`}
            x1={plotL}
            y1={yFor(v)}
            x2={plotR}
            y2={yFor(v)}
            stroke={C.gridline}
            strokeWidth={v === 0 ? 0.8 : 0.6}
            {...(v === 0 ? {} : { strokeDasharray: "2 2" })}
          />
        ))}
        {ticks.map((v) => (
          <SvgText key={`t${v}`} x={44} y={yFor(v) + 2.8} textAnchor="middle" style={capsLabel(C.muted)}>
            {axisINR(v)}
          </SvgText>
        ))}
        <Line x1={peakX} y1={baseline} x2={peakX} y2={peakY} stroke={C.blue} strokeWidth={0.8} strokeDasharray="4 4" opacity={0.7} />
        <Line x1={plotL} y1={peakY} x2={peakX} y2={peakY} stroke={C.blue} strokeWidth={0.8} strokeDasharray="4 4" opacity={0.7} />
        <Path d={d} stroke={C.blue} strokeWidth={1.8} fill="none" />
        <Path
          d={`M${peakX - 4.5} ${peakY} a4.5 4.5 0 1 0 9 0 a4.5 4.5 0 1 0 -9 0`}
          fill={C.blue}
          stroke={C.white}
          strokeWidth={1.8}
        />
        {shownTicks.map((a) => (
          <SvgText
            key={`a${a}`}
            x={xFor(a)}
            y={baseline + 14}
            textAnchor="middle"
            style={capsLabel(a === peakAge ? C.claimGreen : C.muted)}
          >
            {String(a)}
          </SvgText>
        ))}
      </Svg>
      <Text
        style={{
          position: "absolute",
          left: labelLeft ? peakX - 100 : peakX + 10,
          top: peakY - 16,
          width: 90,
          textAlign: labelLeft ? "right" : "left",
          fontFamily: "Inter",
          fontWeight: 700,
          fontSize: 10,
          color: C.heading,
        }}
      >
        {peakLabel}
      </Text>
      <Text
        style={{
          position: "absolute",
          left: peakX - 60,
          top: baseline + 20,
          width: 120,
          textAlign: "center",
          fontFamily: "Inter",
          fontWeight: 600,
          fontSize: 8,
          letterSpacing: 1,
          lineHeight: 1.2,
          color: C.claimGreen,
        }}
      >
        {labels.claimAgeLabel}
      </Text>
    </View>
  );
}
