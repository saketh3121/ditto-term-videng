import { Font } from "@react-pdf/renderer";

/**
 * Fonts + palette for the customer summary PDF.
 *
 * Colour exception to CLAUDE.md's "tokens only" rule: @react-pdf/renderer
 * has its own RN-style styling engine with no access to app/globals.css
 * variables, so the PDF can't consume the app's tokens. Instead every PDF
 * colour lives here, once, as an exact hex sampled from the design — the
 * document components reference `C.*`, never a literal.
 *
 * Fonts are self-hosted under public/pdf/fonts/ (no CDN dependency on a
 * live call) and fetched by URL when a PDF is generated.
 */

export const PDF_FONT_BASE = "/pdf/fonts";

let registered = false;
export function registerPdfFonts(): void {
  if (registered) return;
  registered = true;
  Font.register({
    family: "Inter",
    fonts: [300, 400, 500, 600, 700].map((w) => ({ src: `${PDF_FONT_BASE}/Inter-${w}.ttf`, fontWeight: w })),
  });
  // Word-level wrapping only — hyphenated breaks look wrong in a polished doc.
  Font.registerHyphenationCallback((word) => [word]);
}

export const C = {
  // Core
  navy: "#09132D",
  navyCard: "#072032",
  ink: "#151B28",
  heading: "#09132D",
  sectionHeading: "#0A111E",
  body: "#495770",
  bodyAlt: "#496075",
  bodyText: "#84888E",
  muted: "#7B879C",
  faint: "#A4ABB7",
  border: "#E8EAED",
  ghost: "#E8E8E8",
  ghostNumeral: "#E3E3E3",
  white: "#FFFFFF",
  pageBg: "#FFFFFF",
  grayBand: "#FAFAFA",
  detailsCard: "#F5F5F5",
  chipText: "#65728A",
  blue: "#006DEA",
  claimGreen: "#04B267",
  sky: "#1FA1FF",
  wordmark: "#E4EAEF",
  onNavyLabel: "#9FB3D5",
  onNavyRule: "#1C2740",
  tenureGreen: "#6EE2A6",

  // Navy cover card overlays
  onCardLabel: "rgba(255,255,255,0.55)",
  onCardRule: "rgba(255,255,255,0.12)",
  onCardStripRule: "rgba(255,255,255,0.14)",
  onCardStrip: "rgba(255,255,255,0.06)",
  onCardSub: "rgba(255,255,255,0.6)",

  // Insurer table
  tableBorder: "#E6EBED",
  tableRule: "#EBEEF0",
  tableHeadSub: "#7C93A6",
  tableHeadLabel: "#5D768B",

  // Charts
  gridline: "#EFF1F4",
  outlookBar: "#72C3BB",

  // Riders + payments
  cardBorder: "#EDEEF1",
  timelineCaption: "#6B7686",
  timelineConnector: "#D7DBE0",
  timelineTrack: "#DCEAFB",
  timelineMarker: "#E44C63",
  calloutBg: "#EFF5FD",
  calloutText: "#333F4E",
  calloutBorder: "#E2E9F4",
  recommendedText: "#34A163",
  recommendedBg: "#DEF2E6",
  payFree: "#EAF3FE",
} as const;
