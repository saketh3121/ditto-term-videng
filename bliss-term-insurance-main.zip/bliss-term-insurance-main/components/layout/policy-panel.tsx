"use client";

import { useEffect, useMemo, useState } from "react";
import { Check, Search } from "lucide-react";
import { PanelOverlay } from "./panel-overlay";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Segmented } from "@/components/ui/segmented";
import { cn } from "@/lib/utils";
import { useFlow } from "@/context/flow-provider";
import { policiesByInsurer } from "@/lib/policies";
import chromeContent from "@/content/chrome.json";
import type { ChromeContent, Citizenship } from "@/types";

const P = (chromeContent as ChromeContent).policyPanel;
const C = (chromeContent as ChromeContent).controlPanel;

/**
 * Policy multi-select, grouped by insurer, plus the Resident/NRI toggle —
 * selection is tracked independently per residency (see FlowProvider), so
 * switching residency here swaps to that residency's own manual picks.
 * Edits a temp set; Apply commits.
 */
export function PolicyPanel({ onClose }: { onClose: () => void }) {
  const { residency, setCustomer, manualSelectedPolicies, setManualSelectedPolicies } = useFlow();
  const [temp, setTemp] = useState<string[]>(manualSelectedPolicies);
  const [query, setQuery] = useState("");

  // Re-seed the draft whenever residency changes while the panel is open —
  // each residency tracks its own selection independently. Deliberately
  // keyed on residency only, not manualSelectedPolicies, so this doesn't
  // clobber in-progress edits on every keystroke.
  useEffect(() => {
    setTemp(manualSelectedPolicies);
  }, [residency]);

  const groups = useMemo(() => {
    const q = query.trim().toLowerCase();
    return policiesByInsurer()
      .map((g) => ({
        ...g,
        policies: g.policies.filter(
          (p) =>
            !q ||
            p.name.toLowerCase().includes(q) ||
            g.insurerName.toLowerCase().includes(q),
        ),
      }))
      .filter((g) => g.policies.length > 0);
  }, [query]);

  const toggle = (id: string) =>
    setTemp((t) => (t.includes(id) ? t.filter((x) => x !== id) : [...t, id]));

  const apply = () => {
    setManualSelectedPolicies(temp);
    onClose();
  };

  return (
    <PanelOverlay
      title={P.title}
      subtitle={P.subtitle}
      onClose={onClose}
      footer={
        <Button className="w-full" onClick={apply} disabled={temp.length < 1}>
          {P.applyLabel}
        </Button>
      }
    >
      {/* Residency — same underlying field as the Control Panel's toggle */}
      <div className="mb-4 flex flex-col gap-1.5">
        <span className="text-[14px] font-semibold uppercase tracking-[0.08em] text-text-muted">
          {C.citizenshipLabel}
        </span>
        <Segmented
          value={residency === "nri" ? "nri" : "indian"}
          onChange={(v) => setCustomer({ citizenship: v as Citizenship })}
          options={[
            { value: "indian", label: C.citizenshipIndian },
            { value: "nri", label: C.citizenshipNri },
          ]}
        />
      </div>

      {/* Search */}
      <div className="relative mb-3">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-text-muted" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={P.searchPlaceholder}
          className="pl-9"
        />
      </div>

      {/* Selection meta */}
      <div className="mb-2 flex items-center justify-between">
        <span className="text-xs text-text-muted">
          {P.selectedTemplate.replace("{count}", String(temp.length))}
        </span>
        {temp.length > 0 && (
          <button
            type="button"
            onClick={() => setTemp([])}
            className="cursor-pointer text-[14px] font-semibold text-accent-blue hover:underline"
          >
            {P.clearLabel}
          </button>
        )}
      </div>

      {/* Grouped list */}
      {groups.length > 0 ? (
        <div className="flex flex-col gap-4">
          {groups.map((group) => (
            <div key={group.insurerId} className="flex flex-col gap-1">
              <p className="px-1 text-[13px] font-bold uppercase tracking-[0.12em] text-text-muted">
                {group.insurerName}
              </p>
              {group.policies.map((policy) => {
                const checked = temp.includes(policy.id);
                return (
                  <button
                    key={policy.id}
                    type="button"
                    onClick={() => toggle(policy.id)}
                    className={cn(
                      "flex w-full items-center gap-3 rounded-md px-2.5 py-2 text-left text-sm transition-colors cursor-pointer",
                      checked
                        ? "bg-accent-blue-soft text-text-primary"
                        : "text-text-secondary hover:bg-hover-surface",
                    )}
                  >
                    <span
                      className={cn(
                        "flex h-4 w-4 shrink-0 items-center justify-center rounded-[5px] border transition-colors",
                        checked
                          ? "border-accent-blue bg-accent-blue text-white"
                          : "border-border-strong",
                      )}
                    >
                      {checked && <Check className="h-3 w-3" strokeWidth={3} />}
                    </span>
                    <span className="truncate">{policy.name}</span>
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      ) : (
        <p className="px-1 py-6 text-center text-sm text-text-muted">
          {P.emptyLabel}
        </p>
      )}
    </PanelOverlay>
  );
}
