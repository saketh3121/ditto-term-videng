"use client";

import { X } from "lucide-react";
import chromeContent from "@/content/chrome.json";
import type { ChromeContent } from "@/types";

const CHROME = chromeContent as ChromeContent;

/**
 * Shared right-edge overlay for the Control / Policy panels: a dimmed backdrop
 * plus a slide-in panel with a header (title + subtitle + close), a scrollable
 * body, and an optional pinned footer.
 */
export function PanelOverlay({
  title,
  subtitle,
  onClose,
  footer,
  children,
}: {
  title: string;
  subtitle?: string;
  onClose: () => void;
  footer?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <>
      <div
        aria-hidden
        onClick={onClose}
        className="animate-fade-in fixed inset-0 z-50 bg-black/40"
      />
      <div
        role="dialog"
        aria-label={title}
        className="animate-slide-in-right fixed right-0 top-0 z-50 flex h-full w-[440px] max-w-[92vw] flex-col border-l border-border-default bg-bg-card"
      >
        <div className="flex items-start justify-between gap-3 border-b border-border-default px-5 py-4">
          <div className="min-w-0">
            <h3 className="text-sm font-semibold text-text-primary">{title}</h3>
            {subtitle && (
              <p className="mt-0.5 text-xs leading-[1.45] text-text-muted">{subtitle}</p>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={CHROME.closeLabel}
            title={CHROME.closeLabel}
            className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-md text-text-muted transition-colors cursor-pointer hover:bg-hover-surface hover:text-text-primary"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">{children}</div>

        {footer && (
          <div className="border-t border-border-default p-4">{footer}</div>
        )}
      </div>
    </>
  );
}
