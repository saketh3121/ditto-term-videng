"use client";

import { useEffect, useMemo, useState } from "react";
import { useSession } from "next-auth/react";
import { PanelOverlay } from "./panel-overlay";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { loadSummaryInsurers } from "@/app/actions/summary-insurers";
import { useFlow } from "@/context/flow-provider";
import { computeBasicCoverSummary, formatRupees } from "@/lib/calc/cover";
import { downloadBlob, generateSummaryPdfBlob } from "@/lib/pdf/generate";
import { buildSummaryModel, missingSummaryFields, type MissingSummaryField } from "@/lib/pdf/summary-model";
import { insurerIdsForPolicies } from "@/lib/policies";
import chromeContent from "@/content/chrome.json";
import pdfSummaryContent from "@/content/pdf-summary.json";
import type { ChromeContent, Insurer, PdfSummaryContent } from "@/types";

const { panel: P, pdf: PDF } = pdfSummaryContent as PdfSummaryContent;
const LABELS = (chromeContent as ChromeContent).controlPanel;

const MISSING_LABEL: Record<MissingSummaryField, string> = {
  name: P.missingName,
  dob: P.missingDob,
  monthlyExpenses: P.missingMonthlyExpenses,
  insurers: P.missingInsurers,
  advisorName: P.missingAdvisorName,
};

const todayLabel = () => new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });

const labelClass = "text-[14px] font-semibold uppercase tracking-[0.08em] text-text-muted";

function PreviewRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between gap-3 py-1.5">
      <dt className="text-sm text-text-muted">{label}</dt>
      <dd className="text-right text-sm font-medium text-text-primary">{value}</dd>
    </div>
  );
}

/**
 * Admin-only (pilot) customer summary: builds the take-home PDF from this
 * call's live state — Control Panel inputs, Policy Panel selection, and the
 * Basic cover figures — so nothing is typed twice. Only the advisor name and
 * date are editable here; everything about the customer is edited in the
 * Control Panel, the single source for those inputs.
 */
export function SummaryPanel({ onClose }: { onClose: () => void }) {
  const { customer, age, selectedPolicies, setActivePanel } = useFlow();
  const { data: session } = useSession();

  const [advisorNameOverride, setAdvisorNameOverride] = useState<string | null>(null);
  const advisorName = advisorNameOverride ?? session?.user?.name ?? "";
  const [discussedOn, setDiscussedOn] = useState(todayLabel);

  const insurerIds = useMemo(() => insurerIdsForPolicies(selectedPolicies), [selectedPolicies]);
  const insurerKey = insurerIds.join(",");
  const [insurers, setInsurers] = useState<Insurer[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setInsurers(null);
    loadSummaryInsurers(insurerKey ? insurerKey.split(",") : [])
      .then((list) => !cancelled && setInsurers(list))
      .catch((err: unknown) => {
        console.error("[summary] failed to load insurers:", err);
        if (!cancelled) setError(P.errorMessage);
      });
    return () => {
      cancelled = true;
    };
  }, [insurerKey]);

  const cover = useMemo(
    () =>
      age === null
        ? null
        : computeBasicCoverSummary({
            age,
            monthlyExpense: Number(customer.monthlyExpenses) || 0,
            targetAge: Number(customer.preferredCoverAge) || undefined,
            uninsuredLoans: Number(customer.uninsuredLoans) || 0,
            existingCover: Number(customer.existingCoverAmount) || 0,
          }),
    [age, customer],
  );

  const missing = missingSummaryFields({ customer, age, insurerCount: insurerIds.length, advisorName });
  const canDownload = missing.length === 0 && insurers !== null && !busy;

  const download = async () => {
    if (!canDownload || age === null || insurers === null) return;
    setBusy(true);
    setError(null);
    try {
      const model = buildSummaryModel({ customer, age, insurers, advisorName, discussedOn, content: PDF, labels: LABELS });
      const blob = await generateSummaryPdfBlob(model);
      downloadBlob(blob, `${P.fileNamePrefix} - ${model.lead.name}.pdf`);
    } catch (err) {
      console.error("[summary] PDF generation failed:", err);
      setError(P.errorMessage);
    } finally {
      setBusy(false);
    }
  };

  return (
    <PanelOverlay
      title={P.title}
      subtitle={P.subtitle}
      onClose={onClose}
      footer={
        <div className="flex flex-col gap-2">
          <Button className="w-full" onClick={download} disabled={!canDownload}>
            {busy ? P.preparingLabel : P.downloadLabel}
          </Button>
          <p className="text-center text-xs text-text-muted">{P.footnote}</p>
        </div>
      }
    >
      <div className="flex flex-col gap-5">
        <span className="self-start rounded-full bg-accent-blue-soft px-2.5 py-1 text-[12px] font-semibold uppercase tracking-[0.08em] text-accent-blue">
          {P.pilotBadge}
        </span>

        <section className="flex flex-col gap-2">
          <h4 className={labelClass}>{P.previewHeading}</h4>
          <dl className="divide-y divide-border-subtle rounded-md border border-border-default bg-bg-card-elevated px-3">
            <PreviewRow label={P.customerLabel} value={customer.name.trim() || "—"} />
            <PreviewRow label={P.ageLabel} value={age === null ? "—" : String(age)} />
            <PreviewRow
              label={P.coverLabel}
              value={cover && Number(customer.monthlyExpenses) > 0 ? formatRupees(cover.purchaseNow) : "—"}
            />
            <PreviewRow label={P.termLabel} value={cover ? `${cover.termYears} ${PDF.coverSuggested.termUnit}` : "—"} />
            <PreviewRow
              label={P.insurersLabel}
              value={insurers === null ? "…" : insurers.map((i) => i.name).join(", ") || "—"}
            />
          </dl>
          <p className="text-xs text-text-muted">{P.editHint}</p>
        </section>

        <div className="flex flex-col gap-1.5">
          <label htmlFor="sp-advisor" className={labelClass}>
            {P.advisorNameLabel}
          </label>
          <Input id="sp-advisor" value={advisorName} onChange={(e) => setAdvisorNameOverride(e.target.value)} />
        </div>

        <div className="flex flex-col gap-1.5">
          <label htmlFor="sp-date" className={labelClass}>
            {P.discussedOnLabel}
          </label>
          <Input id="sp-date" value={discussedOn} onChange={(e) => setDiscussedOn(e.target.value)} />
        </div>

        {missing.length > 0 && (
          <div className="flex flex-col gap-2 rounded-md border border-[var(--color-warning-border)] bg-[var(--color-warning-soft)] px-3 py-3">
            <p className="text-sm font-medium text-text-primary">{P.missingHeading}</p>
            <ul className="list-disc pl-5 text-sm text-text-secondary">
              {missing.map((m) => (
                <li key={m}>{MISSING_LABEL[m]}</li>
              ))}
            </ul>
            <div className="flex flex-wrap gap-4">
              {missing.some((m) => m !== "insurers" && m !== "advisorName") && (
                <Button variant="ghost" className="px-0" onClick={() => setActivePanel("control")}>
                  {P.editInControlPanelLabel}
                </Button>
              )}
              {missing.includes("insurers") && (
                <Button variant="ghost" className="px-0" onClick={() => setActivePanel("policy")}>
                  {P.editInPolicyPanelLabel}
                </Button>
              )}
            </div>
          </div>
        )}

        {error && <p className="text-sm text-warning">{error}</p>}
      </div>
    </PanelOverlay>
  );
}
