"use client";

import { useState } from "react";
import { PanelOverlay } from "./panel-overlay";
import { IndianWordsHint } from "@/components/ui/indian-words-hint";
import { Input } from "@/components/ui/input";
import { Segmented } from "@/components/ui/segmented";
import { Button } from "@/components/ui/button";
import { useFlow } from "@/context/flow-provider";
import { ageFromDob } from "@/lib/calc/age";
import { isValidChatLink } from "@/lib/chat-id";
import { TENURE_WARNING_AGE } from "@/config/milestone-assumptions";
import chromeContent from "@/content/chrome.json";
import type { ChromeContent, Citizenship, CustomerInfo, EducationLevel, Employment, Gender } from "@/types";

const C = (chromeContent as ChromeContent).controlPanel;

const digitsOnly = (v: string) => v.replace(/[^0-9]/g, "");

function Field({
  label,
  htmlFor,
  hint,
  warning,
  children,
}: {
  label: string;
  htmlFor?: string;
  hint?: React.ReactNode;
  /** Caution text shown below the field — not a hard validation error, just a heads-up. */
  warning?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-center justify-between gap-2">
        <label
          htmlFor={htmlFor}
          className="text-[14px] font-semibold uppercase tracking-[0.08em] text-text-muted"
        >
          {label}
        </label>
        {hint}
      </div>
      {children}
      {warning && <p className="text-xs text-warning">{warning}</p>}
    </div>
  );
}

/** Customer-details form. Edits a local draft; Save commits to shared flow state. */
export function ControlPanel({ onClose }: { onClose: () => void }) {
  const { customer, setCustomer } = useFlow();
  const [draft, setDraft] = useState<CustomerInfo>(customer);
  const [chatIdTouched, setChatIdTouched] = useState(false);

  const patch = (p: Partial<CustomerInfo>) => setDraft((d) => ({ ...d, ...p }));
  const age = ageFromDob(draft.dob);
  const chatIdValid = isValidChatLink(draft.chatId);

  const save = () => {
    if (!chatIdValid) {
      setChatIdTouched(true);
      return;
    }
    // Session logging picks this up from flow state (components/session-tracker.tsx).
    setCustomer(draft);
    onClose();
  };

  return (
    <PanelOverlay
      title={C.title}
      subtitle={C.subtitle}
      onClose={onClose}
      footer={
        <Button className="w-full" onClick={save} disabled={!chatIdValid}>
          {C.saveLabel}
        </Button>
      }
    >
      <div className="flex flex-col gap-4">
        <Field
          label={C.chatIdLabel}
          htmlFor="cp-chat-id"
          warning={chatIdTouched && !chatIdValid ? C.chatIdError : undefined}
        >
          <Input
            id="cp-chat-id"
            value={draft.chatId}
            placeholder={C.chatIdPlaceholder}
            onChange={(e) => patch({ chatId: e.target.value })}
            onBlur={() => setChatIdTouched(true)}
          />
        </Field>

        <Field label={C.nameLabel} htmlFor="cp-name">
          <Input
            id="cp-name"
            value={draft.name}
            placeholder={C.namePlaceholder}
            onChange={(e) => patch({ name: e.target.value })}
          />
        </Field>

        <Field label={C.genderLabel}>
          <Segmented
            value={draft.gender}
            onChange={(v) => patch({ gender: v as Gender })}
            options={[
              { value: "male", label: C.genderMale },
              { value: "female", label: C.genderFemale },
            ]}
          />
        </Field>

        <Field
          label={C.dobLabel}
          htmlFor="cp-dob"
          hint={
            age !== null && (
              <span className="text-[14px] font-semibold text-accent-blue">
                {C.ageLabel}: {age} {C.ageUnit}
              </span>
            )
          }
        >
          <Input
            id="cp-dob"
            type="date"
            value={draft.dob}
            onChange={(e) => patch({ dob: e.target.value })}
          />
        </Field>

        <div className="grid grid-cols-2 gap-3">
          <Field label={C.annualIncomeLabel} htmlFor="cp-income">
            <Input
              id="cp-income"
              inputMode="numeric"
              value={draft.annualIncome}
              placeholder={C.amountPlaceholder}
              onChange={(e) => patch({ annualIncome: digitsOnly(e.target.value) })}
            />
            <IndianWordsHint value={draft.annualIncome} />
          </Field>
          <Field label={C.monthlyExpensesLabel} htmlFor="cp-exp">
            <Input
              id="cp-exp"
              inputMode="numeric"
              value={draft.monthlyExpenses}
              placeholder={C.amountPlaceholder}
              onChange={(e) => patch({ monthlyExpenses: digitsOnly(e.target.value) })}
            />
            <IndianWordsHint value={draft.monthlyExpenses} />
          </Field>
        </div>

        <Field label={C.employmentLabel}>
          <Segmented
            value={draft.employment}
            onChange={(v) => patch({ employment: v as Employment })}
            options={[
              { value: "salaried", label: C.employmentSalaried },
              { value: "self-employed", label: C.employmentSelfEmployed },
            ]}
          />
        </Field>

        {/* PINCODE ARCHIVED — input removed from the form; draft.pincode,
            CustomerInfo.pincode, and the config default stay intact and
            dormant, so restoring is just re-adding this Field. */}
        <Field label={C.citizenshipLabel}>
          <Segmented
            value={draft.citizenship}
            onChange={(v) => patch({ citizenship: v as Citizenship })}
            options={[
              { value: "indian", label: C.citizenshipIndian },
              { value: "nri", label: C.citizenshipNri },
            ]}
          />
        </Field>

        <Field label={C.pedsLabel}>
          <Segmented
            value={draft.hasPEDs ? "yes" : "no"}
            onChange={(v) => patch({ hasPEDs: v === "yes" })}
            options={[
              { value: "no", label: C.pedsNo },
              { value: "yes", label: C.pedsYes },
            ]}
          />
        </Field>

        {draft.hasPEDs && (
          <Field label={C.pedDetailsLabel} htmlFor="cp-ped">
            <textarea
              id="cp-ped"
              rows={3}
              value={draft.pedDetails}
              placeholder={C.pedDetailsPlaceholder}
              onChange={(e) => patch({ pedDetails: e.target.value })}
              className="w-full resize-none rounded-md border border-border-default bg-bg-card-elevated px-3 py-2 text-sm text-text-primary outline-none transition-colors placeholder:text-text-muted focus:border-accent-blue/50 focus:ring-2 focus:ring-accent-blue/15"
            />
          </Field>
        )}

        <Field label={C.tobaccoLabel}>
          <Segmented
            value={draft.tobaccoUser ? "yes" : "no"}
            onChange={(v) => patch({ tobaccoUser: v === "yes" })}
            options={[
              { value: "no", label: C.tobaccoNo },
              { value: "yes", label: C.tobaccoYes },
            ]}
          />
        </Field>

        <Field label={C.educationLabel} htmlFor="cp-education">
          <select
            id="cp-education"
            value={draft.education}
            onChange={(e) => patch({ education: e.target.value as EducationLevel })}
            className="h-10 w-full rounded-md border border-border-default bg-bg-card-elevated px-3 text-sm text-text-primary outline-none transition-colors focus:border-accent-blue/50 focus:ring-2 focus:ring-accent-blue/15"
          >
            <option value="post-graduate">{C.educationPostGraduate}</option>
            <option value="graduate">{C.educationGraduate}</option>
            <option value="diploma">{C.educationDiploma}</option>
            <option value="hsc">{C.educationHsc}</option>
            <option value="ssc">{C.educationSsc}</option>
            <option value="below-10th">{C.educationBelow10th}</option>
          </select>
        </Field>

        <Field
          label={C.preferredCoverAgeLabel}
          htmlFor="cp-cover-age"
          warning={Number(draft.preferredCoverAge) >= TENURE_WARNING_AGE ? C.preferredCoverAgeWarning : undefined}
        >
          <Input
            id="cp-cover-age"
            inputMode="numeric"
            maxLength={2}
            value={draft.preferredCoverAge}
            placeholder={C.preferredCoverAgePlaceholder}
            onChange={(e) => patch({ preferredCoverAge: digitsOnly(e.target.value) })}
          />
        </Field>

        <div className="grid grid-cols-2 gap-3">
          <Field label={C.existingCoverAmountLabel} htmlFor="cp-existing-cover">
            <Input
              id="cp-existing-cover"
              inputMode="numeric"
              value={draft.existingCoverAmount}
              placeholder={C.amountPlaceholder}
              onChange={(e) => patch({ existingCoverAmount: digitsOnly(e.target.value) })}
            />
            <IndianWordsHint value={draft.existingCoverAmount} />
          </Field>
          <Field label={C.uninsuredLoansLabel} htmlFor="cp-uninsured-loans">
            <Input
              id="cp-uninsured-loans"
              inputMode="numeric"
              value={draft.uninsuredLoans}
              placeholder={C.amountPlaceholder}
              onChange={(e) => patch({ uninsuredLoans: digitsOnly(e.target.value) })}
            />
            <IndianWordsHint value={draft.uninsuredLoans} />
          </Field>
        </div>
      </div>
    </PanelOverlay>
  );
}
