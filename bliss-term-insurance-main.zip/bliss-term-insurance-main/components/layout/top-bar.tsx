"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { Home, Menu, RotateCcw } from "lucide-react";
import { useFlow } from "@/context/flow-provider";
import { PriceRevisionBanner } from "./price-revision-banner";
import chromeContent from "@/content/chrome.json";
import type { ChromeContent } from "@/types";

const CHROME = chromeContent as ChromeContent;

interface TopBarProps {
  /** Show the mobile hamburger (flow pages only). */
  showMenu?: boolean;
  onMenuClick?: () => void;
}

/** Persistent top bar: brand, home link, and a mobile menu, plus the site-wide price-revision strip beneath it. DARK MODE ARCHIVED — the theme toggle that lived here is removed; see docs/DARK_MODE_ARCHIVE.md. */
export function TopBar({ showMenu = false, onMenuClick }: TopBarProps) {
  const { startOver } = useFlow();
  const router = useRouter();

  const handleStartOver = () => {
    if (!window.confirm(CHROME.startOverConfirm)) return;
    startOver();
    router.push("/");
  };

  return (
    <>
      <header className="h-16 shrink-0 border-b border-border-default bg-bg-sidebar">
        <div className="flex h-full items-center justify-between px-6 lg:px-8">
          {/* Left: hamburger + brand. Brand keeps generous clear space (per
              Ditto brand guidelines) via the header's own edge padding and
              this gap rather than a literal wrapper — a full 25px on every
              side would nearly double this bar's height. */}
          <div className="flex items-center gap-4">
            {showMenu && (
              <button
                type="button"
                aria-label={CHROME.menuLabel}
                onClick={onMenuClick}
                className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-text-secondary transition-colors cursor-pointer hover:text-text-primary hover:bg-hover-surface lg:hidden"
              >
                <Menu className="h-5 w-5" />
              </button>
            )}
            <Link href="/" className="inline-flex items-center">
              <img src="/ditto-logo.png" alt={CHROME.brand} className="h-12 w-auto" draggable={false} />
            </Link>
          </div>

          {/* Right: nav */}
          <div className="flex items-center gap-2">
            <Link
              href="/"
              className="hidden items-center gap-2 rounded-lg px-3 py-2 text-sm text-text-secondary transition-colors hover:text-text-primary hover:bg-hover-surface md:inline-flex"
            >
              <Home className="h-4 w-4" />
              {CHROME.homeLink}
            </Link>
            <button
              type="button"
              aria-label={CHROME.startOverLabel}
              title={CHROME.startOverLabel}
              onClick={handleStartOver}
              className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-text-secondary transition-colors cursor-pointer hover:text-text-primary hover:bg-hover-surface"
            >
              <RotateCcw className="h-4 w-4" />
            </button>
          </div>
        </div>
      </header>
      <PriceRevisionBanner />
    </>
  );
}
