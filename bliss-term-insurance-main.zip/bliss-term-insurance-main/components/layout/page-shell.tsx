/**
 * Per-step page frame: eyebrow + two-tone hero heading + subtitle, then the
 * content slot. Navigation lives in the shell (left rail + animated Next Step
 * chevron), so the frame stays focused on hero + content. A gentle fade-in-up
 * gives each step a calm entrance without heavy page transitions.
 */
export function PageShell({
  eyebrow,
  title,
  titleAccent,
  subtitle,
  children,
}: {
  eyebrow: string;
  /** Usually a plain string; accepts a ReactNode for the rare page whose accent word sits mid-heading rather than at the end (see Why Now Matters). */
  title: React.ReactNode;
  titleAccent?: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-14">
      <header className="flex flex-col gap-3 animate-fade-in-up">
        <p className="text-[13px] font-semibold uppercase tracking-[0.12em] text-accent-blue">
          {eyebrow}
        </p>
        <h1 className="font-display text-3xl font-extrabold tracking-tight text-text-primary md:text-4xl lg:text-[55px] lg:leading-[1.05] lg:tracking-[-0.02em]">
          {title}
          {titleAccent && <span className="text-accent-blue"> {titleAccent}</span>}
        </h1>
        {subtitle && (
          <p className="max-w-[640px] text-base leading-[1.55] text-text-secondary">
            {subtitle}
          </p>
        )}
      </header>

      <div>{children}</div>
    </div>
  );
}
