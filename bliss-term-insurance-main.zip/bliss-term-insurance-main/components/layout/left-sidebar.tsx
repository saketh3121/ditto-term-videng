"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import { BookOpen, ChevronDown, PanelLeftClose, PanelLeftOpen } from "lucide-react";
import { cn } from "@/lib/utils";
import { STEPS, FLOW_META, type Step } from "@/config/flows";
import { RESOURCES, RESOURCES_SECTION_LABEL, type Resource } from "@/config/resources";
import { useScrollToSection } from "@/hooks/use-scroll-to-section";
import chromeContent from "@/content/chrome.json";
import type { ChromeContent } from "@/types";

const CHROME = chromeContent as ChromeContent;

interface LeftSidebarProps {
  className?: string;
  /** Called after any navigation — used to close the mobile drawer. */
  onNavigate?: () => void;
  /** When false the collapse toggle is hidden and the rail stays expanded (mobile drawer). */
  collapsible?: boolean;
}

/**
 * Step navigation — the sole nav surface, driven entirely by STEPS from
 * config/flows.ts. Collapses between a 380px full rail (widened for the
 * larger type scale — see .text-scale-1_25x in globals.css) and a 60px icon
 * rail with a smooth width transition; the active step shows an accent bar and,
 * when expanded, its scroll-anchored sub-steps. Auto-collapses the moment the
 * advisor clicks anywhere outside it (the page body, the right rail, the top
 * bar) — reopen via the same toggle button in the header.
 */
export function LeftSidebar({
  className,
  onNavigate,
  collapsible = true,
}: LeftSidebarProps) {
  const router = useRouter();
  const pathname = usePathname();
  const scrollToSection = useScrollToSection();
  const [collapsed, setCollapsed] = useState(false);
  const asideRef = useRef<HTMLElement>(null);

  const isCollapsed = collapsible && collapsed;

  const isResourceActive = (href: string) => pathname === href || (pathname?.startsWith(`${href}/`) ?? false);
  const isAnyResourceActive = RESOURCES.some((r) => isResourceActive(r.href));
  const [resourcesOpen, setResourcesOpen] = useState(isAnyResourceActive);

  // Landing on a Resources sub-page (e.g. via a WOP/CI table's Full List
  // link) expands the dropdown so the active entry is visible, without
  // fighting a manual close on every other navigation.
  useEffect(() => {
    if (isAnyResourceActive) setResourcesOpen(true);
  }, [isAnyResourceActive]);

  useEffect(() => {
    if (!collapsible) return;
    const handlePointerDown = (event: PointerEvent) => {
      const target = event.target as Node | null;
      if (!target || asideRef.current?.contains(target)) return;
      setCollapsed(true);
    };
    document.addEventListener("pointerdown", handlePointerDown);
    return () => document.removeEventListener("pointerdown", handlePointerDown);
  }, [collapsible]);

  const renderStepRow = (step: Step) => {
    const href = `/flow/${step.id}`;
    const isActive = pathname === href;
    const num = String(step.n).padStart(2, "0");

    if (isCollapsed) {
      return (
        <button
          key={step.id}
          onClick={() => {
            router.push(href);
            onNavigate?.();
          }}
          title={step.label}
          aria-label={step.label}
          className={cn(
            "group relative flex h-9 w-10 items-center justify-center rounded-md transition-colors cursor-pointer",
            isActive
              ? "bg-accent-blue-soft text-text-primary"
              : "text-text-secondary hover:text-text-primary hover:bg-hover-surface",
          )}
        >
          {isActive && (
            <span
              aria-hidden
              className="absolute left-0 top-1.5 bottom-1.5 w-0.5 rounded-full bg-accent-blue"
            />
          )}
          <span
            className={cn(
              "text-[14px] font-bold tracking-[0.12em] tabular-nums",
              isActive ? "text-accent-blue" : "text-text-muted",
            )}
          >
            {num}
          </span>
        </button>
      );
    }

    return (
      <div key={step.id} className="flex flex-col">
        <button
          onClick={() => {
            router.push(href);
            onNavigate?.();
          }}
          className={cn(
            "group relative grid grid-cols-[28px_1fr_12px] items-center gap-3 rounded-md px-3 py-2.5 text-left transition-colors cursor-pointer",
            isActive
              ? "bg-accent-blue-soft text-text-primary"
              : "text-text-secondary hover:text-text-primary hover:bg-hover-surface",
          )}
        >
          {isActive && (
            <span
              aria-hidden
              className="absolute left-0 top-2 bottom-2 w-0.5 rounded-full bg-accent-blue"
            />
          )}

          <span
            className={cn(
              "text-center text-[14px] font-bold tracking-[0.12em] tabular-nums transition-colors",
              isActive ? "text-accent-blue" : "text-text-muted",
            )}
          >
            {num}
          </span>

          <span
            className={cn(
              "truncate text-[16px] tracking-[-0.005em]",
              isActive ? "font-bold" : "font-semibold",
            )}
          >
            {step.label}
          </span>

          {step.subSteps.length > 0 ? (
            <ChevronDown
              className={cn(
                "h-3 w-3 shrink-0 transition-all",
                isActive
                  ? "rotate-180 text-accent-blue/70 opacity-100"
                  : "text-text-muted opacity-0 group-hover:opacity-100",
              )}
            />
          ) : (
            <span aria-hidden className="h-3 w-3" />
          )}
        </button>

        {isActive && step.subSteps.length > 0 && (
          <div className="mt-0.5 mb-1.5 ml-9 flex flex-col">
            {step.subSteps.map((sub) => (
              <button
                key={sub.id}
                onClick={() => {
                  scrollToSection(sub.id);
                  onNavigate?.();
                }}
                className="group/sub relative w-full rounded-md py-1 pl-3 pr-2 text-left text-[15px] text-text-muted transition-colors cursor-pointer hover:text-text-primary hover:bg-hover-surface"
              >
                <span
                  aria-hidden
                  className="absolute left-0.5 top-1/2 h-[3px] w-[3px] -translate-y-1/2 rounded-full bg-border-default transition-colors group-hover/sub:bg-accent-blue"
                />
                <span className="block truncate">{sub.title}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    );
  };

  const renderResourceRow = (resource: Resource) => {
    const href = resource.href;
    const isActive = isResourceActive(href);

    if (isCollapsed) {
      return (
        <button
          key={resource.id}
          onClick={() => {
            router.push(href);
            onNavigate?.();
          }}
          title={resource.label}
          aria-label={resource.label}
          className={cn(
            "group relative flex h-9 w-10 items-center justify-center rounded-md transition-colors cursor-pointer",
            isActive
              ? "bg-accent-blue-soft text-text-primary"
              : "text-text-secondary hover:text-text-primary hover:bg-hover-surface",
          )}
        >
          {isActive && (
            <span
              aria-hidden
              className="absolute left-0 top-1.5 bottom-1.5 w-0.5 rounded-full bg-accent-blue"
            />
          )}
          <BookOpen className={cn("h-4 w-4", isActive ? "text-accent-blue" : "text-text-muted")} />
        </button>
      );
    }

    return (
      <button
        key={resource.id}
        onClick={() => {
          router.push(href);
          onNavigate?.();
        }}
        className={cn(
          "group relative grid grid-cols-[28px_1fr] items-center gap-3 rounded-md px-3 py-2.5 text-left transition-colors cursor-pointer",
          isActive
            ? "bg-accent-blue-soft text-text-primary"
            : "text-text-secondary hover:text-text-primary hover:bg-hover-surface",
        )}
      >
        {isActive && (
          <span
            aria-hidden
            className="absolute left-0 top-2 bottom-2 w-0.5 rounded-full bg-accent-blue"
          />
        )}
        <BookOpen className={cn("h-4 w-4", isActive ? "text-accent-blue" : "text-text-muted")} />
        <span className={cn("truncate text-[16px] tracking-[-0.005em]", isActive ? "font-bold" : "font-semibold")}>
          {resource.label}
        </span>
      </button>
    );
  };

  return (
    <aside
      ref={asideRef}
      className={cn(
        "hidden h-full flex-col bg-bg-sidebar transition-[width] duration-200 ease-out lg:flex",
        "border-r border-border-default",
        isCollapsed ? "w-[60px]" : "w-[380px]",
        className,
      )}
    >
      {/* Header */}
      <div
        className={cn(
          "flex shrink-0",
          isCollapsed
            ? "justify-center pt-4 pb-3"
            : "items-start justify-between gap-2 px-[18px] pt-5 pb-3.5",
        )}
      >
        {!isCollapsed && (
          <div className="min-w-0 flex-1">
            <p className="text-[13px] font-bold uppercase tracking-[0.16em] text-accent-blue">
              {FLOW_META.title}
            </p>
            <p className="mt-1 text-[15px] leading-[1.45] text-text-muted">
              {FLOW_META.description}
            </p>
          </div>
        )}

        {collapsible && (
          <button
            onClick={() => setCollapsed((c) => !c)}
            title={isCollapsed ? CHROME.sidebarExpandTitle : CHROME.sidebarCollapseTitle}
            aria-label={isCollapsed ? CHROME.sidebarExpandTitle : CHROME.sidebarCollapseTitle}
            className={cn(
              "inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-text-muted transition-colors cursor-pointer hover:text-text-primary hover:bg-hover-surface",
              !isCollapsed && "mt-0.5",
            )}
          >
            {isCollapsed ? (
              <PanelLeftOpen className="h-4 w-4" />
            ) : (
              <PanelLeftClose className="h-4 w-4" />
            )}
          </button>
        )}
      </div>

      {/* Steps */}
      <nav
        className={cn(
          "flex min-h-0 flex-1 flex-col gap-px overflow-y-auto px-2.5 pt-1 pb-3",
          isCollapsed && "items-center",
        )}
      >
        {STEPS.map((step) => renderStepRow(step))}
      </nav>

      {/* Resources — pinned to the bottom, outside the numbered step flow */}
      <div
        className={cn(
          "shrink-0 border-t border-border-default px-2.5 py-3",
          isCollapsed && "flex flex-col items-center",
        )}
      >
        {!isCollapsed && (
          <button
            type="button"
            onClick={() => setResourcesOpen((o) => !o)}
            aria-expanded={resourcesOpen}
            className="mb-1 flex w-full cursor-pointer items-center justify-between gap-2 rounded-md px-3 py-1 text-[12px] font-bold uppercase tracking-[0.16em] text-text-muted transition-colors hover:text-text-primary"
          >
            {RESOURCES_SECTION_LABEL}
            <ChevronDown className={cn("h-3 w-3 shrink-0 transition-transform", resourcesOpen && "rotate-180")} />
          </button>
        )}
        {(isCollapsed || resourcesOpen) && (
          <div className={cn("flex flex-col gap-px", isCollapsed && "items-center")}>
            {RESOURCES.map((resource) => renderResourceRow(resource))}
          </div>
        )}
      </div>
    </aside>
  );
}
