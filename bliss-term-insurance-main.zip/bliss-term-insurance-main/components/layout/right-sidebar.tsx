"use client";

import { FileDown, ShieldCheck, SlidersHorizontal } from "lucide-react";
import { useSession } from "next-auth/react";
import { cn } from "@/lib/utils";
import { useFlow } from "@/context/flow-provider";
import { ControlPanel } from "./control-panel";
import { PolicyPanel } from "./policy-panel";
import { SummaryPanel } from "./summary-panel";
import chromeContent from "@/content/chrome.json";
import pdfSummaryContent from "@/content/pdf-summary.json";
import type { ChromeContent, PdfSummaryContent } from "@/types";

const CHROME = chromeContent as ChromeContent;
const SUMMARY = (pdfSummaryContent as PdfSummaryContent).panel;

function RailButton({
  title,
  active,
  onClick,
  children,
}: {
  title: string;
  active?: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={title}
      aria-label={title}
      className={cn(
        "inline-flex h-9 w-9 items-center justify-center rounded-lg transition-colors cursor-pointer",
        active
          ? "bg-accent-blue-soft text-accent-blue"
          : "text-text-muted hover:bg-hover-surface hover:text-text-primary",
      )}
    >
      {children}
    </button>
  );
}

/**
 * Thin right rail (56px band), present on every flow page. Holds the
 * Control Panel (customer details) and Policy Panel (policy selection) —
 * each opens a slide-in overlay. Hidden below `lg` (desktop-first).
 *
 * The Customer Summary PDF button is admin-only while it's piloted; the
 * server action it relies on re-checks the role.
 *
 * DARK MODE ARCHIVED — the theme toggle that lived here is removed; see
 * docs/DARK_MODE_ARCHIVE.md.
 */
export function RightSidebar() {
  const { activePanel: openPanel, setActivePanel: setOpenPanel } = useFlow();
  const { data: session } = useSession();
  const isAdmin = session?.user?.role === "admin";

  return (
    <>
      <aside className="hidden w-14 shrink-0 flex-col items-center gap-2 border-l border-border-default bg-bg-card py-4 lg:flex">
        <RailButton
          title={CHROME.controlPanel.iconTitle}
          active={openPanel === "control"}
          onClick={() => setOpenPanel("control")}
        >
          <SlidersHorizontal className="h-4 w-4" strokeWidth={1.75} />
        </RailButton>

        <RailButton
          title={CHROME.policyPanel.iconTitle}
          active={openPanel === "policy"}
          onClick={() => setOpenPanel("policy")}
        >
          <ShieldCheck className="h-4 w-4" strokeWidth={1.75} />
        </RailButton>

        {isAdmin && (
          <RailButton
            title={SUMMARY.iconTitle}
            active={openPanel === "summary"}
            onClick={() => setOpenPanel("summary")}
          >
            <FileDown className="h-4 w-4" strokeWidth={1.75} />
          </RailButton>
        )}
      </aside>

      {openPanel === "control" && (
        <ControlPanel onClose={() => setOpenPanel(null)} />
      )}
      {openPanel === "policy" && (
        <PolicyPanel onClose={() => setOpenPanel(null)} />
      )}
      {openPanel === "summary" && isAdmin && (
        <SummaryPanel onClose={() => setOpenPanel(null)} />
      )}
    </>
  );
}
