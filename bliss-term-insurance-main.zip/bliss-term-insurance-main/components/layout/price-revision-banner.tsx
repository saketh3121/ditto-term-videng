"use client";

import { AlertTriangle, X } from "lucide-react";
import { useFlow } from "@/context/flow-provider";
import { isWithinBannerWindow } from "@/lib/banner-window";
import chromeContent from "@/content/chrome.json";
import type { ChromeContent } from "@/types";

const CHROME = chromeContent as ChromeContent;

/**
 * Site-wide caution strip under the top bar (welcome page and every flow
 * step). Shown while ChromeContent.priceRevisionBanner's policy is among the
 * advisor's selected policies and its expiry hasn't passed. Closing it hides
 * it for the rest of this customer's call; Start Over brings it back.
 */
export function PriceRevisionBanner() {
  const { selectedPolicies, priceBannerDismissed, dismissPriceBanner } = useFlow();
  const banner = CHROME.priceRevisionBanner;
  if (
    !banner ||
    priceBannerDismissed ||
    !selectedPolicies.includes(banner.policyId) ||
    !isWithinBannerWindow(banner.expiresAt)
  ) {
    return null;
  }

  return (
    <div
      role="alert"
      className="flex shrink-0 items-start gap-3 border-b border-[var(--color-warning-border)] bg-[var(--color-warning-soft)] px-6 py-2.5 lg:px-8"
    >
      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-warning" />
      <p className="flex-1 text-sm leading-[1.5] text-text-primary">{banner.message}</p>
      <button
        type="button"
        onClick={dismissPriceBanner}
        aria-label={CHROME.closeLabel}
        title={CHROME.closeLabel}
        className="inline-flex h-6 w-6 shrink-0 cursor-pointer items-center justify-center rounded-md text-text-muted transition-colors hover:bg-hover-surface hover:text-text-primary"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}
