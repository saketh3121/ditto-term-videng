"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState, useTransition } from "react";
import { CheckStatusBadge } from "@/components/admin/check-status";
import { Button } from "@/components/ui/button";
import { approveAndMerge, getReviewStatus, rejectAndDiscard } from "@/lib/cms/actions";
import type { CheckStatus } from "@/lib/cms/github";
import type { AdminReviewContent } from "@/types";

const POLL_INTERVAL_MS = 12_000;

export function ReviewActions({ content }: { content: AdminReviewContent }) {
  const router = useRouter();
  const [checks, setChecks] = useState<CheckStatus | null>(null);
  const [confirmingReject, setConfirmingReject] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();

  useEffect(() => {
    let cancelled = false;
    const poll = async () => {
      const status = await getReviewStatus();
      if (!cancelled) setChecks(status.checks);
    };
    poll();
    const interval = setInterval(poll, POLL_INTERVAL_MS);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, []);

  const approve = () => {
    setError(null);
    startTransition(async () => {
      const result = await approveAndMerge();
      if (!result.ok) {
        setError(result.code === "conflict" ? content.mergeConflictMessage : result.error);
        return;
      }
      setMessage(content.approveSuccessMessage);
      router.refresh();
    });
  };

  const reject = () => {
    if (!confirmingReject) {
      setConfirmingReject(true);
      return;
    }
    setError(null);
    startTransition(async () => {
      const result = await rejectAndDiscard();
      setConfirmingReject(false);
      if (!result.ok) {
        setError(result.error);
        return;
      }
      router.refresh();
    });
  };

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-3">
        <CheckStatusBadge checks={checks} content={content} />
      </div>
      {error && <p className="text-sm text-bad">{error}</p>}
      {message && !error && <p className="text-sm text-good">{message}</p>}
      <div className="flex gap-3">
        <Button onClick={approve} disabled={pending || checks?.state !== "success"}>
          {content.approveLabel}
        </Button>
        <Button variant="ghost" onClick={reject} disabled={pending}>
          {confirmingReject ? content.rejectConfirmLabel : content.rejectLabel}
        </Button>
      </div>
    </div>
  );
}
