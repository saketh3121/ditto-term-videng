import Link from "next/link";
import type { Insurer } from "@/types";

export function InsurerTable({
  insurers,
  pendingIds,
}: {
  insurers: Insurer[];
  pendingIds: Set<string>;
}) {
  return (
    <div className="overflow-hidden rounded-lg border border-border-default">
      <table className="w-full text-left text-sm">
        <thead className="bg-bg-card-elevated text-xs uppercase tracking-wide text-text-muted">
          <tr>
            <th className="px-4 py-2.5 font-semibold">Name</th>
            <th className="px-4 py-2.5 font-semibold">CSR</th>
            <th className="px-4 py-2.5 font-semibold">ASR</th>
            <th className="px-4 py-2.5 font-semibold">Segments</th>
            <th className="px-4 py-2.5" />
          </tr>
        </thead>
        <tbody>
          {insurers.map((insurer) => (
            <tr key={insurer.id} className="border-t border-border-subtle">
              <td className="px-4 py-2.5 font-medium text-text-primary">
                {insurer.name}
                {pendingIds.has(insurer.id) && (
                  <span className="ml-2 rounded-full bg-accent-blue-soft px-2 py-0.5 text-[10px] font-semibold text-accent-blue">
                    pending
                  </span>
                )}
              </td>
              <td className="px-4 py-2.5 text-text-secondary">{insurer.csr}%</td>
              <td className="px-4 py-2.5 text-text-secondary">{insurer.asr}%</td>
              <td className="px-4 py-2.5 text-text-secondary">{insurer.segments.join(", ")}</td>
              <td className="px-4 py-2.5 text-right">
                <Link
                  href={`/admin/insurers/${insurer.id}/edit`}
                  className="text-xs font-semibold text-accent-blue hover:underline"
                >
                  Edit
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
