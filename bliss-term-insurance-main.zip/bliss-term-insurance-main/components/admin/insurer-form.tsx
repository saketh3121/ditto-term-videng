"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { submitInsurerEdit } from "@/lib/cms/actions";
import { slugify } from "@/lib/cms/slug";
import { cn } from "@/lib/utils";
import type { AdminInsurerFormContent, Insurer, Residency } from "@/types";

const BLANK: Insurer = {
  id: "",
  name: "",
  logo: "",
  csr: 0,
  complaintsPer10k: 0,
  asr: 0,
  annualBusinessCrore: 0,
  annualBusinessLabel: "",
  segments: [],
};

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-[11px] font-semibold uppercase tracking-[0.08em] text-text-muted">
        {label}
      </label>
      {children}
    </div>
  );
}

export function InsurerForm({
  mode,
  initial,
  content,
}: {
  mode: "create" | "edit";
  initial: Insurer | null;
  content: AdminInsurerFormContent;
}) {
  const router = useRouter();
  const [draft, setDraft] = useState<Insurer>(initial ?? BLANK);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [pending, startTransition] = useTransition();

  const patch = (p: Partial<Insurer>) => setDraft((d) => ({ ...d, ...p }));
  const toggleSegment = (segment: Residency) =>
    patch({
      segments: draft.segments.includes(segment)
        ? draft.segments.filter((s) => s !== segment)
        : [...draft.segments, segment],
    });

  const numberField = (key: "csr" | "complaintsPer10k" | "asr" | "annualBusinessCrore") => ({
    type: "number" as const,
    value: draft[key],
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => patch({ [key]: Number(e.target.value) }),
  });

  const submit = () => {
    setError(null);
    const id = mode === "create" ? slugify(draft.name) : initial!.id;
    const data: Insurer = { ...draft, id };
    startTransition(async () => {
      const result = await submitInsurerEdit({ id, mode, data });
      if (!result.ok) {
        setError(result.code === "duplicate_id" ? content.duplicateIdError : result.error);
        return;
      }
      setSaved(true);
      router.refresh();
    });
  };

  return (
    <div className="flex max-w-xl flex-col gap-4">
      <h1 className="text-h2 font-bold text-text-primary">
        {mode === "create" ? content.createHeading : content.editHeading}
      </h1>

      <Field label={content.nameLabel}>
        <Input value={draft.name} placeholder={content.namePlaceholder} onChange={(e) => patch({ name: e.target.value })} />
      </Field>

      <Field label={content.logoLabel}>
        <Input value={draft.logo} placeholder={content.logoPlaceholder} onChange={(e) => patch({ logo: e.target.value })} />
      </Field>

      <div className="grid grid-cols-2 gap-3">
        <Field label={content.csrLabel}>
          <Input {...numberField("csr")} />
        </Field>
        <Field label={content.asrLabel}>
          <Input {...numberField("asr")} />
        </Field>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Field label={content.complaintsPer10kLabel}>
          <Input {...numberField("complaintsPer10k")} />
        </Field>
        <Field label={content.annualBusinessCroreLabel}>
          <Input {...numberField("annualBusinessCrore")} />
        </Field>
      </div>

      <Field label={content.annualBusinessLabelLabel}>
        <Input
          value={draft.annualBusinessLabel}
          onChange={(e) => patch({ annualBusinessLabel: e.target.value })}
        />
      </Field>

      <Field label={content.segmentsLabel}>
        <div className="flex gap-2">
          {(["resident", "nri"] as const).map((segment) => (
            <button
              key={segment}
              type="button"
              onClick={() => toggleSegment(segment)}
              className={cn(
                "rounded-md border px-3 py-1.5 text-xs font-medium transition-colors cursor-pointer",
                draft.segments.includes(segment)
                  ? "border-accent-blue bg-accent-blue-soft text-accent-blue"
                  : "border-border-default text-text-secondary hover:text-text-primary",
              )}
            >
              {segment === "resident" ? content.segmentResident : content.segmentNri}
            </button>
          ))}
        </div>
      </Field>

      {error && <p className="text-sm text-bad">{error}</p>}
      {saved && !error && <p className="text-sm text-good">{content.savedMessage}</p>}

      <div className="mt-2 flex gap-3">
        <Button onClick={submit} disabled={pending || !draft.name}>
          {content.saveLabel}
        </Button>
        <Button variant="ghost" onClick={() => router.back()}>
          {content.cancelLabel}
        </Button>
      </div>
    </div>
  );
}
