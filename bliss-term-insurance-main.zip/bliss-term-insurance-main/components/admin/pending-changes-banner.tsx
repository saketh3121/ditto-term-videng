import Link from "next/link";
import type { AdminDashboardContent } from "@/types";
import type { PendingChange } from "@/lib/cms/pending-changes";

export function PendingChangesBanner({
  content,
  changes,
}: {
  content: AdminDashboardContent;
  changes: PendingChange[];
}) {
  if (changes.length === 0) {
    return (
      <div className="border-b border-border-subtle bg-bg-card px-6 py-2.5 text-xs text-text-muted">
        {content.pendingBannerEmptyLabel}
      </div>
    );
  }

  return (
    <div className="flex items-center justify-between gap-3 border-b border-accent-blue-border bg-bg-card-accent px-6 py-2.5">
      <span className="text-xs font-medium text-text-primary">
        {content.pendingBannerTemplate.replace("{count}", String(changes.length))}
      </span>
      <Link href="/admin/review" className="text-xs font-semibold text-accent-blue hover:underline">
        {content.pendingBannerCta}
      </Link>
    </div>
  );
}
