"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { submitPolicyEdit } from "@/lib/cms/actions";
import { slugify } from "@/lib/cms/slug";
import type { AdminPolicyFormContent, Insurer, Policy } from "@/types";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-[11px] font-semibold uppercase tracking-[0.08em] text-text-muted">
        {label}
      </label>
      {children}
    </div>
  );
}

export function PolicyForm({
  mode,
  initial,
  insurers,
  content,
}: {
  mode: "create" | "edit";
  initial: Policy | null;
  insurers: Insurer[];
  content: AdminPolicyFormContent;
}) {
  const router = useRouter();
  const firstInsurer = insurers[0];
  const [name, setName] = useState(initial?.name ?? "");
  const [insurerId, setInsurerId] = useState(initial?.insurerId ?? firstInsurer?.id ?? "");
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [pending, startTransition] = useTransition();

  const submit = () => {
    setError(null);
    const insurer = insurers.find((i) => i.id === insurerId);
    if (!insurer) {
      setError("Select an insurer.");
      return;
    }
    const id = mode === "create" ? `${insurer.id}-${slugify(name)}` : initial!.id;
    const data: Policy = { id, name, insurerId: insurer.id, insurerName: insurer.name };
    startTransition(async () => {
      const result = await submitPolicyEdit({ id, mode, data });
      if (!result.ok) {
        setError(result.code === "duplicate_id" ? content.duplicateIdError : result.error);
        return;
      }
      setSaved(true);
      router.refresh();
    });
  };

  return (
    <div className="flex max-w-xl flex-col gap-4">
      <h1 className="text-h2 font-bold text-text-primary">
        {mode === "create" ? content.createHeading : content.editHeading}
      </h1>

      <Field label={content.nameLabel}>
        <Input value={name} placeholder={content.namePlaceholder} onChange={(e) => setName(e.target.value)} />
      </Field>

      <Field label={content.insurerLabel}>
        <select
          value={insurerId}
          onChange={(e) => setInsurerId(e.target.value)}
          className="h-10 w-full rounded-md border border-border-default bg-bg-card-elevated px-3 text-sm text-text-primary outline-none"
        >
          {insurers.map((insurer) => (
            <option key={insurer.id} value={insurer.id}>
              {insurer.name}
            </option>
          ))}
        </select>
      </Field>

      {mode === "edit" && (
        <Field label={content.idLabel}>
          <Input value={initial?.id} disabled />
        </Field>
      )}

      {error && <p className="text-sm text-bad">{error}</p>}
      {saved && !error && <p className="text-sm text-good">{content.savedMessage}</p>}

      <div className="mt-2 flex gap-3">
        <Button onClick={submit} disabled={pending || !name || !insurerId}>
          {content.saveLabel}
        </Button>
        <Button variant="ghost" onClick={() => router.back()}>
          {content.cancelLabel}
        </Button>
      </div>
    </div>
  );
}
