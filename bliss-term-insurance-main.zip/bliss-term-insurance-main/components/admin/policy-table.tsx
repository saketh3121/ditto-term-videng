import Link from "next/link";
import type { InsurerPolicyGroup } from "@/lib/cms/policies-live";

export function PolicyTable({
  groups,
  pendingIds,
}: {
  groups: InsurerPolicyGroup[];
  pendingIds: Set<string>;
}) {
  return (
    <div className="flex flex-col gap-4">
      {groups.map((group) => (
        <div key={group.insurerId} className="overflow-hidden rounded-lg border border-border-default">
          <div className="bg-bg-card-elevated px-4 py-2 text-xs font-semibold uppercase tracking-wide text-text-muted">
            {group.insurerName}
          </div>
          <table className="w-full text-left text-sm">
            <tbody>
              {group.policies.map((policy) => (
                <tr key={policy.id} className="border-t border-border-subtle">
                  <td className="px-4 py-2.5 font-medium text-text-primary">
                    {policy.name}
                    {pendingIds.has(policy.id) && (
                      <span className="ml-2 rounded-full bg-accent-blue-soft px-2 py-0.5 text-[10px] font-semibold text-accent-blue">
                        pending
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-2.5 text-right">
                    <Link
                      href={`/admin/policies/${policy.id}/edit`}
                      className="text-xs font-semibold text-accent-blue hover:underline"
                    >
                      Edit
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ))}
    </div>
  );
}
