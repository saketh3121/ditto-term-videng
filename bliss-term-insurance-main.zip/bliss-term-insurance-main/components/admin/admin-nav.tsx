import Link from "next/link";
import { SignOutButton } from "@/components/admin/sign-out-button";
import { cn } from "@/lib/utils";
import type { AdminNavContent } from "@/types";

const LINKS = [
  { href: "/admin", key: "dashboardLabel" as const },
  { href: "/admin/insurers", key: "insurersLabel" as const },
  { href: "/admin/policies", key: "policiesLabel" as const },
];

export function AdminNav({
  content,
  email,
  isAdmin,
}: {
  content: AdminNavContent;
  email: string;
  isAdmin: boolean;
}) {
  return (
    <header className="flex items-center justify-between gap-4 border-b border-border-default bg-bg-sidebar px-6 py-3">
      <div className="flex items-center gap-6">
        <span className="text-sm font-bold text-text-primary">{content.brand}</span>
        <nav className="flex items-center gap-1">
          {LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="rounded-md px-3 py-1.5 text-sm text-text-secondary transition-colors hover:bg-hover-surface hover:text-text-primary"
            >
              {content[link.key]}
            </Link>
          ))}
          {isAdmin && (
            <Link
              href="/admin/review"
              className={cn(
                "rounded-md px-3 py-1.5 text-sm font-medium transition-colors",
                "text-accent-blue hover:bg-accent-blue-soft",
              )}
            >
              {content.reviewLabel}
            </Link>
          )}
        </nav>
      </div>
      <div className="flex items-center gap-3">
        <span className="text-xs text-text-muted">
          {content.signedInAsTemplate.replace("{email}", email)}
        </span>
        <SignOutButton label={content.signOutLabel} />
      </div>
    </header>
  );
}
