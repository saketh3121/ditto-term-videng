import { cn } from "@/lib/utils";
import type { PendingChange } from "@/lib/cms/pending-changes";

const STATUS_STYLES: Record<PendingChange["diff"]["status"], string> = {
  added: "text-good bg-good/10",
  removed: "text-bad bg-bad/10",
  modified: "text-accent-blue bg-accent-blue-soft",
  unchanged: "text-text-muted bg-hover-surface",
};

export function DiffView({ changes }: { changes: PendingChange[] }) {
  return (
    <div className="flex flex-col gap-3">
      {changes.map((change) => (
        <div
          key={`${change.recordType}-${change.recordId}`}
          className="rounded-lg border border-border-default bg-bg-card p-4"
        >
          <div className="mb-2 flex items-center gap-2">
            <span
              className={cn(
                "rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide",
                STATUS_STYLES[change.diff.status],
              )}
            >
              {change.diff.status}
            </span>
            <span className="text-sm font-semibold text-text-primary">{change.recordLabel}</span>
            <span className="text-xs text-text-muted">
              {change.recordType} · {change.recordId}
            </span>
          </div>
          <div className="flex flex-col gap-1">
            {change.diff.changes.map((fieldChange) => (
              <div key={fieldChange.field} className="grid grid-cols-[120px_1fr] gap-2 text-xs">
                <span className="font-medium text-text-muted">{fieldChange.field}</span>
                <span className="text-text-secondary">
                  <span className="text-bad/80 line-through">{JSON.stringify(fieldChange.before)}</span>
                  {" → "}
                  <span className="text-good">{JSON.stringify(fieldChange.after)}</span>
                </span>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
