"use client";

import { signOut } from "next-auth/react";
import { Button } from "@/components/ui/button";

export function SignOutButton({ label }: { label: string }) {
  return (
    <Button variant="ghost" size="md" onClick={() => signOut({ redirectTo: "/admin" })}>
      {label}
    </Button>
  );
}
