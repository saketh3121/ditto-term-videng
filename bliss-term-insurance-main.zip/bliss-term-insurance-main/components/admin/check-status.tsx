"use client";

import { cn } from "@/lib/utils";
import type { CheckStatus } from "@/lib/cms/github";
import type { AdminReviewContent } from "@/types";

const LABEL: Record<CheckStatus["state"], keyof Pick<AdminReviewContent, "checksPendingLabel" | "checksPassedLabel" | "checksFailedLabel">> = {
  pending: "checksPendingLabel",
  success: "checksPassedLabel",
  failure: "checksFailedLabel",
};

const STYLE: Record<CheckStatus["state"], string> = {
  pending: "text-text-muted bg-hover-surface",
  success: "text-good bg-good/10",
  failure: "text-bad bg-bad/10",
};

export function CheckStatusBadge({ checks, content }: { checks: CheckStatus | null; content: AdminReviewContent }) {
  if (!checks) return null;
  return (
    <span className={cn("inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold", STYLE[checks.state])}>
      {content[LABEL[checks.state]]}
    </span>
  );
}
