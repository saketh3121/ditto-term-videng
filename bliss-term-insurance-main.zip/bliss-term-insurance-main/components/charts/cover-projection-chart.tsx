"use client";

import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Card } from "@/components/ui/card";
import { formatRupees } from "@/lib/calc/cover";
import type { CoverResult } from "@/lib/calc/cover";

/**
 * Basic-mode projection chart, paired with SuggestedCoverBanner in a
 * two-column grid (see cover-amount.tsx) where the insurer-wise max
 * eligibility list used to sit. `projection` is expected pre-sampled via
 * lib/calc/cover.ts's sampleProjectionByInterval — one bar every 10 years
 * plus the final year of the tenure, not every single year.
 *
 * The underlying engine works in annual terms (see lib/calc/cover.ts) —
 * that's what the NPV/eligibility math needs — but advisors and customers
 * think in monthly expenses, so this chart divides down to monthly for
 * display only; nothing upstream of it changes units.
 */

interface ChartTooltipProps {
  active?: boolean;
  payload?: Array<{ value?: number }>;
  label?: number | string;
  inflationRate?: number;
}

function ChartTooltip({ active, payload, label, inflationRate }: ChartTooltipProps) {
  if (!active || !payload?.length) return null;
  const value = payload[0]?.value;
  if (typeof value !== "number") return null;
  return (
    <div className="rounded-lg border border-border-default bg-bg-card/95 px-3 py-2 text-xs shadow-lg backdrop-blur">
      <p className="font-semibold text-text-primary">Age {label}</p>
      <div className="mt-1.5 space-y-0.5 tabular-nums text-text-secondary">
        <p>{formatRupees(value)} monthly expense</p>
        {typeof inflationRate === "number" && (
          <p className="text-text-muted">Inflation: {(inflationRate * 100).toFixed(1)}%</p>
        )}
      </div>
    </div>
  );
}

export function CoverProjectionChart({
  projection,
  heading = "Projected monthly expense",
  inflationRate,
}: {
  projection: CoverResult["projection"];
  heading?: string;
  inflationRate?: number;
}) {
  const data = projection.map((p) => ({ ...p, monthlyExpense: Math.round(p.annualExpense / 12) }));

  return (
    <Card className="flex h-full flex-col gap-6">
      <header className="min-w-0">
        <h3 className="text-lg font-semibold text-text-primary">{heading}</h3>
        <p className="mt-1 text-sm leading-relaxed text-text-secondary">
          from your current age to the end of the policy term
        </p>
      </header>
      <div className="-mx-2 h-[340px] md:-mx-1">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 4, right: 16, bottom: 8, left: 4 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border-default)" vertical={false} />
            <XAxis dataKey="age" tick={{ fontSize: 11, fill: "var(--text-muted)" }} axisLine={false} tickLine={false} height={28} />
            <YAxis tickFormatter={formatRupees} tick={{ fontSize: 11, fill: "var(--text-muted)" }} axisLine={false} tickLine={false} width={64} />
            <Tooltip
              cursor={{ fill: "var(--color-brand-soft)" }}
              content={<ChartTooltip inflationRate={inflationRate} />}
            />
            <Bar dataKey="monthlyExpense" radius={[6, 6, 0, 0]} fill="var(--color-brand)" isAnimationActive={false} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}
