"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";
import {
  MILESTONES,
  MILESTONE_AGE_MAX,
  MILESTONE_AGE_MIN,
  PERSONAL_GOALS_BASE_MONTHLY,
  PROJECTION_END_AGE,
  type IncludedMilestones,
  type MilestoneAges,
  type MilestoneKey,
} from "@/config/milestone-assumptions";
import { effectiveMilestoneAge } from "@/lib/calc/milestone-expense-projection";

/**
 * Milestone checkbox strip + editable ages + personal-goals toggle. Split
 * out of milestone-inputs-panel.tsx to stay near CLAUDE.md's ~150-line
 * component guideline.
 */

export interface PersonalGoalsState {
  included: boolean;
  age: number | null;
  monthlyAmount?: number | "" | undefined;
}

const GOAL_AMOUNT_FORMATTER = new Intl.NumberFormat("en-IN");
function formatGoalAmount(v: number | string | null | undefined): string {
  if (v === "" || v == null) return "";
  const digits = String(v).replace(/[^\d]/g, "");
  if (!digits) return "";
  return GOAL_AMOUNT_FORMATTER.format(Number(digits));
}
function stripGoalAmount(s: string | null | undefined): string {
  return s == null ? "" : String(s).replace(/[^\d]/g, "");
}

interface MilestoneIncludeStripProps {
  currentAge: number;
  includedMilestones?: Partial<IncludedMilestones>;
  onToggleMilestone?: (key: MilestoneKey, value: boolean) => void;
  personalGoals?: PersonalGoalsState;
  onPersonalGoalsChange?: (goals: PersonalGoalsState) => void;
  customMilestoneAges?: Partial<MilestoneAges>;
  onCustomMilestoneAgeChange?: (key: MilestoneKey, age: number) => void;
}

export function MilestoneIncludeStrip({
  currentAge,
  includedMilestones = {},
  onToggleMilestone,
  personalGoals = { included: false, age: null },
  onPersonalGoalsChange,
  customMilestoneAges = {},
  onCustomMilestoneAgeChange,
}: MilestoneIncludeStripProps) {
  const [editing, setEditing] = useState(false);
  const goalsChecked = personalGoals.included === true;
  const goalAgeMin = currentAge;
  const goalAgeMax = PROJECTION_END_AGE;

  const togglePersonalGoals = (e: React.ChangeEvent<HTMLInputElement>) => {
    onPersonalGoalsChange?.({
      ...personalGoals,
      included: e.target.checked,
      age: e.target.checked
        ? Number.isFinite(Number(personalGoals.age)) && Number(personalGoals.age) >= goalAgeMin
          ? Number(personalGoals.age)
          : Math.min(goalAgeMax, currentAge + 5)
        : null,
      monthlyAmount:
        Number.isFinite(Number(personalGoals.monthlyAmount)) && Number(personalGoals.monthlyAmount) > 0
          ? personalGoals.monthlyAmount
          : PERSONAL_GOALS_BASE_MONTHLY,
    });
  };

  const setGoalAge = (raw: string) => {
    const n = Number(raw);
    onPersonalGoalsChange?.({ ...personalGoals, included: true, age: Number.isFinite(n) ? n : null });
  };

  const setGoalAmount = (raw: string) => {
    onPersonalGoalsChange?.({ ...personalGoals, included: true, monthlyAmount: raw === "" ? "" : Number(raw) });
  };

  const effectiveGoalAmount =
    Number.isFinite(Number(personalGoals.monthlyAmount)) && Number(personalGoals.monthlyAmount) > 0
      ? Number(personalGoals.monthlyAmount)
      : PERSONAL_GOALS_BASE_MONTHLY;

  const chipClass = (state: "disabled" | "checked" | "unchecked") =>
    cn(
      "inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs transition",
      state === "disabled" && "cursor-not-allowed border-border-default bg-bg-card-elevated text-text-muted opacity-60",
      state === "checked" && "cursor-pointer border-good/40 bg-bg-card text-text-secondary",
      state === "unchecked" && "cursor-pointer border-border-default bg-bg-card text-text-muted",
    );

  return (
    <fieldset className="rounded-xl border border-border-default bg-bg-card-elevated px-4 py-3">
      <div className="flex items-baseline justify-between gap-3">
        <legend className="px-1 text-[13px] font-semibold uppercase tracking-wider text-text-muted">
          Include in projection
        </legend>
        <button
          type="button"
          onClick={() => setEditing((v) => !v)}
          className="inline-flex items-center gap-1.5 rounded-full border border-border-default bg-bg-card px-2.5 py-1 text-[14px] font-medium text-text-secondary transition hover:border-border-strong hover:text-text-primary"
          aria-pressed={editing}
        >
          {editing ? "✓ Done" : "Edit ages"}
        </button>
      </div>

      <div className="mt-2 flex flex-wrap items-center gap-2">
        {MILESTONES.map((m) => {
          const checked = includedMilestones[m.key] !== false;
          const effAge = effectiveMilestoneAge(m.key, customMilestoneAges);
          const isPast = effAge <= currentAge;
          const firstChildChecked = includedMilestones.firstChild !== false;
          const disabled = m.key === "secondChild" && !firstChildChecked;
          return (
            <label
              key={m.key}
              title={disabled ? "Select First child first" : undefined}
              className={chipClass(disabled ? "disabled" : checked ? "checked" : "unchecked")}
            >
              <input
                type="checkbox"
                checked={checked && !disabled}
                disabled={disabled}
                onChange={(e) => onToggleMilestone?.(m.key, e.target.checked)}
                className="h-3.5 w-3.5 accent-[var(--color-good)] disabled:cursor-not-allowed"
              />
              <span className="font-medium">{m.label}</span>
              {editing ? (
                <input
                  type="number"
                  min={MILESTONE_AGE_MIN}
                  max={MILESTONE_AGE_MAX}
                  step={1}
                  value={effAge}
                  onChange={(e) => onCustomMilestoneAgeChange?.(m.key, Number(e.target.value))}
                  onClick={(e) => e.stopPropagation()}
                  onKeyDown={(e) => e.stopPropagation()}
                  className="ml-0.5 w-12 rounded border border-border-default bg-bg-card-elevated px-1 py-0.5 text-[14px] tabular-nums text-text-secondary focus:border-accent-blue/50 focus:outline-none focus:ring-1 focus:ring-accent-blue/15"
                  aria-label={`${m.label} age`}
                />
              ) : (
                <span className="text-text-muted tabular-nums">({effAge})</span>
              )}
              {isPast && !editing && (
                <span className="rounded-full bg-hover-surface px-1.5 py-0.5 text-[13px] font-medium text-text-muted">
                  past
                </span>
              )}
            </label>
          );
        })}

        <label className={chipClass(goalsChecked ? "checked" : "unchecked")}>
          <input
            type="checkbox"
            checked={goalsChecked}
            onChange={togglePersonalGoals}
            className="h-3.5 w-3.5 cursor-pointer accent-[var(--color-good)]"
          />
          <span className="font-medium">Personal goals</span>
          {goalsChecked && Number.isFinite(Number(personalGoals.age)) && (
            <span className="text-text-muted tabular-nums">({personalGoals.age})</span>
          )}
        </label>
      </div>

      {goalsChecked && (
        <div className="mt-3 flex flex-wrap items-end gap-3 border-t border-border-default pt-3">
          <label className="block">
            <span className="text-[13px] font-medium uppercase tracking-wider text-text-muted">
              Start goals at age
            </span>
            <div className="mt-1.5 flex w-24 items-center gap-1 rounded-md border border-border-default bg-bg-card-elevated px-2 py-1 focus-within:border-accent-blue/50 focus-within:ring-2 focus-within:ring-accent-blue/15">
              <input
                type="number"
                min={goalAgeMin}
                max={goalAgeMax}
                step={1}
                value={Number.isFinite(Number(personalGoals.age)) ? (personalGoals.age as number) : ""}
                onChange={(e) => setGoalAge(e.target.value)}
                className="min-w-0 flex-1 bg-transparent text-sm tabular-nums text-text-primary outline-none placeholder:text-text-muted"
              />
              <span className="text-[13px] text-text-muted">years</span>
            </div>
          </label>
          <label className="block">
            <span className="text-[13px] font-medium uppercase tracking-wider text-text-muted">
              Monthly amount today
            </span>
            <div className="mt-1.5 flex w-36 items-center gap-1 rounded-md border border-border-default bg-bg-card-elevated px-2 py-1 focus-within:border-accent-blue/50 focus-within:ring-2 focus-within:ring-accent-blue/15">
              <span className="text-[13px] text-text-muted">₹</span>
              <input
                type="text"
                inputMode="numeric"
                value={formatGoalAmount(personalGoals.monthlyAmount)}
                placeholder={GOAL_AMOUNT_FORMATTER.format(PERSONAL_GOALS_BASE_MONTHLY)}
                onChange={(e) => setGoalAmount(stripGoalAmount(e.target.value))}
                className="min-w-0 flex-1 bg-transparent text-sm tabular-nums text-text-primary outline-none placeholder:text-text-muted"
              />
              <span className="text-[13px] text-text-muted">/mo</span>
            </div>
          </label>
          <p className="text-[14px] leading-relaxed text-text-muted">
            Adds ₹{effectiveGoalAmount.toLocaleString("en-IN")}/mo in today's prices, inflated each year and carried
            forward from this age onward.
          </p>
        </div>
      )}

      {MILESTONES.some((m) => m.age <= currentAge) && (
        <p className="mt-2 text-[13px] leading-relaxed text-text-muted">
          Past milestones can be toggled, but they don't produce a bar — earlier life events are assumed already in
          your current expense.
        </p>
      )}
    </fieldset>
  );
}
