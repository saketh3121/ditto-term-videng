"use client";

import { MilestoneIncludeStrip, type PersonalGoalsState } from "@/components/charts/milestone-include-strip";
import type { IncludedMilestones, MilestoneAges, MilestoneKey } from "@/config/milestone-assumptions";

export type { PersonalGoalsState } from "@/components/charts/milestone-include-strip";

/**
 * Milestone inputs: which milestones/personal goals feed the projections.
 * Renders no chart of its own — every input checked here reflects directly
 * in the Year-by-year expense outlook card. The inflation slider and
 * assumptions disclosure live below that chart (ExpenseProjectionAssumptions,
 * rendered by cover-amount.tsx), not here.
 */

interface MilestoneInputsPanelProps {
  currentAge: number;
  includedMilestones: Partial<IncludedMilestones>;
  onToggleMilestone?: (key: MilestoneKey, value: boolean) => void;
  personalGoals: PersonalGoalsState;
  onPersonalGoalsChange?: (goals: PersonalGoalsState) => void;
  customMilestoneAges: Partial<MilestoneAges>;
  onCustomMilestoneAgeChange?: (key: MilestoneKey, age: number) => void;
}

export function MilestoneInputsPanel({
  currentAge,
  includedMilestones,
  onToggleMilestone,
  personalGoals,
  onPersonalGoalsChange,
  customMilestoneAges,
  onCustomMilestoneAgeChange,
}: MilestoneInputsPanelProps) {
  return (
    <MilestoneIncludeStrip
      currentAge={currentAge}
      includedMilestones={includedMilestones}
      onToggleMilestone={onToggleMilestone}
      personalGoals={personalGoals}
      onPersonalGoalsChange={onPersonalGoalsChange}
      customMilestoneAges={customMilestoneAges}
      onCustomMilestoneAgeChange={onCustomMilestoneAgeChange}
    />
  );
}
