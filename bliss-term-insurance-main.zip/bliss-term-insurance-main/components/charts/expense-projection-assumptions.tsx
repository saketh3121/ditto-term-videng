"use client";

import { cn } from "@/lib/utils";
import {
  INFLATION_RATE_MAX,
  INFLATION_RATE_MIN,
  INFLATION_RATE_STEP,
  KID_INDEPENDENCE_MAX,
  KID_INDEPENDENCE_MIN,
  MILESTONE_MULTIPLIERS,
  MILESTONES,
  PROJECTION_END_AGE,
  type IncludedMilestones,
  type MilestoneAges,
  type MilestoneKey,
  type Tier,
} from "@/config/milestone-assumptions";
import {
  effectiveMilestoneAge,
  incomeBracketIndex,
  INCOME_BRACKET_LABELS,
  type ActiveMilestone,
} from "@/lib/calc/milestone-expense-projection";

/** Collapsible assumptions panel + inflation slider for the milestone bar chart. */

type MilestoneStatus = "past" | "excluded" | "active";

interface ExpenseProjectionAssumptionsProps {
  currentAge: number;
  annualIncome: number;
  tier: Tier;
  inflationRate: number;
  onInflationRateChange?: ((rate: number) => void) | undefined;
  includedMilestones?: Partial<IncludedMilestones>;
  activeMilestones?: ActiveMilestone[];
  customMilestoneAges?: Partial<MilestoneAges>;
}

export function ExpenseProjectionAssumptions({
  currentAge,
  annualIncome,
  tier,
  inflationRate,
  onInflationRateChange,
  includedMilestones = {},
  activeMilestones = [],
  customMilestoneAges = {},
}: ExpenseProjectionAssumptionsProps) {
  const bracketIdx = incomeBracketIndex(annualIncome);
  const tierLabel = tier === "tier2" ? "Non-metro" : "Metro";
  const multTable = MILESTONE_MULTIPLIERS[tier] ?? MILESTONE_MULTIPLIERS.tier1;
  const pct = (n: number) => `${+(n * 100).toFixed(1)}%`;
  const activeKeys = new Set(activeMilestones.map((m) => m.key));
  const effAge = (m: { key: MilestoneKey }) => effectiveMilestoneAge(m.key, customMilestoneAges);
  const statusFor = (m: { key: MilestoneKey }): MilestoneStatus => {
    if (effAge(m) <= currentAge) return "past";
    if (includedMilestones[m.key] === false) return "excluded";
    return activeKeys.has(m.key) ? "active" : "excluded";
  };

  const items: [string, string][] = [
    ["Bars shown", "Today plus each checked future milestone, in chronological order"],
    ["Milestone horizon", `Through age ${PROJECTION_END_AGE}`],
    [
      "Kid financial independence",
      `Assumed between age ${KID_INDEPENDENCE_MIN} and ${KID_INDEPENDENCE_MAX} of the kid; drives the ideal tenure range`,
    ],
    ["City tier (current selection)", tierLabel],
    ["Income bracket (current)", `${INCOME_BRACKET_LABELS[bracketIdx]} → column ${bracketIdx + 1} of the multiplier table`],
    [
      "Milestone trigger ages",
      MILESTONES.map((m) => `${m.label} ${effAge(m)}`).join(" · ") + " · only those after your current age apply",
    ],
  ];

  return (
    <div className="overflow-hidden rounded-card border border-border-default bg-bg-card">
      <details className="group">
        <summary className="flex cursor-pointer list-none items-center justify-between gap-2 px-6 py-4 transition-colors hover:bg-bg-card-elevated focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent-blue">
          <span className="text-base font-semibold text-text-primary">Assumptions used in this projection</span>
          <span className="inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-border-default text-text-muted transition-transform duration-200 group-open:rotate-180">
            ▾
          </span>
        </summary>

        <div className="border-t border-border-subtle px-6 py-5">
          <div className="rounded-lg border border-border-default bg-bg-card-elevated p-4">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <label htmlFor="assumptions-inflation-slider" className="text-sm font-semibold text-text-primary">
                Inflation rate
              </label>
              <span className="text-base font-semibold tabular-nums text-text-primary">
                {pct(inflationRate)} <span className="text-sm font-normal text-text-muted">/ year</span>
              </span>
            </div>
            <input
              id="assumptions-inflation-slider"
              type="range"
              min={INFLATION_RATE_MIN}
              max={INFLATION_RATE_MAX}
              step={INFLATION_RATE_STEP}
              value={inflationRate}
              onChange={(e) => onInflationRateChange?.(Number(e.target.value))}
              disabled={!onInflationRateChange}
              className="mt-2 w-full accent-[var(--color-accent-blue)] disabled:cursor-not-allowed disabled:opacity-50"
              aria-valuemin={INFLATION_RATE_MIN}
              aria-valuemax={INFLATION_RATE_MAX}
              aria-valuenow={inflationRate}
              aria-valuetext={`${pct(inflationRate)} per year`}
            />
            <div className="mt-1 flex justify-between text-xs tabular-nums text-text-muted">
              <span>{pct(INFLATION_RATE_MIN)}</span>
              <span>{pct(INFLATION_RATE_MAX)}</span>
            </div>
            <p className="mt-2 text-sm leading-relaxed text-text-muted">
              Applied to every projection on this page, compounded between bars.
            </p>
          </div>

          <dl className="mt-4 grid gap-x-6 gap-y-1 text-sm sm:grid-cols-2">
            {items.map(([label, value]) => (
              <div key={label} className="flex items-baseline justify-between gap-3 border-b border-dashed border-border-subtle py-1">
                <dt className="text-text-muted">{label}</dt>
                <dd className="text-right font-medium tabular-nums text-text-secondary">{value}</dd>
              </div>
            ))}
          </dl>

          <div className="mt-4">
            <p className="text-sm font-semibold text-text-primary">Milestone multipliers, {tierLabel}</p>
            <p className="mt-1 text-sm text-text-muted">Read from the column matching your income bracket above.</p>
            <div className="mt-2 overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="text-left text-text-muted">
                    <th className="py-1 pr-3 font-medium">Milestone</th>
                    {INCOME_BRACKET_LABELS.map((lbl, i) => (
                      <th key={lbl} className={cn("px-2 py-1 text-right font-medium tabular-nums", i === bracketIdx && "text-accent-blue")}>
                        {lbl}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {MILESTONES.map((m) => {
                    const row = multTable[m.key];
                    const status = statusFor(m);
                    return (
                      <tr key={m.key} className="border-t border-dashed border-border-subtle">
                        <td className="py-1 pr-3 text-text-secondary">
                          {m.label} <span className="text-text-muted">({effAge(m)})</span>
                          {status === "past" && <span className="ml-1 text-xs text-text-muted">· already past</span>}
                          {status === "excluded" && <span className="ml-1 text-xs text-text-muted">· excluded</span>}
                        </td>
                        {row.map((v, i) => (
                          <td key={i} className={cn("px-2 py-1 text-right tabular-nums", i === bracketIdx ? "font-semibold text-accent-blue" : "text-text-secondary")}>
                            ×{v.toFixed(2)}
                          </td>
                        ))}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          <p className="mt-4 text-sm leading-relaxed text-text-muted">
            Figures are illustrative. Real expenses vary with lifestyle, location, and individual choices.
          </p>
        </div>
      </details>
    </div>
  );
}
