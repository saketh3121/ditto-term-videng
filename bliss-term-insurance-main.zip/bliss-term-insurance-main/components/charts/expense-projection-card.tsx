"use client";

import { useMemo } from "react";
import { Bar, BarChart, CartesianGrid, LabelList, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { formatRupees } from "@/lib/calc/cover";
import type { MilestoneKey } from "@/config/milestone-assumptions";
import type { ProjectExpensesResult } from "@/lib/calc/expense-projection";

/**
 * Year-by-year stacked expense outlook. Presentational, token-driven.
 * Directly reflects whichever milestones are checked in the Milestone
 * Inputs panel above — no separate chart-mode picker; when nothing's
 * checked it's plain inflation on the base expense. Each included
 * milestone gets its own stacked colour (its incremental step-up over the
 * previous cumulative milestone, not a single lumped "milestones" delta),
 * so a marriage top-up reads distinctly from a first-child top-up.
 */

const COLORS = {
  base: "var(--chart-base)",
  grid: "var(--chart-grid)",
  axis: "var(--chart-tick)",
};

const MILESTONE_COLORS: Record<MilestoneKey, string> = {
  marriage: "var(--chart-milestone-marriage)",
  firstChild: "var(--chart-milestone-first-child)",
  secondChild: "var(--chart-milestone-second-child)",
};

interface MilestoneStep {
  key: MilestoneKey;
  label: string;
  projection: ProjectExpensesResult;
}

/** `delta_<milestoneKey>` fields are added dynamically, one per included
 * milestone — flat string keys so Recharts' `<Bar dataKey="...">` can read
 * them directly (a function-based dataKey isn't reliable with stacking). */
type LayeredRow = {
  age: number;
  baseMonthly: number;
  showValueLabel: boolean;
  milestoneLabel: string;
  deltas: Partial<Record<MilestoneKey, number>>;
} & Partial<Record<`delta_${MilestoneKey}`, number>>;

function deltaKey(key: MilestoneKey): `delta_${MilestoneKey}` {
  return `delta_${key}`;
}

interface ExpenseProjectionCardProps {
  baseProjection?: ProjectExpensesResult;
  milestoneSteps?: MilestoneStep[];
  milestoneLabelsByAge?: Record<number, string>;
  heading?: string;
  inflationRate?: number;
  onSeeCover?: () => void;
  onBack?: () => void;
  backLabel?: string;
}

export function ExpenseProjectionCard({
  baseProjection,
  milestoneSteps = [],
  milestoneLabelsByAge = {},
  heading = "Year-by-year expense outlook",
  inflationRate,
  onSeeCover,
  onBack,
  backLabel = "Back to ideal tenure",
}: ExpenseProjectionCardProps) {
  const endAge = baseProjection?.endAge;
  const hasMilestones = milestoneSteps.length > 0;

  const layeredRows: LayeredRow[] = useMemo(() => {
    const rows: LayeredRow[] = (baseProjection?.rows ?? []).map((r, i) => ({
      age: r.age,
      baseMonthly: r.monthly,
      showValueLabel: i % 5 === 0,
      milestoneLabel: milestoneLabelsByAge[r.age] ?? "",
      deltas: {},
    }));
    const rowByAge = new Map(rows.map((r) => [r.age, r]));

    let prevByAge = new Map((baseProjection?.rows ?? []).map((r) => [r.age, r.monthly]));
    for (const step of milestoneSteps) {
      for (const r of step.projection.rows) {
        const row = rowByAge.get(r.age);
        if (!row) continue;
        const prevMonthly = prevByAge.get(r.age) ?? r.monthly;
        const delta = Math.max(0, r.monthly - prevMonthly);
        row.deltas[step.key] = delta;
        row[deltaKey(step.key)] = delta;
      }
      prevByAge = new Map(step.projection.rows.map((r) => [r.age, r.monthly]));
    }
    return rows;
  }, [baseProjection, milestoneSteps, milestoneLabelsByAge]);

  const topRadius: [number, number, number, number] = [3, 3, 0, 0];
  const flatRadius: [number, number, number, number] = [0, 0, 0, 0];

  const MS_LABEL_Y = 12;
  const VAL_LABEL_Y = 28;
  const renderBarLabel = (props: BarLabelRenderProps) => {
    const { x, y, width, height, payload, index } = props;
    const row = payload ?? (typeof index === "number" ? layeredRows[index] : undefined);
    const nx = Number(x);
    const ny = Number(y);
    const nWidth = Number(width);
    const nHeight = Number(height);
    if (!row || !Number.isFinite(nx) || !Number.isFinite(ny) || !Number.isFinite(nWidth) || !Number.isFinite(nHeight)) return null;
    const showVal = row.showValueLabel;
    const msText = row.milestoneLabel;
    if (!showVal && !msText) return null;

    const totalDelta = Object.values(row.deltas).reduce((sum, d) => sum + (d ?? 0), 0);
    const visibleTotal = row.baseMonthly + totalDelta;
    const cx = nx + nWidth / 2;
    const pxPerUnit = row.baseMonthly > 0 ? nHeight / row.baseMonthly : 0;
    const stackTopY = ny - pxPerUnit * totalDelta;
    const lineTopY = (showVal ? VAL_LABEL_Y : MS_LABEL_Y) + 4;
    const lineBottomY = Math.max(lineTopY, stackTopY - 2);

    return (
      <g>
        {msText && (
          <text x={cx} y={MS_LABEL_Y} textAnchor="middle" fontSize="10" fontWeight="600" fill="var(--chart-next-delta)">
            {msText}
          </text>
        )}
        {showVal && (
          <text x={cx} y={VAL_LABEL_Y} textAnchor="middle" fontSize="10" fontWeight="500" fill="var(--chart-label)">
            {formatRupees(visibleTotal)}
          </text>
        )}
        <line x1={cx} x2={cx} y1={lineTopY} y2={lineBottomY} stroke="var(--chart-leader)" strokeDasharray="2 3" strokeWidth="1" />
      </g>
    );
  };

  return (
    <Card className="mt-3 flex flex-col gap-6">
      <header className="min-w-0">
        <h3 className="text-lg font-semibold text-text-primary">{heading}</h3>
        <p className="mt-1 text-sm leading-relaxed text-text-secondary">
          {hasMilestones
            ? "Your expense across every milestone you've checked above, inflated annually through"
            : "Your average monthly expense per year, inflated annually through"}{" "}
          {endAge} (your ideal tenure end age).
        </p>
        {!hasMilestones && (
          <p className="mt-1 text-sm text-text-muted">
            No milestones checked yet — tick one above to see how it changes your expense over time.
          </p>
        )}
      </header>

      <div className="-mx-2 h-[340px] md:-mx-1">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={layeredRows} margin={{ top: 40, right: 16, left: 4, bottom: 8 }} barCategoryGap={2}>
            <CartesianGrid stroke={COLORS.grid} strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="age" tickLine={false} axisLine={{ stroke: COLORS.grid }} tick={{ fill: COLORS.axis, fontSize: 11 }} interval={4} height={28} />
            <YAxis tickFormatter={formatRupees} tickLine={false} axisLine={false} tick={{ fill: COLORS.axis, fontSize: 11 }} width={64} />
            <Tooltip
              content={<ChartTooltip milestoneSteps={milestoneSteps} inflationRate={inflationRate} />}
              cursor={{ fill: COLORS.grid, fillOpacity: 0.35 }}
            />
            <Bar
              dataKey="baseMonthly"
              stackId="exp"
              fill={COLORS.base}
              radius={hasMilestones ? flatRadius : topRadius}
              isAnimationActive={false}
            >
              <LabelList content={renderBarLabel} />
            </Bar>
            {milestoneSteps.map((step, i) => (
              <Bar
                key={step.key}
                dataKey={deltaKey(step.key)}
                name={step.label}
                stackId="exp"
                fill={MILESTONE_COLORS[step.key]}
                radius={i === milestoneSteps.length - 1 ? topRadius : flatRadius}
                isAnimationActive={false}
              />
            ))}
          </BarChart>
        </ResponsiveContainer>
      </div>

      {hasMilestones && (
        <div className="-mt-2 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-sm text-text-secondary">
          <LegendDot color={COLORS.base} label="Current expense growth" />
          {milestoneSteps.map((step) => (
            <LegendDot key={step.key} color={MILESTONE_COLORS[step.key]} label={step.label} />
          ))}
        </div>
      )}

      {(onBack || onSeeCover) && (
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border-default pt-4">
          {onBack ? (
            <Button variant="ghost" onClick={onBack}>
              ← {backLabel}
            </Button>
          ) : (
            <span />
          )}
          {onSeeCover ? <Button onClick={onSeeCover}>See your suggested cover →</Button> : <span />}
        </div>
      )}
    </Card>
  );
}

interface BarLabelRenderProps {
  x?: string | number | undefined;
  y?: string | number | undefined;
  width?: string | number | undefined;
  height?: string | number | undefined;
  payload?: LayeredRow | undefined;
  index?: number | undefined;
}

interface ChartTooltipProps {
  active?: boolean;
  payload?: Array<{ payload?: LayeredRow }>;
  label?: number | string;
  milestoneSteps?: MilestoneStep[];
  inflationRate?: number;
}

function ChartTooltip({ active, payload, label, milestoneSteps = [], inflationRate }: ChartTooltipProps) {
  if (!active || !payload?.length) return null;
  const row = payload[0]?.payload;
  if (!row) return null;
  const base = row.baseMonthly ?? 0;
  const totalDelta = Object.values(row.deltas).reduce((sum, d) => sum + (d ?? 0), 0);
  const visibleTotal = base + totalDelta;
  return (
    <div className="rounded-lg border border-border-default bg-bg-card/95 px-3 py-2 text-xs shadow-lg backdrop-blur">
      <p className="font-semibold text-text-primary">Age {label}</p>
      <div className="mt-1.5 space-y-0.5 tabular-nums text-text-secondary">
        <p>{formatRupees(visibleTotal)} / month</p>
        <p className="text-text-muted">≈ {formatRupees(visibleTotal * 12)} / year</p>
        {typeof inflationRate === "number" && (
          <p className="text-text-muted">Inflation: {(inflationRate * 100).toFixed(1)}%</p>
        )}
        {totalDelta > 0 && (
          <div className="mt-1 space-y-0.5 border-t border-border-subtle pt-1 text-[14px]">
            <p className="flex items-center gap-1.5">
              <span aria-hidden className="h-2 w-2 rounded-sm" style={{ background: COLORS.base }} /> Base {formatRupees(base)}
            </p>
            {milestoneSteps.map((step) => {
              const d = row.deltas[step.key];
              if (!d) return null;
              return (
                <p key={step.key} className="flex items-center gap-1.5">
                  <span aria-hidden className="h-2 w-2 rounded-sm" style={{ background: MILESTONE_COLORS[step.key] }} /> {step.label} +
                  {formatRupees(d)}
                </p>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function LegendDot({ color, label }: { color: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span aria-hidden className="h-2.5 w-2.5 rounded-sm" style={{ background: color }} />
      {label}
    </span>
  );
}
