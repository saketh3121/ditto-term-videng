import { Info } from "lucide-react";
import type { EligibilityCase } from "@/lib/max-eligibility";
import { renderBoldText } from "@/lib/rich-text";
import type { EligibilityComparisonCopy } from "@/types";

/**
 * The over/within callout plus the standing disclaimer below it, as one
 * highlighted tile rather than a bare footnote. 'under' deliberately reuses
 * the 'within' copy — a single "your cover is fine" message, not a distinct
 * under-eligible warning (a product decision carried over from the source
 * app, not an oversight).
 */

interface EligibilityComparisonNoteProps {
  eligibilityCase: EligibilityCase | null;
  copy: EligibilityComparisonCopy;
}

export function EligibilityComparisonNote({ eligibilityCase, copy }: EligibilityComparisonNoteProps) {
  if (!eligibilityCase) return null;
  const message = eligibilityCase === "over" ? copy.over : copy.within;
  // The disclaimer talks about topping up eligibility with multiple insurers
  // to reach the ideal amount — moot (and misleading) when the customer is
  // "over" (ineligible for the ideal amount even before stacking insurers).
  const showDisclaimer = eligibilityCase !== "over";
  return (
    <div className="flex items-start gap-3 rounded-xl border border-accent-blue-border bg-accent-blue-soft px-5 py-4">
      <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-accent-blue/15 text-accent-blue">
        <Info className="h-3.5 w-3.5" />
      </span>
      <div className="flex flex-col gap-2 text-sm leading-relaxed text-text-secondary">
        <p>{renderBoldText(message)}</p>
        {showDisclaimer && <p>{renderBoldText(copy.disclaimer)}</p>}
      </div>
    </div>
  );
}
