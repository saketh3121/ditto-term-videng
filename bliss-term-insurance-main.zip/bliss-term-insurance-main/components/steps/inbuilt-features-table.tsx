"use client";

import { Check, X } from "lucide-react";
import { AccordionSection } from "@/components/ui/accordion";
import { InfoModalButton } from "@/components/ui/modal";
import { AnnotatedText } from "@/components/ui/annotated-text";
import { parseDetailFields } from "@/lib/detail-fields";
import { policyById } from "@/lib/policies";
import type { Insurer, InbuiltFeatureCategory, InbuiltFeatureEntry } from "@/types";

/**
 * "Inbuilt Features" sub-page of Our Recommended Insurers: one collapsible
 * section per category, one column per currently-selected policy, one row
 * per feature, all centered. `categories` is expected pre-filtered via
 * lib/inbuilt-features.ts's visibleInbuiltFeatureCategories(policyIds) — a
 * feature row that's unavailable for every shown policy is dropped entirely
 * rather than rendered as an all-NA row.
 */

function FeatureCell({
  title,
  entry,
  naLabel,
}: {
  title: string;
  entry: InbuiltFeatureEntry | undefined;
  naLabel: string;
}) {
  if (!entry || !entry.available || !entry.mainContent) {
    return (
      <span
        title={naLabel}
        className="mx-auto inline-flex h-6 w-6 items-center justify-center rounded-full bg-bad/10 text-bad"
      >
        <X className="h-3.5 w-3.5" />
      </span>
    );
  }

  if (entry.mainContent.trim().toLowerCase() === "available") {
    return (
      <span className="mx-auto inline-flex h-6 w-6 items-center justify-center rounded-full bg-good/10 text-good">
        <Check className="h-3.5 w-3.5" strokeWidth={3} />
      </span>
    );
  }

  return (
    <span className="inline-flex items-start justify-center gap-1.5">
      <span className="text-text-secondary">
        <AnnotatedText text={entry.mainContent} />
      </span>
      {entry.detailText && (
        <span className="mt-0.5">
          <InfoModalButton payload={{ title, bullets: parseDetailFields(entry.detailText, title) }} />
        </span>
      )}
    </span>
  );
}

interface InbuiltFeaturesTableProps {
  categories: InbuiltFeatureCategory[];
  policyIds: string[];
  insurersById: Record<string, Insurer>;
  parametersLabel: string;
  naLabel: string;
  emptyNote: string;
  /** False when a page-level heading already labels the single category
   * shown (Riders' Others tab) — avoids repeating the same title twice.
   * Recommendations' Inbuilt Features tab has several categories and keeps
   * this true so each one stays labelled. */
  showCategoryTitles?: boolean;
}

function FeaturesTable({
  category,
  policyIds,
  insurersById,
  parametersLabel,
  naLabel,
}: {
  category: InbuiltFeatureCategory;
  policyIds: string[];
  insurersById: Record<string, Insurer>;
  parametersLabel: string;
  naLabel: string;
}) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[820px] border-collapse text-sm">
        <thead>
          <tr className="bg-bg-card-elevated text-center text-[14px] uppercase tracking-wider text-text-muted">
            <th className="w-64 px-6 py-3 font-bold">{parametersLabel}</th>
            {policyIds.map((id) => {
              const policy = policyById(id);
              const insurer = policy ? insurersById[policy.insurerId] : undefined;
              return (
                <th key={id} className="min-w-[240px] px-4 py-3 font-bold normal-case">
                  <div className="flex flex-col items-center gap-1.5">
                    {insurer && (
                      <img
                        src={insurer.logo}
                        alt=""
                        className="h-8 w-8 shrink-0 rounded-md bg-white object-contain p-1 ring-1 ring-border-default"
                      />
                    )}
                    <div className="flex flex-col items-center gap-0.5">
                      <span className="text-sm font-semibold text-text-primary">{policy?.name}</span>
                      <span className="text-[14px] uppercase tracking-wide text-text-muted">{insurer?.name}</span>
                    </div>
                  </div>
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody className="divide-y divide-border-subtle">
          {category.features.map((feature) => (
            <tr key={feature.id} className="hover:bg-bg-card-elevated/60">
              <td className="px-6 py-4 text-center align-middle font-medium text-text-primary">
                <AnnotatedText text={feature.title} />
              </td>
              {policyIds.map((id) => (
                <td key={id} className="px-4 py-4 text-center align-middle">
                  <FeatureCell title={feature.title} entry={feature.byPolicy[id]} naLabel={naLabel} />
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function InbuiltFeaturesTable({
  categories,
  policyIds,
  insurersById,
  parametersLabel,
  naLabel,
  emptyNote,
  showCategoryTitles = true,
}: InbuiltFeaturesTableProps) {
  if (policyIds.length === 0 || categories.length === 0) {
    return (
      <p className="rounded-card border border-border-default bg-bg-card p-6 text-sm text-text-muted">{emptyNote}</p>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      {categories.map((category) =>
        showCategoryTitles ? (
          <AccordionSection key={category.id} title={category.title} defaultOpen panelClassName="px-0 py-0">
            <FeaturesTable
              category={category}
              policyIds={policyIds}
              insurersById={insurersById}
              parametersLabel={parametersLabel}
              naLabel={naLabel}
            />
          </AccordionSection>
        ) : (
          <div key={category.id} className="overflow-hidden rounded-card border border-border-default bg-bg-card">
            <FeaturesTable
              category={category}
              policyIds={policyIds}
              insurersById={insurersById}
              parametersLabel={parametersLabel}
              naLabel={naLabel}
            />
          </div>
        ),
      )}
    </div>
  );
}
