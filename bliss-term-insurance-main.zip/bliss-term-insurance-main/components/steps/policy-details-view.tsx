"use client";

import { ArrowLeft } from "lucide-react";
import { categoryToNarrative } from "@/lib/policy-narrative";
import { AnnotatedText } from "@/components/ui/annotated-text";
import type { PolicyDetailsContent, PolicyDetailsPageCopy, Residency } from "@/types";

/**
 * In-place swap from the insurer comparison table: one flowing-text section
 * per category (in the content file's own order) — each item becomes a
 * paragraph led by its label, rather than a collapsible label/value grid.
 * NRI Guidelines only renders for NRI leads (residency comes from the
 * Control Panel via useFlow(), same source as everywhere else in the app —
 * not re-asked here).
 */

interface PolicyDetailsViewProps {
  policy: PolicyDetailsContent;
  policyName: string;
  insurerName: string;
  insurerLogo: string;
  copy: PolicyDetailsPageCopy;
  residency: Residency;
  onBack: () => void;
}

export function PolicyDetailsView({
  policy,
  policyName,
  insurerName,
  insurerLogo,
  copy,
  residency,
  onBack,
}: PolicyDetailsViewProps) {
  const categories = policy.categories.filter((c) => c.category !== "nri-guidelines" || residency === "nri");

  return (
    <div className="flex flex-col gap-8">
      <button
        type="button"
        onClick={onBack}
        className="inline-flex w-fit cursor-pointer items-center gap-1.5 text-sm font-semibold text-text-muted transition-colors hover:text-text-primary"
      >
        <ArrowLeft className="h-3.5 w-3.5" />
        {copy.backLabel}
      </button>

      <div className="flex items-center gap-3">
        <img
          src={insurerLogo}
          alt=""
          className="h-10 w-10 shrink-0 rounded-lg bg-white object-contain p-1.5 ring-1 ring-border-default"
        />
        <div>
          <p className="text-[14px] font-semibold uppercase tracking-wider text-accent-blue">{insurerName}</p>
          <h2 className="text-xl font-bold text-text-primary">{policyName}</h2>
        </div>
      </div>

      <div className="flex flex-col gap-10">
        {categories.map((category) => {
          const paragraphs = categoryToNarrative(category);
          if (paragraphs.length === 0) return null;
          return (
            <section key={category.category} className="flex flex-col gap-3">
              <h3 className="text-base font-semibold text-text-primary">{copy.categoryLabels[category.category]}</h3>
              <div className="flex flex-col gap-3">
                {paragraphs.map((p) => (
                  <p key={p.label} className="text-[19px] leading-relaxed text-text-secondary">
                    <span className="font-semibold text-text-primary">
                      <AnnotatedText text={p.label} />:{" "}
                    </span>
                    <AnnotatedText text={p.text} />
                  </p>
                ))}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}
