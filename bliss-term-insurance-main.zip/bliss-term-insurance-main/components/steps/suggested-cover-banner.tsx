import { RupeeAmount } from "@/components/ui/rupee-amount";

/**
 * The dark-navy "Suggested Cover" spotlight — split out of IdealCoverPanel
 * so Basic mode can pair it with the Expense Projection chart instead of
 * the insurer-wise max eligibility list (see cover-amount.tsx). Advanced
 * mode's IdealCoverPanel still renders this same banner next to its own
 * eligibility list. Fixed dark-navy gradient (bg-gradient-hero), not the
 * page's light/dark-reactive surface, so its text colors are hardcoded
 * white/white-opacity rather than the usual text-primary/secondary/muted
 * tokens.
 */

export interface SuggestedCoverBannerProps {
  suggestedCoverLabel: string;
  adjustedLabel: string;
  purchaseNowLabel: string;
  purchaseNowAmount: number;
  secondaryLabel: string;
  secondaryValue: string;
  baseCoverLabel: string;
  baseCoverAmount: number;
  loansLabel: string;
  loansAmount: number;
  existingCoverLabel: string;
  existingCoverAmount: number;
  /** False before the advisor has entered a monthly expense — the cover figures are meaningless zeros until then, so an empty-state message replaces them instead. */
  hasData: boolean;
  emptyStateMessage: string;
}

export function SuggestedCoverBanner({
  suggestedCoverLabel,
  adjustedLabel,
  purchaseNowLabel,
  purchaseNowAmount,
  secondaryLabel,
  secondaryValue,
  baseCoverLabel,
  baseCoverAmount,
  loansLabel,
  loansAmount,
  existingCoverLabel,
  existingCoverAmount,
  hasData,
  emptyStateMessage,
}: SuggestedCoverBannerProps) {
  return (
    <div className="rounded-2xl border border-white/10 bg-gradient-hero p-6">
      {hasData ? (
        <>
          <p className="text-[14px] font-semibold uppercase tracking-wider text-white/60">{suggestedCoverLabel}</p>
          <RupeeAmount amount={baseCoverAmount} className="mt-1 block text-4xl font-semibold text-white" />

          <div className="mt-5 rounded-xl border border-white/10 bg-white/5 p-4">
            <p className="mb-2 text-[14px] font-semibold uppercase tracking-wider text-white/60">{adjustedLabel}</p>
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between text-sm">
                <span className="text-white/70">{baseCoverLabel}</span>
                <RupeeAmount amount={baseCoverAmount} prefix="+" className="text-white" />
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-white/70">{loansLabel}</span>
                <RupeeAmount amount={loansAmount} prefix="+" className="text-white" />
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-white/70">{existingCoverLabel}</span>
                <RupeeAmount amount={existingCoverAmount} prefix="-" className="text-white" />
              </div>
            </div>

            <div className="mt-3 border-t border-white/10 pt-3">
              <p className="text-[14px] font-semibold uppercase tracking-wider text-white/60">{purchaseNowLabel}</p>
              <RupeeAmount amount={purchaseNowAmount} className="mt-1 block text-2xl font-semibold text-accent-sky" />
            </div>

            <div className="mt-3 border-t border-white/10 pt-3">
              <p className="text-[14px] font-semibold uppercase tracking-wider text-white/60">{secondaryLabel}</p>
              <p className="mt-1 text-lg font-bold text-white">{secondaryValue}</p>
            </div>
          </div>
        </>
      ) : (
        <div className="flex min-h-[220px] flex-col items-center justify-center text-center">
          <p className="text-[14px] font-semibold uppercase tracking-wider text-white/60">{suggestedCoverLabel}</p>
          <p className="mt-3 max-w-[28ch] text-sm text-white/70">{emptyStateMessage}</p>
        </div>
      )}
    </div>
  );
}
