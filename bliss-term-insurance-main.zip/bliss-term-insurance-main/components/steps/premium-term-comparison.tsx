"use client";

import { Card } from "@/components/ui/card";
import { useFlow } from "@/context/flow-provider";

/**
 * "How long you pay" — a single illustration contrasting Regular Pay
 * (premiums every year for the full tenure) with Limited Pay (premiums stop
 * early, cover continues to maturity). Asset is gender-matched, same
 * convention as RiderIllustrationTile: public/illustrations/
 * PaymentTerm_{F|M}.png. DARK MODE ARCHIVED — the -dark variant this
 * component used to switch to is no longer selected; see
 * docs/DARK_MODE_ARCHIVE.md.
 */
export function PremiumTermComparison({ intro }: { intro: string }) {
  const { customer } = useFlow();

  const genderSuffix = customer.gender === "female" ? "F" : "M";
  const src = `/illustrations/PaymentTerm_${genderSuffix}.png`;

  return (
    <div className="flex flex-col gap-3">
      <p className="max-w-[640px] text-sm leading-relaxed text-text-secondary">{intro}</p>
      <Card className="flex flex-col items-center gap-0 p-4">
        <img
          src={src}
          alt="Regular Pay: premiums are paid every year for the full policy tenure, with cover valid for the entire tenure. Limited Pay: premiums are paid for only a limited number of years, while cover continues all the way to maturity."
          className="h-auto w-full max-w-[1000px]"
          draggable={false}
        />
      </Card>
    </div>
  );
}
