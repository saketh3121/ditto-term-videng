"use client";

import { useEffect, useMemo, useState } from "react";
import { useSession } from "next-auth/react";
import { CoverProjectionChart } from "@/components/charts/cover-projection-chart";
import { ExpenseProjectionAssumptions } from "@/components/charts/expense-projection-assumptions";
import { ExpenseProjectionCard } from "@/components/charts/expense-projection-card";
import { MilestoneInputsPanel, type PersonalGoalsState } from "@/components/charts/milestone-inputs-panel";
import { EligibilityComparisonNote } from "@/components/max-eligibility";
import { IdealCoverPanel } from "@/components/steps/ideal-cover-panel";
import { ProfileSummaryBanner } from "@/components/steps/profile-summary-banner";
import { SuggestedCoverBanner } from "@/components/steps/suggested-cover-banner";
import { Segmented } from "@/components/ui/segmented";
import {
  DEFAULT_INFLATION_RATE,
  DEFAULT_MILESTONE_AGES,
  MILESTONES,
  MILESTONE_MULTIPLIERS,
  type IncludedMilestones,
  type MilestoneAges,
  type MilestoneKey,
  type Tier,
} from "@/config/milestone-assumptions";
import { useFlow } from "@/context/flow-provider";
import { computeBasicCoverSummary, roundUpToCoverUnit, sampleProjectionByInterval } from "@/lib/calc/cover";
import { computeIdealCover, projectExpenses, type MilestoneOverlay } from "@/lib/calc/expense-projection";
import {
  computeIdealTenureEndAge,
  defaultIncludedFromAge,
  effectiveMilestoneAge,
  incomeBracketIndex,
} from "@/lib/calc/milestone-expense-projection";
import { classifyCoverVsEligibilityRange, computeMaxEligibilityRange } from "@/lib/max-eligibility";
import type { CoverAmountContent } from "@/types";

/**
 * Cover Amount step. Age, annual income, and monthly expense come from the
 * shared Control Panel data (useFlow()) — not re-collected here, so the
 * advisor never enters them twice.
 *
 * Toggles between Basic (flat-inflation cover.ts engine) and Advanced
 * (life-stage-aware milestone/NPV engine). The Basic/Advanced Segmented
 * control only renders for signed-in advisors with role "admin" — everyone
 * else stays permanently on Basic, same as when Advanced was fully archived.
 */

type Mode = "basic" | "advanced";
const AGE_MIN = 18;
const AGE_MAX = 65;
const clampAge = (n: number) => Math.max(AGE_MIN, Math.min(AGE_MAX, n));

export function CoverAmountStep({ content }: { content: CoverAmountContent }) {
  const { age, customer, residency } = useFlow();
  const safeAge = clampAge(age ?? 30);
  const monthlyExpense = Number(customer.monthlyExpenses) || 0;
  const annualIncome = Number(customer.annualIncome) || 0;

  const { data: session } = useSession();
  const isAdmin = session?.user?.role === "admin";
  const [mode, setMode] = useState<Mode>("basic");

  const targetAge = Number(customer.preferredCoverAge) || undefined;
  const uninsuredLoans = Number(customer.uninsuredLoans) || 0;
  const existingCover = Number(customer.existingCoverAmount) || 0;
  const basic = useMemo(
    () => computeBasicCoverSummary({ age: safeAge, monthlyExpense, targetAge, uninsuredLoans, existingCover }),
    [safeAge, monthlyExpense, targetAge, uninsuredLoans, existingCover],
  );

  const [tier, setTier] = useState<Tier>("tier1");
  const [inflationRate, setInflationRate] = useState<number>(DEFAULT_INFLATION_RATE);
  const [customMilestoneAges, setCustomMilestoneAges] = useState<MilestoneAges>({ ...DEFAULT_MILESTONE_AGES });
  const setCustomMilestoneAge = (key: MilestoneKey, milestoneAge: number) =>
    setCustomMilestoneAges((prev) => ({ ...prev, [key]: milestoneAge }));

  const [includedMilestones, setIncludedMilestones] = useState<IncludedMilestones>(() =>
    defaultIncludedFromAge(safeAge, customMilestoneAges),
  );
  // defaultIncludedFromAge is documented to "re-evaluate each time the
  // user's current age changes" — the useState initializer above only ever
  // runs once, at mount, when age is often still null (pre-DOB fallback of
  // 30). Re-run it once the advisor's real age loads so the auto-checked
  // milestone reflects the actual customer, not whoever was assumed at mount.
  // Deliberately keyed on safeAge only — a custom milestone-age edit
  // shouldn't reset the advisor's manual include/exclude toggles.
  useEffect(() => {
    setIncludedMilestones(defaultIncludedFromAge(safeAge, customMilestoneAges));
  }, [safeAge]);
  const toggleMilestone = (key: MilestoneKey, value: boolean) =>
    setIncludedMilestones((prev) => {
      const next = { ...prev, [key]: value };
      if (key === "firstChild" && value === false) next.secondChild = false;
      if (key === "secondChild" && value === true && prev.firstChild === false) return prev;
      return next;
    });

  const [personalGoals, setPersonalGoals] = useState<PersonalGoalsState>({ included: false, age: null });

  // Mirrors Basic mode's targetAge fix: the milestone/NPV horizon (chart
  // window, milestone cutoff, death-age scenarios, and computeIdealCover's
  // horizonEndAge) follows the Control Panel's "Cover until" age when set,
  // instead of a fixed rolling 30-year window disconnected from it.
  const projectionEndAge =
    typeof targetAge === "number" && Number.isFinite(targetAge) && targetAge > safeAge
      ? targetAge
      : safeAge + 30;

  const checkedFutureMilestonesWithKeys = useMemo(() => {
    const bracket = incomeBracketIndex(annualIncome);
    const multTable = MILESTONE_MULTIPLIERS[tier] ?? MILESTONE_MULTIPLIERS.tier1;
    return MILESTONES.map((m) => ({
      key: m.key,
      label: m.label,
      age: effectiveMilestoneAge(m.key, customMilestoneAges),
      multiplier: multTable[m.key][bracket],
    }))
      .filter((m) => m.age > safeAge && m.age <= projectionEndAge && includedMilestones[m.key] !== false)
      .sort((a, b) => a.age - b.age);
  }, [annualIncome, tier, customMilestoneAges, includedMilestones, safeAge, projectionEndAge]);

  const checkedFutureMilestones: MilestoneOverlay[] = useMemo(
    () => checkedFutureMilestonesWithKeys.map(({ age: milestoneAge, multiplier }) => ({ age: milestoneAge, multiplier })),
    [checkedFutureMilestonesWithKeys],
  );

  const activeMilestonesForAssumptions = useMemo(
    () => checkedFutureMilestonesWithKeys.map((m) => ({ ...m, type: "milestone" as const })),
    [checkedFutureMilestonesWithKeys],
  );

  const baseProjection = useMemo(
    () => projectExpenses({ currentAge: safeAge, monthlyExpense, endAge: projectionEndAge, milestones: [], inflationRate }),
    [safeAge, monthlyExpense, projectionEndAge, inflationRate],
  );

  // One cumulative projection per included milestone, in the order each
  // fires — lets the Year-by-year chart attribute each milestone's own
  // incremental step-up to a distinct stacked colour instead of one lumped
  // "milestones" delta.
  const milestoneSteps = useMemo(() => {
    const steps: { key: MilestoneKey; label: string; projection: ReturnType<typeof projectExpenses> }[] = [];
    let cumulative: MilestoneOverlay[] = [];
    for (const m of checkedFutureMilestonesWithKeys) {
      cumulative = [...cumulative, { age: m.age, multiplier: m.multiplier }];
      steps.push({
        key: m.key,
        label: m.label,
        projection: projectExpenses({
          currentAge: safeAge,
          monthlyExpense,
          endAge: projectionEndAge,
          milestones: cumulative,
          inflationRate,
        }),
      });
    }
    return steps;
  }, [checkedFutureMilestonesWithKeys, safeAge, monthlyExpense, projectionEndAge, inflationRate]);

  const scenarioAges = useMemo(() => {
    const ages: number[] = [];
    for (let a = safeAge; a <= projectionEndAge; a++) ages.push(a);
    return ages;
  }, [safeAge, projectionEndAge]);

  const idealCoverRaw = useMemo(
    () =>
      computeIdealCover({
        currentAge: safeAge,
        monthlyExpense,
        horizonEndAge: projectionEndAge,
        milestones: checkedFutureMilestones,
        scenarioAges,
        inflationRate, // discountRate deliberately NOT passed — stays fixed at 5%, see SPEC.md §8
      }),
    [safeAge, monthlyExpense, projectionEndAge, checkedFutureMilestones, scenarioAges, inflationRate],
  );
  const idealCover = roundUpToCoverUnit(idealCoverRaw);
  const loanAmount = basic.loansRounded;
  const existingCoverRounded = basic.existingRounded;
  const purchaseNow = Math.max(0, idealCover + loanAmount - existingCoverRounded);
  const basicPurchaseNow = basic.purchaseNow;

  const idealTenure = useMemo(
    () => computeIdealTenureEndAge(includedMilestones, customMilestoneAges, Number(customer.preferredCoverAge) || undefined),
    [includedMilestones, customMilestoneAges, customer.preferredCoverAge],
  );

  // What the customer actually needs to be eligible FOR — and what each
  // insurer's max-eligibility row should be judged "below" — is the adjusted
  // purchase-now figure (suggested cover + uninsured loans - existing cover),
  // not the pre-adjustment suggested/ideal cover.
  const activePurchaseNow = mode === "basic" ? basicPurchaseNow : purchaseNow;
  const maxEligibilityRange = useMemo(
    () => computeMaxEligibilityRange({ age: safeAge, annualIncome, residency }),
    [safeAge, annualIncome, residency],
  );
  // Before a monthly expense is entered, activePurchaseNow is a meaningless
  // near-zero figure — classifying it against the eligibility range would
  // surface a misleading "your cover is fine" note for data that isn't real.
  const eligibilityCase = useMemo(
    () => (monthlyExpense > 0 ? classifyCoverVsEligibilityRange(activePurchaseNow, maxEligibilityRange) : null),
    [monthlyExpense, activePurchaseNow, maxEligibilityRange],
  );

  return (
    <div className="flex flex-col gap-8">
      <ProfileSummaryBanner content={content.banner} uninsuredLoans={loanAmount} />

      {isAdmin && (
        <Segmented
          value={mode}
          options={[
            { value: "basic", label: "Basic" },
            { value: "advanced", label: "Advanced" },
          ]}
          onChange={(v) => setMode(v as Mode)}
          className="max-w-xs"
        />
      )}

      {mode === "basic" ? (
        <div className="flex flex-col gap-6">
          <h3 className="text-lg font-semibold text-text-primary">{content.howMuchCoverHeading}</h3>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-[1.3fr_1fr]">
            <CoverProjectionChart
              projection={sampleProjectionByInterval(basic.projection, 10)}
              heading={content.projectionChartHeading}
              inflationRate={DEFAULT_INFLATION_RATE}
            />
            <SuggestedCoverBanner
              purchaseNowLabel={content.purchaseNowLabel}
              purchaseNowAmount={basicPurchaseNow}
              secondaryLabel={content.policyTermLabel}
              secondaryValue={`${basic.termYears} ${content.policyTermUnit}`}
              suggestedCoverLabel={content.suggestedCoverLabel}
              adjustedLabel={content.adjustedLabel}
              baseCoverLabel={content.baseCoverLabel}
              baseCoverAmount={basic.coverAmount}
              loansLabel={content.loansLabel}
              loansAmount={loanAmount}
              existingCoverLabel={content.existingCoverLabel}
              existingCoverAmount={existingCoverRounded}
              hasData={monthlyExpense > 0}
              emptyStateMessage={content.emptyStateMessage}
            />
          </div>
        </div>
      ) : (
        <div className="flex flex-col gap-6">
          <p className="text-sm text-text-secondary">{content.advancedIntro}</p>

          <h3 className="text-lg font-semibold text-text-primary">{content.howMuchCoverHeading}</h3>
          <IdealCoverPanel
            range={maxEligibilityRange}
            suggestedCover={activePurchaseNow}
            eligibilityHeading={content.eligibilityTableHeading}
            eligibilityCaption={content.eligibilityTableCaption}
            belowSuggestedLabel={content.eligibilityBelowSuggestedLabel}
            purchaseNowLabel={content.purchaseNowLabel}
            purchaseNowAmount={purchaseNow}
            secondaryLabel={content.idealTenureLabel}
            secondaryValue={`${idealTenure.min}–${idealTenure.max} ${content.idealTenureUnit}`}
            suggestedCoverLabel={content.suggestedCoverLabel}
            adjustedLabel={content.adjustedLabel}
            baseCoverLabel={content.baseCoverLabel}
            baseCoverAmount={idealCover}
            loansLabel={content.loansLabel}
            loansAmount={loanAmount}
            existingCoverLabel={content.existingCoverLabel}
            existingCoverAmount={existingCoverRounded}
            hasData={monthlyExpense > 0}
            emptyStateMessage={content.emptyStateMessage}
          />

          <Segmented
            value={tier}
            options={[
              { value: "tier1", label: "Metro" },
              { value: "tier2", label: "Non-metro" },
            ]}
            onChange={(v) => setTier(v as Tier)}
            className="max-w-xs"
          />

          <MilestoneInputsPanel
            currentAge={safeAge}
            includedMilestones={includedMilestones}
            onToggleMilestone={toggleMilestone}
            personalGoals={personalGoals}
            onPersonalGoalsChange={setPersonalGoals}
            customMilestoneAges={customMilestoneAges}
            onCustomMilestoneAgeChange={setCustomMilestoneAge}
          />

          <ExpenseProjectionCard
            baseProjection={baseProjection}
            milestoneSteps={milestoneSteps}
            heading={content.projectionChartHeading}
            inflationRate={inflationRate}
          />

          <ExpenseProjectionAssumptions
            currentAge={safeAge}
            annualIncome={annualIncome}
            tier={tier}
            inflationRate={inflationRate}
            onInflationRateChange={setInflationRate}
            includedMilestones={includedMilestones}
            activeMilestones={activeMilestonesForAssumptions}
            customMilestoneAges={customMilestoneAges}
          />
        </div>
      )}

      <EligibilityComparisonNote eligibilityCase={eligibilityCase} copy={content.eligibilityComparison} />
    </div>
  );
}
