import { AccordionSection } from "@/components/ui/accordion";
import type { IllnessList } from "@/types";

/**
 * One WOP or CI section of a Specific Illnesses policy page: a heading plus
 * one collapsible block per illness-list tier (a policy can carry several,
 * e.g. Bajaj's 10/25/60-illness CI tiers). Every block opens by default —
 * with only the first block open, a WOP section's own (often lower) tier
 * count sat collapsed while the CI section's first block sat open directly
 * below it, making WOP's list look like it had the CI section's count
 * instead of its own. Users can still collapse tiers they don't need.
 */
export function IllnessListSection({
  id,
  heading,
  lists,
  emptyNote,
}: {
  id: string;
  heading: string;
  lists: IllnessList[];
  emptyNote: string;
}) {
  return (
    <section id={id} className="flex scroll-mt-24 flex-col gap-4">
      <h2 className="text-xl font-bold text-text-primary">{heading}</h2>
      {lists.length === 0 ? (
        <p className="rounded-card border border-border-default bg-bg-card p-6 text-sm text-text-muted">{emptyNote}</p>
      ) : (
        <div className="flex flex-col gap-3">
          {lists.map((list, i) => (
            <AccordionSection key={`${list.heading}-${i}`} title={list.heading} defaultOpen>
              {list.items.length > 0 && (
                <ul className="grid list-inside list-disc grid-cols-1 gap-x-6 gap-y-1.5 text-sm leading-relaxed text-text-secondary marker:text-text-muted sm:grid-cols-2">
                  {list.items.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              )}
            </AccordionSection>
          ))}
        </div>
      )}
    </section>
  );
}
