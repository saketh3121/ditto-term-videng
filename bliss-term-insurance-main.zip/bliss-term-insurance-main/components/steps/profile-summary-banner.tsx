"use client";

import { Pencil, TriangleAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { TENURE_WARNING_AGE } from "@/config/milestone-assumptions";
import { useFlow } from "@/context/flow-provider";
import { formatRupees } from "@/lib/calc/cover";
import type { ProfileSummaryBannerContent } from "@/types";

/**
 * Profile snapshot shown atop the cover-amount step: who we're advising, and
 * what we know so far. Chosen tenure is derived as preferred cover age minus
 * current age, with that preferred age itself appended for context; existing
 * cover and uninsured loans come straight from the Control Panel.
 */

interface ProfileSummaryBannerProps {
  content: ProfileSummaryBannerContent;
  uninsuredLoans: number;
}

function Stat({ label, value, warning }: { label: string; value: string; warning?: string }) {
  return (
    <div className="flex items-baseline justify-between gap-3 py-1.5">
      <span className="text-sm font-semibold text-text-muted">{label}</span>
      <span className="flex items-baseline gap-1.5 text-right">
        <span className="text-sm font-medium text-text-primary">{value}</span>
        {warning && (
          <span className="inline-flex items-center gap-1 text-xs font-medium text-warning" title={warning}>
            <TriangleAlert className="h-3 w-3 shrink-0" />
            {warning}
          </span>
        )}
      </span>
    </div>
  );
}

export function ProfileSummaryBanner({ content, uninsuredLoans }: ProfileSummaryBannerProps) {
  const { customer, age, residency, setActivePanel } = useFlow();
  const name = customer.name.trim() || content.namePlaceholder;
  const na = content.notAvailable;

  const preferredCoverAge = Number(customer.preferredCoverAge);
  const chosenTenure =
    age !== null && Number.isFinite(preferredCoverAge) && preferredCoverAge > age
      ? preferredCoverAge - age
      : null;
  const chosenTenureValue = chosenTenure !== null ? `${chosenTenure} ${content.ageUnit}` : na;
  const chosenTenureHeading =
    chosenTenure !== null
      ? `${content.chosenTenureLabel} ${content.chosenTenureUpToTemplate.replace("{age}", String(preferredCoverAge))}`
      : content.chosenTenureLabel;
  const tenureIsUnusuallyLong = chosenTenure !== null && preferredCoverAge >= TENURE_WARNING_AGE;

  return (
    <Card className="flex flex-col gap-5">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="bg-gradient-avatar inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-base font-bold text-white">
            {name.charAt(0).toUpperCase()}
          </div>
          <span className="text-base font-semibold text-text-primary">
            {name}
            {content.profileHeadingSuffix}
          </span>
        </div>
        <Button variant="ghost" size="md" onClick={() => setActivePanel("control")}>
          <Pencil className="h-3.5 w-3.5" /> {content.editLabel}
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-x-8 border-t border-border-default pt-4 sm:grid-cols-2">
        <div className="flex flex-col divide-y divide-border-subtle">
          <Stat label={content.ageLabel} value={age !== null ? `${age} ${content.ageUnit}` : na} />
          <Stat
            label={content.monthlyExpensesLabel}
            value={customer.monthlyExpenses ? formatRupees(Number(customer.monthlyExpenses)) : na}
          />
          <Stat label={content.tobaccoLabel} value={customer.tobaccoUser ? content.tobaccoYes : content.tobaccoNo} />
          <Stat
            label={content.existingCoverLabel}
            value={Number(customer.existingCoverAmount) > 0 ? formatRupees(Number(customer.existingCoverAmount)) : na}
          />
        </div>
        <div className="flex flex-col divide-y divide-border-subtle">
          <Stat
            label={content.annualIncomeLabel}
            value={customer.annualIncome ? formatRupees(Number(customer.annualIncome)) : na}
          />
          <Stat label={content.residencyLabel} value={residency === "nri" ? content.nriValue : content.residentValue} />
          <Stat
            label={chosenTenureHeading}
            value={chosenTenureValue}
            warning={tenureIsUnusuallyLong ? content.chosenTenureWarning : undefined}
          />
          <Stat
            label={content.uninsuredLoansLabel}
            value={uninsuredLoans > 0 ? formatRupees(uninsuredLoans) : na}
          />
        </div>
      </div>
    </Card>
  );
}
