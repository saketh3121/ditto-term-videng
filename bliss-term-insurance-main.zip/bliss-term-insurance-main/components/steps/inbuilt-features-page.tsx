"use client";

import { InbuiltFeaturesTable } from "@/components/steps/inbuilt-features-table";
import { useFlow } from "@/context/flow-provider";
import { visibleInbuiltFeatureCategories } from "@/lib/inbuilt-features";
import type { Insurer, InbuiltFeaturesPageContent } from "@/types";

/**
 * Resources > Inbuilt Features. Split out of the Recommendations step so it
 * lives under its own Resources nav section rather than behind a tab —
 * reads the same selected-policies flow state either way.
 */
export function InbuiltFeaturesPage({
  content,
  insurersById,
}: {
  content: InbuiltFeaturesPageContent;
  insurersById: Record<string, Insurer>;
}) {
  const { selectedPolicies } = useFlow();

  return (
    <InbuiltFeaturesTable
      categories={visibleInbuiltFeatureCategories(selectedPolicies)}
      policyIds={selectedPolicies}
      insurersById={insurersById}
      parametersLabel={content.parametersLabel}
      naLabel={content.naLabel}
      emptyNote={content.emptyNote}
    />
  );
}
