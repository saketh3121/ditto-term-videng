import { cn } from "@/lib/utils";
import type { LinkedInReview } from "@/types";

/** A single LinkedIn testimonial, shown in full — no truncation or "Read more" toggle. */
export function ReviewCard({ review, className }: { review: LinkedInReview; className?: string }) {
  const { customerName, mediumLink, review: body } = review;

  return (
    <a
      href={mediumLink}
      target="_blank"
      rel="noopener noreferrer"
      className={cn(
        "block rounded-card border border-accent-blue-border bg-accent-blue-soft p-6 transition-colors hover:border-accent-blue/50 focus:outline-none focus-visible:ring-2 focus-visible:ring-accent-blue",
        className,
      )}
    >
      <div className="flex items-start gap-4">
        <img src="/logos/linkedin.svg" alt="LinkedIn" className="h-12 w-12 shrink-0" />
        <div className="min-w-0 flex-1">
          <span className="font-semibold text-text-primary">{customerName}</span>
          <p className="mt-3 whitespace-pre-line text-sm leading-relaxed text-text-secondary">{body}</p>
        </div>
      </div>
    </a>
  );
}
