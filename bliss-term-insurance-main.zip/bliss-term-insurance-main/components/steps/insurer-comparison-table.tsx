import { selectedPoliciesForInsurer } from "@/lib/policies";
import { AnnotatedText } from "@/components/ui/annotated-text";
import type { Insurer, KeyMetric } from "@/types";

/**
 * Replaces the old one-chart-per-metric layout with a single dense
 * comparison table (one row per insurer, one column per key metric). The
 * insurer cell also lists whichever of the advisor's selected policies
 * belong to that insurer, as plain text (POLICY DETAILS LINK ARCHIVED —
 * these used to be clickable, swapping the step into the Policy Details
 * view; see recommendations.tsx for the dormant onViewPolicy wiring).
 *
 * Two of the four logo files have a mismatched extension vs their actual
 * format (bajaj.png is really AVIF, icici.png is really WebP) — plain
 * `<img>`, not next/image, until they're re-exported as their labeled
 * format (next/image's sharp pipeline may well handle them fine, but this
 * avoids depending on that).
 */

function metricValue(insurer: Insurer, metric: KeyMetric): string {
  if (metric.field === "annualBusinessCrore") return insurer.annualBusinessLabel;
  return `${insurer[metric.field]}${metric.columnSuffix}`;
}

interface InsurerComparisonTableProps {
  insurers: Insurer[];
  keyMetrics: KeyMetric[];
  insurerColumnLabel: string;
  selectedPolicyIds: string[];
  footnote?: string;
}

export function InsurerComparisonTable({
  insurers,
  keyMetrics,
  insurerColumnLabel,
  selectedPolicyIds,
  footnote,
}: InsurerComparisonTableProps) {
  return (
    <section className="overflow-hidden rounded-card border border-border-default bg-bg-card">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[820px] border-collapse text-sm">
          <thead>
            <tr className="bg-bg-card-elevated text-center text-[14px] uppercase tracking-wider text-text-muted">
              <th className="px-6 py-3 font-bold">{insurerColumnLabel}</th>
              {keyMetrics.map((m) => (
                <th key={m.field} className="px-4 py-3 font-bold">
                  <AnnotatedText text={m.columnHeader} />
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border-subtle">
            {insurers.map((insurer) => {
              const policies = selectedPoliciesForInsurer(insurer.id, selectedPolicyIds);
              return (
                <tr key={insurer.id} className="hover:bg-bg-card-elevated/60">
                  <td className="px-6 py-4 align-top">
                    <div className="flex items-start gap-3">
                      <img
                        src={insurer.logo}
                        alt=""
                        className="h-8 w-8 shrink-0 rounded-md bg-white object-contain p-1 ring-1 ring-border-default"
                      />
                      <div className="flex flex-col gap-1">
                        <div className="font-medium text-text-primary">{insurer.name}</div>
                        {policies.length > 0 && (
                          <ul className="mt-1.5 flex flex-col gap-1">
                            {policies.map((p) => (
                              <li key={p.id} className="text-xs font-medium text-text-secondary">
                                {p.name}
                              </li>
                            ))}
                          </ul>
                        )}
                      </div>
                    </div>
                  </td>
                  {keyMetrics.map((m) => (
                    <td key={m.field} className="px-4 py-4 text-center align-middle">
                      <div className="font-semibold tabular-nums text-text-primary">{metricValue(insurer, m)}</div>
                    </td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      {footnote && (
        <footer className="border-t border-border-subtle px-6 py-3 text-[14px] text-text-muted">{footnote}</footer>
      )}
    </section>
  );
}
