import { createElement } from "react";
import * as LucideIcons from "lucide-react";
import { CheckCircle2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import type { PayTermComparisonRow } from "@/types";

/**
 * Feature-by-feature Regular Pay vs Limited Pay breakdown. No per-row
 * verdict — the table leans toward Limited Pay wholesale, through the
 * column's own treatment (light-green wash, bolder text) rather than
 * picking a winner row by row. Cells themselves carry no checkmark; only
 * the column header keeps one, as the column's own identity badge.
 */

type IconComponent = React.ComponentType<{ className?: string }>;

function getIcon(name: string): IconComponent {
  const map = LucideIcons as unknown as Record<string, IconComponent>;
  return map[name] ?? LucideIcons.HelpCircle;
}

function RegularPayCell({ text }: { text: string }) {
  return (
    <div className="flex h-full flex-col justify-center rounded-xl border border-border-subtle p-3.5 text-sm leading-relaxed text-text-secondary">
      <span>{text}</span>
    </div>
  );
}

function LimitedPayCell({ text }: { text: string }) {
  return (
    <div className="flex h-full flex-col justify-center rounded-xl border border-good/35 bg-good/[0.07] p-3.5 text-sm leading-relaxed text-text-primary">
      <span className="font-medium">{text}</span>
    </div>
  );
}

export function PayTermComparisonTable({
  heading,
  regularLabel,
  limitedLabel,
  rows,
}: {
  heading: string;
  regularLabel: string;
  limitedLabel: string;
  rows: PayTermComparisonRow[];
}) {
  return (
    <Card className="flex flex-col gap-4">
      <h3 className="text-base font-semibold text-text-primary">{heading}</h3>

      <div className="grid grid-cols-1 gap-3 md:grid-cols-[minmax(180px,1fr)_1.3fr_1.3fr]">
        {/* Column headers — hidden on mobile, where each row stacks instead */}
        <div className="hidden md:block" />
        <div className="hidden items-center justify-center rounded-lg bg-hover-surface px-3 py-2 text-sm font-semibold text-text-secondary md:flex">
          {regularLabel}
        </div>
        <div className="hidden items-center justify-center gap-1.5 rounded-lg bg-good px-3 py-2 text-sm font-bold text-white shadow-sm md:flex">
          <CheckCircle2 className="h-3.5 w-3.5" strokeWidth={2.5} />
          {limitedLabel}
        </div>

        {rows.map((row) => (
          <div key={row.feature} className="contents">
            <div className="flex items-center gap-2.5 pt-1 md:pt-0">
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-hover-surface text-text-secondary">
                {createElement(getIcon(row.icon), { className: "h-4 w-4" })}
              </span>
              <span className="text-sm font-semibold text-text-primary">{row.feature}</span>
            </div>
            <RegularPayCell text={row.regularPay} />
            <LimitedPayCell text={row.limitedPay} />
          </div>
        ))}
      </div>
    </Card>
  );
}
