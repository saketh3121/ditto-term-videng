"use client";

import { useEffect, useState } from "react";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { ReviewCard } from "@/components/steps/review-card";
import { cn } from "@/lib/utils";
import type { LinkedInReview } from "@/types";

const AUTO_ROTATE_MS = 10_000;

/** Auto-rotates every 10s; pauses entirely while the pointer hovers anywhere over it. */
export function ReviewsCarousel({ reviews }: { reviews: LinkedInReview[] }) {
  const [activeIdx, setActiveIdx] = useState(0);
  const [paused, setPaused] = useState(false);
  const total = reviews.length;

  useEffect(() => {
    if (paused || total <= 1) return undefined;
    const id = setInterval(() => setActiveIdx((i) => (i + 1) % total), AUTO_ROTATE_MS);
    return () => clearInterval(id);
  }, [paused, total]);

  if (total === 0) return null;

  const goPrev = () => setActiveIdx((i) => (i - 1 + total) % total);
  const goNext = () => setActiveIdx((i) => (i + 1) % total);
  const review = reviews[activeIdx] ?? reviews[0]!;

  return (
    <div className="mt-3" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
      {/* Badge column = 1/3, review card spans 2/3 on desktop; stacks on mobile. */}
      <div className="grid grid-cols-1 gap-5 md:grid-cols-3 md:items-stretch">
        <div className="flex items-center justify-center">
          <img
            src="/illustrations/google-reviews-card.png"
            alt="Google customer reviews"
            className="max-h-40 w-auto object-contain"
            draggable={false}
          />
        </div>
        <ReviewCard review={review} className="md:col-span-2" />
      </div>

      <div className="mt-5 flex items-center justify-between">
        <button
          type="button"
          onClick={goPrev}
          aria-label="Previous review"
          className="inline-flex h-9 w-9 cursor-pointer items-center justify-center rounded-full border border-border-default bg-bg-card text-text-secondary transition-colors hover:bg-bg-card-elevated hover:text-text-primary"
        >
          <ArrowLeft className="h-4 w-4" />
        </button>

        <div className="flex items-center gap-1.5">
          {reviews.map((_, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setActiveIdx(i)}
              aria-label={`Show review ${i + 1}`}
              aria-current={i === activeIdx ? "true" : undefined}
              className={cn(
                "cursor-pointer rounded-full transition-all",
                i === activeIdx ? "h-1.5 w-5 bg-accent-blue" : "h-1.5 w-1.5 bg-border-default hover:bg-text-muted",
              )}
            />
          ))}
        </div>

        <button
          type="button"
          onClick={goNext}
          aria-label="Next review"
          className="inline-flex h-9 w-9 cursor-pointer items-center justify-center rounded-full border border-border-default bg-bg-card text-text-secondary transition-colors hover:bg-bg-card-elevated hover:text-text-primary"
        >
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
