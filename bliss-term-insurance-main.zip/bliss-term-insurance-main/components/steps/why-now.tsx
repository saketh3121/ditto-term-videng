import { createElement } from "react";
import * as LucideIcons from "lucide-react";
import type { WhyNowContent } from "@/types";

/**
 * Why Now Matters: a 2x2 grid of "reasons to buy now" cards using the same
 * hover-reveal mechanic as Profile's factor tiles / Why Ditto's pillars
 * (title only at rest, body fades in on hover/focus — see .profile-tile in
 * globals.css). Each card names its own icon (content-driven), unlike the
 * source app's position-matched icon array — a content edit that
 * adds/reorders a card without an icon now fails validate:content with a
 * named error instead of silently falling back to a generic icon.
 */

type IconComponent = React.ComponentType<{ className?: string; strokeWidth?: number }>;

function getIcon(name: string): IconComponent {
  const map = LucideIcons as unknown as Record<string, IconComponent>;
  return map[name] ?? LucideIcons.HelpCircle;
}

export function WhyNow({ content }: { content: WhyNowContent }) {
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
      {content.cards.map((card) => (
        <div
          key={card.title}
          tabIndex={0}
          className="profile-tile flex min-h-[168px] flex-col items-center justify-center gap-1.5 px-5 py-6 text-center outline-none focus-visible:ring-2 focus-visible:ring-accent-blue focus-visible:ring-offset-2"
        >
          <div className="relative z-10 flex flex-col items-center">
            <span className="mb-1.5 inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-[10px] bg-accent-blue-soft text-accent-blue">
              {createElement(getIcon(card.icon), { className: "h-5 w-5", strokeWidth: 1.5 })}
            </span>
            <h3 className="text-base font-semibold text-text-primary">{card.title}</h3>
            <p className="profile-tile__body text-sm leading-relaxed text-text-secondary">{card.body}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
