"use client";

import { createElement } from "react";
import * as LucideIcons from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import type { KeyMetric } from "@/types";

/**
 * One "Why these four metrics" tile. Hovering the trigger reveals the
 * definition; clicking it pins the popover open (Base UI's Popover.Trigger
 * `openOnHover` composes hover-reveal with its native click-toggle — no
 * extra pinning logic needed here).
 */

const METRIC_ICONS: Record<KeyMetric["field"], string> = {
  csr: "ShieldCheck",
  asr: "Wallet",
  complaintsPer10k: "MessageSquareWarning",
  annualBusinessCrore: "TrendingUp",
};

type IconComponent = React.ComponentType<{ className?: string; strokeWidth?: number }>;

function getIcon(name: string): IconComponent {
  const map = LucideIcons as unknown as Record<string, IconComponent>;
  return map[name] ?? LucideIcons.HelpCircle;
}

export function MetricLegendTile({ metric }: { metric: KeyMetric }) {
  const iconName = METRIC_ICONS[metric.field];

  return (
    <Popover>
      <PopoverTrigger
        openOnHover
        delay={150}
        className="flex w-full cursor-pointer items-center gap-3 rounded-card border border-border-default bg-bg-card p-5 text-left transition-colors hover:border-accent-blue/40"
      >
        <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-[10px] bg-accent-blue-soft text-accent-blue">
          {createElement(getIcon(iconName), { className: "h-4 w-4", strokeWidth: 1.5 })}
        </span>
        <span className="text-[19px] font-semibold text-text-primary">{metric.title}</span>
      </PopoverTrigger>
      <PopoverContent side="bottom" align="start">
        <p>{metric.description}</p>
      </PopoverContent>
    </Popover>
  );
}
