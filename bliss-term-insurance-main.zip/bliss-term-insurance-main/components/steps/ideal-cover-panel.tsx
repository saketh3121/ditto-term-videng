import { SuggestedCoverBanner, type SuggestedCoverBannerProps } from "@/components/steps/suggested-cover-banner";
import { Card } from "@/components/ui/card";
import { formatRupees } from "@/lib/calc/cover";
import { cn } from "@/lib/utils";
import type { MaxEligibilityRange } from "@/lib/max-eligibility";

/**
 * Two separate boxes side by side: insurer-wise max eligibility (left,
 * wider, plain surface) and the Suggested Cover banner (right, its own
 * box — see SuggestedCoverBanner). Only reachable via Advanced mode, which
 * is admin-only (see cover-amount.tsx); Basic mode pairs SuggestedCoverBanner
 * with the Expense Projection chart instead.
 */

interface IdealCoverPanelProps extends SuggestedCoverBannerProps {
  range: MaxEligibilityRange | null | undefined;
  suggestedCover: number;
  eligibilityHeading: string;
  eligibilityCaption: string;
  belowSuggestedLabel: string;
}

export function IdealCoverPanel({
  range,
  suggestedCover,
  eligibilityHeading,
  eligibilityCaption,
  belowSuggestedLabel,
  ...bannerProps
}: IdealCoverPanelProps) {
  const rows = range ? [...range.perInsurer].reverse() : [];

  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-[1.3fr_1fr]">
      <Card className="flex flex-col gap-3">
        <header className="flex items-baseline justify-between gap-3">
          <h3 className="text-base font-semibold text-text-primary">{eligibilityHeading}</h3>
          <p className="text-sm text-text-muted">{eligibilityCaption}</p>
        </header>
        {rows.length > 0 ? (
          <ul className="divide-y divide-border-subtle">
            {rows.map((p) => {
              const belowSuggested = suggestedCover > 0 && p.amount < suggestedCover;
              return (
                <li
                  key={p.brand}
                  className={cn(
                    "flex flex-wrap items-baseline gap-x-3 gap-y-1 px-1 py-2.5",
                    belowSuggested && "rounded-md bg-bad/5",
                  )}
                >
                  <div className="flex min-w-0 items-center gap-2.5">
                    {p.logo && (
                      <img
                        src={p.logo}
                        alt=""
                        className="h-6 w-6 shrink-0 rounded-md bg-white object-contain p-1 ring-1 ring-border-default"
                      />
                    )}
                    <span className="text-sm font-medium text-text-primary">{p.brand}</span>
                  </div>
                  <span className="text-sm font-semibold text-text-primary">{formatRupees(p.amount)}</span>
                  {belowSuggested && (
                    <span className="rounded-full bg-bad/10 px-2 py-0.5 text-[13px] font-semibold uppercase tracking-wider text-bad">
                      {belowSuggestedLabel}
                    </span>
                  )}
                </li>
              );
            })}
          </ul>
        ) : (
          <p className="text-sm text-text-muted">—</p>
        )}
      </Card>

      <SuggestedCoverBanner {...bannerProps} />
    </div>
  );
}
