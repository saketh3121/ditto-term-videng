import { PayTermComparisonTable } from "@/components/steps/pay-term-comparison-table";
import { PremiumFrequencyToggle } from "@/components/steps/premium-frequency-toggle";
import { PremiumTermComparison } from "@/components/steps/premium-term-comparison";
import type { PremiumOptionsContent } from "@/types";

/**
 * Premium Payment Options step: two scroll-anchored sections matching the
 * sidebar's sub-steps (content/flows.json) — "How often you pay" (frequency
 * toggle + month-strip animation) and "How long you pay" (Limited vs Regular
 * Pay comparison).
 */
export function PremiumOptions({ content }: { content: PremiumOptionsContent }) {
  return (
    <div className="flex flex-col gap-14">
      <section id="how-long" className="flex scroll-mt-24 flex-col gap-3">
        <h2 className="text-[28px] font-bold leading-[1.25] tracking-[-0.015em] text-text-primary">
          {content.howLongHeading}
        </h2>
        <PremiumTermComparison intro={content.howLongIntro} />
        <PayTermComparisonTable
          heading={content.payTermComparisonHeading}
          regularLabel={content.payTermComparisonRegularLabel}
          limitedLabel={content.payTermComparisonLimitedLabel}
          rows={content.payTermComparisonRows}
        />
      </section>

      <section id="how-often" className="flex scroll-mt-24 flex-col gap-3">
        <h2 className="text-[28px] font-bold leading-[1.25] tracking-[-0.015em] text-text-primary">
          {content.howOftenHeading}
        </h2>
        <PremiumFrequencyToggle intro={content.howOftenIntro} disclaimers={content.howOftenDisclaimers} />
      </section>
    </div>
  );
}
