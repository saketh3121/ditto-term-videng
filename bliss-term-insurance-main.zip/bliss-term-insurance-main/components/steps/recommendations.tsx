"use client";

import { useMemo, useState } from "react";
import { Check } from "lucide-react";
import { InsurerComparisonTable } from "@/components/steps/insurer-comparison-table";
import { MetricLegendTile } from "@/components/steps/metric-legend-tile";
import { NriGuidelinesSection } from "@/components/steps/nri-guidelines-section";
import { PolicyDetailsView } from "@/components/steps/policy-details-view";
import { useFlow } from "@/context/flow-provider";
import { insurerIdsForPolicies, policyById } from "@/lib/policies";
import type {
  Insurer,
  PolicyDetailsContent,
  PolicyDetailsPageCopy,
  RecommendationsContent,
  Residency,
} from "@/types";

/**
 * Recommendations step. Receives already-loaded, already-validated insurers,
 * per-policy detail content, and page copy as props (the server component
 * does the I/O): key-metric legend tiles plus the insurer comparison table.
 * Clicking a policy name swaps the whole step to that policy's Policy
 * Details — no route change, no modal. Inbuilt Features lives on its own
 * page under Resources (see app/flow/resources/[resourceId]).
 */

function SectionHeading({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <div className="flex flex-col gap-1.5">
      <span className="text-[13px] font-semibold uppercase tracking-[0.12em] text-accent-blue">{eyebrow}</span>
      <h2 className="text-[28px] font-bold leading-[1.25] tracking-[-0.015em] text-text-primary">{title}</h2>
    </div>
  );
}

export function Recommendations({
  content,
  insurersBySegment,
  allInsurers,
  policyDetailsByPolicyId,
  policyDetailsCopy,
}: {
  content: RecommendationsContent;
  insurersBySegment: Record<Residency, Insurer[]>;
  allInsurers: Insurer[];
  policyDetailsByPolicyId: Record<string, PolicyDetailsContent>;
  policyDetailsCopy: PolicyDetailsPageCopy;
}) {
  const {
    residency,
    selectedPolicies,
    secondaryRecommendationEnabled,
    setSecondaryRecommendationEnabled,
    secondaryRecommendationPolicyId,
  } = useFlow();
  // POLICY DETAILS LINK ARCHIVED — the comparison table's policy names are
  // now plain text (see insurer-comparison-table.tsx), so nothing ever
  // calls setViewingPolicyId anymore and this branch is dormant. Restoring
  // is just re-adding the onClick there.
  const [viewingPolicyId, setViewingPolicyId] = useState<string | null>(null);

  const insurersById = useMemo(() => {
    const map: Record<string, Insurer> = {};
    for (const i of allInsurers) map[i.id] = i;
    return map;
  }, [allInsurers]);

  // Policy selection drives which insurers appear. An explicitly-selected
  // policy is resolved against the FULL insurer list, not just the current
  // residency's segment — some presets (e.g. Bajaj as Resident's secondary
  // recommendation) sit outside their usual segment gate, and an explicit
  // pick should win over that default gate. The segment list is only used
  // as the no-selection fallback view.
  const segmentInsurers = insurersBySegment[residency];
  const selectedInsurerIds = insurerIdsForPolicies(selectedPolicies);
  const insurers =
    selectedInsurerIds.length > 0
      ? selectedInsurerIds.map((id) => insurersById[id]).filter((i): i is Insurer => i !== undefined)
      : segmentInsurers;

  if (viewingPolicyId) {
    const policy = policyById(viewingPolicyId);
    const detail = policyDetailsByPolicyId[viewingPolicyId];
    const insurer = policy ? insurersById[policy.insurerId] : undefined;
    if (policy && detail && insurer) {
      return (
        <PolicyDetailsView
          policy={detail}
          policyName={policy.name}
          insurerName={insurer.name}
          insurerLogo={insurer.logo}
          copy={policyDetailsCopy}
          residency={residency}
          onBack={() => setViewingPolicyId(null)}
        />
      );
    }
  }

  const secondaryPolicy = secondaryRecommendationPolicyId ? policyById(secondaryRecommendationPolicyId) : null;

  return (
    <div className="flex flex-col gap-14">
      {/* Why these four metrics */}
      <section id="why-efficient" className="flex scroll-mt-24 flex-col gap-4">
        <SectionHeading eyebrow="Reliability" title={content.keyMetricsHeading} />
        <p className="max-w-[720px] text-[19px] leading-[1.6] text-text-secondary">{content.keyMetricsLead}</p>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {content.keyMetrics.map((metric) => (
            <MetricLegendTile key={metric.field} metric={metric} />
          ))}
        </div>
      </section>

      {/* How our picks compare */}
      <section id="compare" className="flex scroll-mt-24 flex-col gap-6">
        <SectionHeading eyebrow="Comparison" title={content.compareHeading} />

        <h3 className="text-base font-semibold text-text-primary">
          {residency === "resident" ? content.residentHeading : content.nriHeading}
        </h3>

        {insurers.length > 0 ? (
          <InsurerComparisonTable
            insurers={insurers}
            keyMetrics={content.keyMetrics}
            insurerColumnLabel={content.insurerColumnLabel}
            selectedPolicyIds={selectedPolicies}
            footnote={content.footnote}
          />
        ) : (
          <p className="rounded-card border border-border-default bg-bg-card p-6 text-sm text-text-muted">
            {content.emptyNote}
          </p>
        )}

        {secondaryPolicy && (
          <label className="flex cursor-pointer items-center gap-1.5 self-end text-[14px] text-text-muted">
            <span
              className={
                "flex h-3 w-3 shrink-0 items-center justify-center rounded-[3px] border transition-colors " +
                (secondaryRecommendationEnabled
                  ? "border-accent-blue bg-accent-blue text-white"
                  : "border-border-strong")
              }
            >
              {secondaryRecommendationEnabled && <Check className="h-2 w-2" strokeWidth={3} />}
            </span>
            <input
              type="checkbox"
              className="sr-only"
              checked={secondaryRecommendationEnabled}
              onChange={(e) => setSecondaryRecommendationEnabled(e.target.checked)}
            />
            {content.secondaryRecommendationToggleLabel}
          </label>
        )}

        {residency === "nri" && <NriGuidelinesSection insurers={insurers} />}
      </section>
    </div>
  );
}
