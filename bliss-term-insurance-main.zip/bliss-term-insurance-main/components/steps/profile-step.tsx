"use client";

import { createElement } from "react";
import * as LucideIcons from "lucide-react";
import { renderBoldText } from "@/lib/rich-text";
import type { ProfileContent } from "@/types";

/**
 * Profile (eligibility) step: two slim trust-building info bars, followed by
 * a symmetric grid of all 8 profile factors as uniform hover-reveal tiles
 * (title always visible, body revealed on hover/focus — same reveal
 * mechanic as the Why Ditto step's pillars, recoloured for a plain white
 * surface). Purely educational; every value that drives the calculators
 * lives in the Control Panel, entered once.
 */

type IconComponent = React.ComponentType<{ className?: string }>;

function getIcon(name: string): IconComponent {
  const map = LucideIcons as unknown as Record<string, IconComponent>;
  return map[name] ?? LucideIcons.HelpCircle;
}

function FactorIcon({ name, className }: { name: string; className?: string }) {
  return createElement(getIcon(name), { className });
}

export function ProfileStep({ content }: { content: ProfileContent }) {
  return (
    <div className="flex flex-col gap-8">
      {/* Trust-building info bar — one merged tile, rows divided internally */}
      <div className="flex flex-col divide-y divide-accent-blue-border/60 rounded-xl border border-accent-blue-border bg-accent-blue-soft">
        {content.assurances.map((a) => (
          <div key={a.title} className="flex items-center gap-3 px-4 py-3">
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-accent-blue/15 text-accent-blue">
              <FactorIcon name={a.icon} className="h-3.5 w-3.5" />
            </span>
            <p className="text-sm leading-relaxed text-text-secondary">
              <span className="font-semibold text-text-primary">{a.title}.</span> {a.body}
            </p>
          </div>
        ))}
      </div>

      {/* Profile factors — uniform hover-reveal tiles */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {content.factors.map((factor) => (
          <div
            key={factor.id}
            tabIndex={0}
            className="profile-tile flex min-h-[124px] flex-col items-center justify-center gap-1.5 px-4 py-4 text-center outline-none focus-visible:ring-2 focus-visible:ring-accent-blue focus-visible:ring-offset-2"
          >
            <div className="relative z-10 flex flex-col items-center">
              <span className="mb-1.5 inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-hover-surface">
                <FactorIcon name={factor.icon} className="h-4.5 w-4.5" />
              </span>
              <h3 className="text-base font-semibold tracking-tight">{factor.title}</h3>
              <p className="profile-tile__body text-sm leading-relaxed">{renderBoldText(factor.body)}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
