"use client";

import { Card } from "@/components/ui/card";
import { useFlow } from "@/context/flow-provider";

/**
 * Shared explainer tile for WOP/CI: a definition line plus a gender-matched
 * illustration. Assets live in public/illustrations as {WOP|CI}_{F|M}.png.
 * DARK MODE ARCHIVED — the {F|M}-dark.png variants this tile used to switch
 * to are no longer selected; see docs/DARK_MODE_ARCHIVE.md.
 */
export function RiderIllustrationTile({
  definition,
  assetBaseName,
  alt,
}: {
  definition: string;
  assetBaseName: "WOP" | "CI";
  alt: string;
}) {
  const { customer } = useFlow();

  const genderSuffix = customer.gender === "female" ? "F" : "M";
  const src = `/illustrations/${assetBaseName}_${genderSuffix}.png`;

  return (
    <Card className="flex flex-col gap-5">
      <p className="text-sm leading-relaxed text-text-secondary">{definition}</p>
      <div className="flex items-center justify-center">
        <img src={src} alt={alt} className="h-auto w-full max-w-[1000px]" draggable={false} />
      </div>
    </Card>
  );
}
