"use client";

import { useRouter } from "next/navigation";
import { ChevronLeft } from "lucide-react";

/**
 * Looks like a "back" link but actually goes back — browser history, not a
 * fixed destination. A plain Link to the Resources index would always land
 * there even when the advisor arrived via a WOP/CI table's Full List link
 * (from Riders, say), so a single press wouldn't return them to where they
 * clicked from. Falls back to `indexHref` only when there's nothing in this
 * tab's history to go back to (e.g. the page was opened directly).
 */
export function BackToIndexLink({ indexHref, label }: { indexHref: string; label: string }) {
  const router = useRouter();

  return (
    <button
      type="button"
      onClick={() => {
        if (typeof window !== "undefined" && window.history.length > 1) {
          router.back();
        } else {
          router.push(indexHref);
        }
      }}
      className="inline-flex w-fit cursor-pointer items-center gap-1.5 text-sm font-semibold text-accent-blue hover:underline"
    >
      <ChevronLeft className="h-3.5 w-3.5" />
      {label}
    </button>
  );
}
