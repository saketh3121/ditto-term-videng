"use client";

import { useMemo, useState } from "react";
import { Info } from "lucide-react";
import { AccordionSection } from "@/components/ui/accordion";
import { Segmented } from "@/components/ui/segmented";
import nriGuidelinesContent from "@/content/nri-guidelines.json";
import type { Insurer, NriGuidelinesContent } from "@/types";

/**
 * Collapsible NRI Guidelines table shown under the "How our picks compare"
 * comparison table — only for NRI customer profiles (see recommendations.tsx).
 * Rows are filtered and ordered to match `insurers`, the same
 * currently-recommended list the comparison table above renders — an
 * insurer with no medical-abroad content, or one not actually recommended
 * for this customer, simply doesn't get a row.
 */

const CONTENT = nriGuidelinesContent as NriGuidelinesContent;

type Tab = "gcc" | "nonGcc";

export function NriGuidelinesSection({ insurers }: { insurers: Insurer[] }) {
  const [tab, setTab] = useState<Tab>("gcc");

  const rows = useMemo(() => {
    const detailsByInsurerId = new Map((tab === "gcc" ? CONTENT.gcc : CONTENT.nonGcc).map((d) => [d.insurerId, d.details]));
    return insurers
      .map((insurer) => {
        const details = detailsByInsurerId.get(insurer.id);
        return details ? { insurer, details } : null;
      })
      .filter((row): row is { insurer: Insurer; details: string } => row !== null);
  }, [insurers, tab]);

  if (rows.length === 0) return null;

  return (
    <AccordionSection title={CONTENT.heading}>
      <div className="flex flex-col gap-4">
        <Segmented
          value={tab}
          onChange={(v) => setTab(v as Tab)}
          options={[
            { value: "gcc", label: CONTENT.gccLabel },
            { value: "nonGcc", label: CONTENT.nonGccLabel },
          ]}
          className="max-w-xs"
        />

        <div className="overflow-hidden rounded-card border border-border-default">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="bg-bg-card-elevated text-left text-[13px] uppercase tracking-wider text-text-muted">
                <th className="px-4 py-2.5 font-bold" colSpan={2}>
                  {CONTENT.tableHeading}
                </th>
              </tr>
              <tr className="border-t border-border-subtle bg-bg-card-elevated text-left text-[13px] uppercase tracking-wider text-text-muted">
                <th className="w-[220px] px-4 py-2 font-semibold">{CONTENT.insurerColumnLabel}</th>
                <th className="px-4 py-2 font-semibold">{CONTENT.detailsColumnLabel}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border-subtle">
              {rows.map(({ insurer, details }) => (
                <tr key={insurer.id}>
                  <td className="px-4 py-3 align-top">
                    <div className="flex items-center gap-2">
                      <img
                        src={insurer.logo}
                        alt=""
                        className="h-7 w-7 shrink-0 rounded-md bg-white object-contain p-1 ring-1 ring-border-default"
                      />
                      <span className="font-medium text-text-primary">{insurer.name}</span>
                    </div>
                  </td>
                  <td className="whitespace-pre-line px-4 py-3 align-top text-text-secondary">{details}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex items-start gap-3 rounded-xl border border-accent-blue-border bg-accent-blue-soft px-5 py-4">
          <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-accent-blue/15 text-accent-blue">
            <Info className="h-3.5 w-3.5" />
          </span>
          <div className="flex flex-col gap-1 text-sm leading-relaxed">
            <p className="font-semibold text-text-primary">{CONTENT.indiaBannerHeading}</p>
            <p className="text-text-secondary">{CONTENT.indiaBannerText}</p>
          </div>
        </div>
      </div>
    </AccordionSection>
  );
}
