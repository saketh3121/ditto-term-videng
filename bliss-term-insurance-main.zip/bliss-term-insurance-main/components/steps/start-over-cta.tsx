"use client";

import { useRouter } from "next/navigation";
import { RotateCcw } from "lucide-react";
import { useFlow } from "@/context/flow-provider";
import chromeContent from "@/content/chrome.json";
import type { ChromeContent } from "@/types";

const CHROME = chromeContent as ChromeContent;

/**
 * End-of-flow "Start over" affordance — the second of the two placements
 * requested alongside the TopBar's icon (top-bar.tsx): one reachable from
 * anywhere, one explicit at the natural end of a call (Why Ditto, the last
 * step). Same confirm-then-reset-then-redirect-home behavior as the TopBar's.
 */
export function StartOverCta() {
  const { startOver } = useFlow();
  const router = useRouter();

  const handleClick = () => {
    if (!window.confirm(CHROME.startOverConfirm)) return;
    startOver();
    router.push("/");
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      className="inline-flex items-center gap-2 self-center rounded-pill border border-border-default px-5 py-2.5 text-sm font-medium text-text-secondary transition-colors cursor-pointer hover:border-accent-blue/40 hover:text-accent-blue"
    >
      <RotateCcw className="h-4 w-4" />
      {CHROME.startOverLabel}
    </button>
  );
}
