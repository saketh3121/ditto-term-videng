"use client";

import { useState } from "react";
import { Calendar, CalendarCheck, CalendarClock, CalendarRange, IndianRupee, Info } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * "How often you pay" — a frequency toggle (Monthly/Quarterly/Semi-Annually/
 * Annually) paired with a Jan–Dec month strip. Hovering (or focusing) a
 * frequency pill previews which months a payment would land on; clicking
 * selects it, so the strip keeps showing that pattern after the pointer
 * moves away. Purely conceptual — no premium figures, matching the
 * reference mock exactly.
 */

const MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];

type Frequency = "monthly" | "quarterly" | "semiAnnually" | "annually";

const FREQUENCIES: { value: Frequency; label: string; icon: typeof Calendar; perYear: number }[] = [
  { value: "monthly", label: "Monthly", icon: Calendar, perYear: 12 },
  { value: "quarterly", label: "Quarterly", icon: CalendarRange, perYear: 4 },
  { value: "semiAnnually", label: "Semi-Annually", icon: CalendarClock, perYear: 2 },
  { value: "annually", label: "Annually", icon: CalendarCheck, perYear: 1 },
];

/** Evenly-spaced month indices for a given number of payments a year. */
function activeMonthIndices(perYear: number): Set<number> {
  const step = 12 / perYear;
  return new Set(Array.from({ length: perYear }, (_, i) => i * step));
}

export function PremiumFrequencyToggle({ intro, disclaimers }: { intro: string; disclaimers: string[] }) {
  const [selected, setSelected] = useState<Frequency>("monthly");
  const [hovered, setHovered] = useState<Frequency | null>(null);
  const active = hovered ?? selected;
  const activeMeta = FREQUENCIES.find((f) => f.value === active) ?? FREQUENCIES[0]!;
  const activeIndices = activeMonthIndices(activeMeta.perYear);

  return (
    <div className="flex flex-col gap-5">
      <p className="max-w-[640px] text-sm leading-relaxed text-text-secondary">{intro}</p>

      <div className="flex flex-wrap gap-2">
        {FREQUENCIES.map((f) => {
          const isSelected = selected === f.value;
          return (
            <button
              key={f.value}
              type="button"
              onClick={() => setSelected(f.value)}
              onMouseEnter={() => setHovered(f.value)}
              onMouseLeave={() => setHovered(null)}
              onFocus={() => setHovered(f.value)}
              onBlur={() => setHovered(null)}
              className={cn(
                "inline-flex cursor-pointer items-center gap-2 rounded-full border px-4 py-2 text-sm font-medium transition-colors",
                isSelected
                  ? "border-accent-blue bg-accent-blue text-white"
                  : "border-border-default bg-bg-card text-text-secondary hover:border-accent-blue/40 hover:text-text-primary",
              )}
            >
              <f.icon className="h-4 w-4" />
              {f.label}
            </button>
          );
        })}
      </div>

      <div className="overflow-x-auto rounded-card border border-border-default bg-bg-card px-6 py-6">
        <div className="flex min-w-[640px] items-end justify-between gap-1">
          {MONTHS.map((month, i) => {
            const isActive = activeIndices.has(i);
            return (
              <div key={month} className="flex flex-1 flex-col items-center gap-1.5">
                <span
                  className={cn(
                    "flex h-8 w-8 items-center justify-center rounded-full border transition-all duration-300",
                    isActive
                      ? "scale-100 border-good/30 bg-good/10 text-good opacity-100"
                      : "scale-75 border-transparent bg-transparent text-transparent opacity-0",
                  )}
                >
                  <IndianRupee className="h-4 w-4" />
                </span>
                <span className="h-3 w-px bg-border-default" />
              </div>
            );
          })}
        </div>
        <div className="flex min-w-[640px] justify-between border-t border-border-default">
          {MONTHS.map((month, i) => {
            const isActive = activeIndices.has(i);
            return (
              <div key={month} className="flex flex-1 flex-col items-center">
                <span
                  className={cn(
                    "-mt-[3px] h-1.5 w-1.5 rounded-full transition-colors duration-300",
                    isActive ? "bg-accent-blue" : "bg-border-strong",
                  )}
                />
                <span className="mt-2 text-[13px] font-semibold uppercase tracking-wide text-text-muted">
                  {month}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="flex items-start gap-3 rounded-xl border border-accent-blue-border bg-accent-blue-soft px-5 py-4">
        <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-accent-blue/15 text-accent-blue">
          <Info className="h-3.5 w-3.5" />
        </span>
        <ul className="flex flex-col gap-2 text-sm leading-relaxed text-text-secondary">
          {disclaimers.map((d) => (
            <li key={d}>{d}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}
