"use client";

import { useMemo, useState } from "react";
import { InbuiltFeaturesTable } from "@/components/steps/inbuilt-features-table";
import { RiderIllustrationTile } from "@/components/steps/rider-illustration-tile";
import { StaticComparisonTableView } from "@/components/steps/static-comparison-table";
import { Segmented } from "@/components/ui/segmented";
import { useFlow } from "@/context/flow-provider";
import { staticTable, visibleOthersCategories, visibleStaticColumns, type RiderPill } from "@/lib/riders";
import type { Insurer, RidersPageCopy } from "@/types";

/**
 * Recommended Riders step: three pills. WOP and CI are fixed-parameter
 * insurer-comparison tables sourced straight from an editorial spreadsheet
 * (StaticComparisonTableView); Others reuses the Inbuilt-Features-style
 * per-policy table. All three scope their columns to the currently-selected
 * policies (Policy Panel).
 */
export function Riders({ content, allInsurers }: { content: RidersPageCopy; allInsurers: Insurer[] }) {
  const { selectedPolicies } = useFlow();
  const [pill, setPill] = useState<RiderPill>("wop");

  const insurersById = useMemo(() => {
    const map: Record<string, Insurer> = {};
    for (const i of allInsurers) map[i.id] = i;
    return map;
  }, [allInsurers]);

  return (
    <div className="flex flex-col gap-6">
      <Segmented
        value={pill}
        options={[
          { value: "wop", label: content.wopTabLabel },
          { value: "ci", label: content.ciTabLabel },
          { value: "others", label: content.othersTabLabel },
        ]}
        onChange={(v) => setPill(v as RiderPill)}
        className="max-w-sm"
      />

      {pill === "wop" && (
        <>
          <h2 className="text-[28px] font-bold leading-[1.25] tracking-[-0.015em] text-text-primary">
            {content.wopHeading}
          </h2>
          <RiderIllustrationTile
            definition={content.wopDefinition}
            assetBaseName="WOP"
            alt="Waiver of Premium timeline: after the waiting period, if an accident or critical illness is detected and the survival period completes, all future premiums are waived and life cover continues till maturity."
          />
          <StaticComparisonTableView
            table={staticTable("wop")}
            columns={visibleStaticColumns(staticTable("wop"), selectedPolicies)}
            insurersById={insurersById}
            parametersLabel={content.parametersLabel}
            naLabel={content.naLabel}
            emptyNote={content.emptyNote}
            illnessListSection="wop"
            fullListLabel={content.fullListLabel}
          />
        </>
      )}

      {pill === "ci" && (
        <>
          <h2 className="text-[28px] font-bold leading-[1.25] tracking-[-0.015em] text-text-primary">
            {content.ciHeading}
          </h2>
          <RiderIllustrationTile
            definition={content.ciDefinition}
            assetBaseName="CI"
            alt="Critical Illness timeline: after the waiting period, if a critical illness is detected and the survival period completes, the benefit triggers a lump sum payment while cover continues till maturity."
          />
          <StaticComparisonTableView
            table={staticTable("ci")}
            columns={visibleStaticColumns(staticTable("ci"), selectedPolicies)}
            insurersById={insurersById}
            parametersLabel={content.parametersLabel}
            naLabel={content.naLabel}
            emptyNote={content.emptyNote}
            illnessListSection="ci"
            fullListLabel={content.fullListLabel}
          />
        </>
      )}

      {pill === "others" && (
        <>
          <h2 className="text-[28px] font-bold leading-[1.25] tracking-[-0.015em] text-text-primary">
            {content.othersHeading}
          </h2>
          <InbuiltFeaturesTable
            categories={visibleOthersCategories(selectedPolicies)}
            policyIds={selectedPolicies}
            insurersById={insurersById}
            parametersLabel={content.parametersLabel}
            naLabel={content.naLabel}
            emptyNote={content.emptyNote}
            showCategoryTitles={false}
          />
        </>
      )}
    </div>
  );
}
