import { ReviewsCarousel } from "@/components/steps/reviews-carousel";
import { StartOverCta } from "@/components/steps/start-over-cta";
import type { WhyDittoContent } from "@/types";

/**
 * Why Ditto: three hover-reveal pillar cards (title only at rest; hovering
 * or focusing expands two corner accents to fill the card and fades the
 * body text in — pure CSS, see .why-ditto-pillar in globals.css), followed
 * by an auto-rotating carousel of real LinkedIn customer reviews.
 */
export function WhyDitto({ content }: { content: WhyDittoContent }) {
  return (
    <div className="flex flex-col gap-10">
      <div className="grid grid-cols-1 gap-5 md:grid-cols-3">
        {content.cards.map((card) => (
          <div
            key={card.title}
            tabIndex={0}
            className="why-ditto-pillar flex min-h-[220px] flex-col items-center justify-center px-5 py-7 text-center outline-none focus-visible:ring-2 focus-visible:ring-accent-sky focus-visible:ring-offset-2"
          >
            <div className="relative z-10 flex flex-col items-center">
              <h3 className="text-xl font-semibold tracking-tight">{card.title}</h3>
              <p className="why-ditto-pillar__body text-[19px] leading-relaxed">{card.body}</p>
            </div>
          </div>
        ))}
      </div>

      <div>
        <p className="text-[14px] font-semibold uppercase tracking-wider text-text-muted">
          {content.reviewsSectionLabel}
        </p>
        <ReviewsCarousel reviews={content.reviews} />
      </div>

      <div className="flex flex-col items-center gap-2 border-t border-border-subtle pt-8">
        <StartOverCta />
      </div>
    </div>
  );
}
