"use client";

import Link from "next/link";
import { Check, X } from "lucide-react";
import { AnnotatedText } from "@/components/ui/annotated-text";
import { hasIllnessData } from "@/lib/specific-illnesses";
import { policyById } from "@/lib/policies";
import type { Insurer, StaticComparisonCell, StaticComparisonColumn, StaticComparisonTable } from "@/types";

/**
 * Fixed-row, fixed-insurer-column comparison table for the WOP/CI rider
 * pills — sourced directly from an editorial spreadsheet, not scaled per
 * selected policy the way Inbuilt Features is. `columns` is expected
 * pre-filtered via lib/riders.ts's visibleStaticColumns(table, policyIds).
 *
 * Footnoted cells carry a superscript marker (e.g. "60*") instead of an (i)
 * button — every marker used anywhere in the table is spelled out once, in
 * order, in a footnote block glued to the bottom of the table (same card,
 * no gap), immediately above the standing disclaimer. Matches the source
 * spreadsheet/deck's own footnote convention.
 *
 * Rows flagged `linksToIllnessList` (the illness-count rows) additionally
 * get a "Full List" link per non-empty cell, jumping to that policy's
 * Resources > Specific Illnesses page.
 */

function FootnoteMarker({ marker }: { marker: string }) {
  return <sup className="ml-0.5 font-bold text-accent-blue">{marker}</sup>;
}

function FullListLink({ policyId, section, label }: { policyId: string; section: "wop" | "ci"; label: string }) {
  if (!hasIllnessData(policyId)) return null;
  return (
    <Link
      href={`/flow/resources/specific-illnesses/${policyId}#${section}`}
      className="block text-xs font-semibold text-accent-blue hover:underline"
    >
      {label}
    </Link>
  );
}

function StaticCellValue({
  cell,
  rowLabel,
  naLabel,
  fullList,
}: {
  cell: StaticComparisonCell;
  rowLabel: string;
  naLabel: string;
  fullList: { policyId: string; section: "wop" | "ci"; label: string } | null;
}) {
  const marker = cell.footnoteMarker ? <FootnoteMarker marker={cell.footnoteMarker} /> : null;

  if (cell.kind === "check") {
    return (
      <span className="inline-flex items-center justify-center gap-0.5">
        <span
          title={rowLabel}
          className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-good/10 text-good"
        >
          <Check className="h-3.5 w-3.5" strokeWidth={3} />
        </span>
        {marker}
      </span>
    );
  }

  if (cell.kind === "cross") {
    return (
      <span className="inline-flex items-center justify-center gap-0.5">
        <span
          title={naLabel}
          className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-bad/10 text-bad"
        >
          <X className="h-3.5 w-3.5" />
        </span>
        {marker}
      </span>
    );
  }

  if (!cell.text) {
    return <span className="text-text-muted">{naLabel}</span>;
  }

  return (
    <span className="inline-flex flex-col items-center gap-1">
      <span className="inline-flex items-start justify-center gap-0.5">
        <span className="whitespace-pre-line text-text-secondary">
          <AnnotatedText text={cell.text} />
        </span>
        {marker}
      </span>
      {fullList && <FullListLink policyId={fullList.policyId} section={fullList.section} label={fullList.label} />}
    </span>
  );
}

interface StaticComparisonTableViewProps {
  table: StaticComparisonTable;
  columns: StaticComparisonColumn[];
  insurersById: Record<string, Insurer>;
  parametersLabel: string;
  naLabel: string;
  emptyNote: string;
  /** Which Specific Illnesses section (WOP or CI) rows flagged linksToIllnessList should jump to. */
  illnessListSection: "wop" | "ci";
  fullListLabel: string;
}

export function StaticComparisonTableView({
  table,
  columns,
  insurersById,
  parametersLabel,
  naLabel,
  emptyNote,
  illnessListSection,
  fullListLabel,
}: StaticComparisonTableViewProps) {
  if (columns.length === 0) {
    return (
      <p className="rounded-card border border-border-default bg-bg-card p-6 text-sm text-text-muted">{emptyNote}</p>
    );
  }

  return (
    <div className="overflow-hidden rounded-card border border-border-default bg-bg-card">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[820px] border-collapse text-sm">
          <thead>
            <tr className="bg-bg-card-elevated text-center text-[14px] uppercase tracking-wider text-text-muted">
              <th className="w-64 px-6 py-3 font-bold">{parametersLabel}</th>
              {columns.map((col) => {
                const policy = policyById(col.policyId);
                const insurer = insurersById[col.insurerId];
                return (
                  <th key={col.policyId} className="min-w-[240px] px-4 py-3 font-bold normal-case">
                    <div className="flex flex-col items-center gap-1.5">
                      {insurer && (
                        <img
                          src={insurer.logo}
                          alt=""
                          className="h-8 w-8 shrink-0 rounded-md bg-white object-contain p-1 ring-1 ring-border-default"
                        />
                      )}
                      <div className="flex flex-col items-center gap-0.5">
                        <span className="text-sm font-semibold text-text-primary">{policy?.name}</span>
                        <span className="text-[14px] uppercase tracking-wide text-text-muted">{insurer?.name}</span>
                      </div>
                    </div>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody className="divide-y divide-border-subtle">
            {table.rows.map((row) => (
              <tr key={row.label} className="hover:bg-bg-card-elevated/60">
                <td className="px-6 py-4 text-center align-middle font-medium text-text-primary">
                  <AnnotatedText text={row.label} />
                </td>
                {columns.map((col) => (
                  <td key={col.policyId} className="px-4 py-4 text-center align-middle">
                    <StaticCellValue
                      cell={row.cells[col.policyId] ?? { kind: "text", text: "", footnoteMarker: null }}
                      rowLabel={row.label}
                      naLabel={naLabel}
                      fullList={
                        row.linksToIllnessList
                          ? { policyId: col.policyId, section: illnessListSection, label: fullListLabel }
                          : null
                      }
                    />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {(table.footnotes.length > 0 || table.disclaimer) && (
        <div className="border-t border-border-subtle bg-bg-card-elevated px-6 py-4">
          <ul className="flex flex-col gap-1.5 text-xs text-text-muted">
            {table.footnotes.map((footnote) => (
              <li key={footnote.marker}>
                <span className="font-bold text-accent-blue">{footnote.marker}</span>{" "}
                <AnnotatedText text={footnote.text} />
              </li>
            ))}
            {table.disclaimer && <li>{table.disclaimer}</li>}
          </ul>
        </div>
      )}
    </div>
  );
}
