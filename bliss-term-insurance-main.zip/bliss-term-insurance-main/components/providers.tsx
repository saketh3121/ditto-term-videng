"use client";

import { SessionProvider } from "next-auth/react";
import { ThemeProvider } from "next-themes";
import { FlowProvider } from "@/context/flow-provider";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SessionTracker } from "@/components/session-tracker";

/**
 * Top-level client providers: session + theme + flow state + tooltip delay
 * group (so hovering across several abbreviation hints in a row doesn't
 * re-trigger the open delay).
 *
 * DARK MODE ARCHIVED — forcedTheme="light" locks every consumer's
 * useTheme() to light regardless of stored preference; see
 * docs/DARK_MODE_ARCHIVE.md for the full list of touched files and how to
 * restore.
 *
 * `SessionProvider` backs `useSession()` everywhere — the whole site
 * (`/`, `/flow/*`, `/admin/*`) is gated by proxy.ts, so a session is always
 * present by the time client components render. See docs/AUTH.md.
 */
export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <SessionProvider>
      <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false} forcedTheme="light">
        <TooltipProvider>
          <FlowProvider>
            <SessionTracker />
            {children}
          </FlowProvider>
        </TooltipProvider>
      </ThemeProvider>
    </SessionProvider>
  );
}
